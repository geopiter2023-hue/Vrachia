// ─── Платформа: B2B-кабинет клиники + агрегатор для пациентов ─────────────
// Клиника: регистрация (email+пароль), профиль в агрегаторе, рекламные
// кампании по региону, приём записей от пациентов, статистика.
// Пациент: видит продвигаемые клиники своего региона, записывается.
import { z } from "zod";
import crypto from "node:crypto";
import { TRPCError } from "@trpc/server";
import { createRouter, publicQuery, userProcedure, t } from "./middleware";
import { getDb } from "./queries/connection";
import { clinicAccounts, clinicProfiles, clinicPromotions, clinicBookings } from "@db/schema";
import { and, desc, eq, sql } from "drizzle-orm";
import { ensurePlatformTables } from "./platformTables";

const CLINIC_COOKIE = "ai_vrach_clinic";
const SESSION_DAYS = 30;

// ── Таблицы (самосоздание) ───────────────────────────────────────────────
let ready = false;
async function ensureClinicTables() {
  if (ready) return;
  await ensurePlatformTables();
  const db = getDb();
  await db.execute(sql.raw(`CREATE TABLE IF NOT EXISTS clinic_sessions (
    id bigint unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
    token varchar(128) NOT NULL,
    account_id bigint unsigned NOT NULL,
    created_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp NOT NULL,
    UNIQUE KEY uq_token (token), KEY idx_acc (account_id)
  )`));
  ready = true;
}

function hashPassword(password: string, email: string): string {
  const secret = process.env.APP_SECRET ?? "ai-vrach";
  return crypto.createHash("sha256").update(`clinic:${email}:${password}:${secret}`).digest("hex");
}

function readClinicToken(req: Request): string | null {
  const raw = req.headers.get("cookie") ?? "";
  for (const part of raw.split(";")) {
    const [k, ...v] = part.trim().split("=");
    if (k === CLINIC_COOKIE) return decodeURIComponent(v.join("="));
  }
  return null;
}

async function getClinicAccount(req: Request) {
  const token = readClinicToken(req);
  if (!token) return null;
  try {
    await ensureClinicTables();
    const db = getDb();
    const rows = await db.execute(sql.raw(
      `SELECT account_id FROM clinic_sessions WHERE token = '${token.replace(/'/g, "")}' AND expires_at > NOW() LIMIT 1`
    ));
    const list = (rows as any)[0] as any[];
    if (!list?.length) return null;
    const [acc] = await db.select().from(clinicAccounts).where(eq(clinicAccounts.id, Number(list[0].account_id))).limit(1);
    return acc ?? null;
  } catch {
    return null;
  }
}

function clinicCookie(req: Request, token: string, maxAgeSec: number): string {
  const secure = new URL(req.url).protocol === "https:" ? "; Secure" : "";
  return `${CLINIC_COOKIE}=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAgeSec}${secure}`;
}

// Процедура с обязательной авторизацией клиники
const clinicProcedure = t.procedure.use(async ({ ctx, next }) => {
  const account = await getClinicAccount(ctx.req);
  if (!account) throw new TRPCError({ code: "UNAUTHORIZED", message: "Требуется вход в кабинет клиники" });
  return next({ ctx: { ...ctx, clinic: { ...account, id: Number(account.id) } } });
});

export const clinicRouter = createRouter({
  // ── Регистрация клиники ────────────────────────────────────────────────
  register: publicQuery
    .input(z.object({
      email: z.string().email().max(255),
      password: z.string().min(8).max(128),
      orgName: z.string().min(2).max(255),
      licenseNumber: z.string().max(128).optional(),
      phone: z.string().max(64).optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      await ensureClinicTables();
      const db = getDb();
      const email = input.email.trim().toLowerCase();
      const [exists] = await db.select().from(clinicAccounts).where(eq(clinicAccounts.email, email)).limit(1);
      if (exists) return { ok: false as const, error: "Клиника с таким email уже зарегистрирована" };
      const r = await db.insert(clinicAccounts).values({
        email,
        passwordHash: hashPassword(input.password, email),
        orgName: input.orgName,
        licenseNumber: input.licenseNumber ?? null,
        phone: input.phone ?? null,
      });
      const accountId = Number((r as any)[0]?.insertId ?? (r as any).insertId);
      const token = crypto.randomBytes(32).toString("hex");
      await db.execute(sql.raw(
        `INSERT INTO clinic_sessions (token, account_id, expires_at) VALUES ('${token}', ${accountId}, DATE_ADD(NOW(), INTERVAL ${SESSION_DAYS} DAY))`
      ));
      ctx.resHeaders.append("Set-Cookie", clinicCookie(ctx.req, token, SESSION_DAYS * 86400));
      return { ok: true as const };
    }),

  // ── Вход клиники ───────────────────────────────────────────────────────
  login: publicQuery
    .input(z.object({ email: z.string().email(), password: z.string().min(1).max(128) }))
    .mutation(async ({ input, ctx }) => {
      await ensureClinicTables();
      const db = getDb();
      const email = input.email.trim().toLowerCase();
      const [acc] = await db.select().from(clinicAccounts).where(eq(clinicAccounts.email, email)).limit(1);
      if (!acc || acc.passwordHash !== hashPassword(input.password, email)) {
        return { ok: false as const, error: "Неверный email или пароль" };
      }
      const token = crypto.randomBytes(32).toString("hex");
      await db.execute(sql.raw(
        `INSERT INTO clinic_sessions (token, account_id, expires_at) VALUES ('${token}', ${Number(acc.id)}, DATE_ADD(NOW(), INTERVAL ${SESSION_DAYS} DAY))`
      ));
      ctx.resHeaders.append("Set-Cookie", clinicCookie(ctx.req, token, SESSION_DAYS * 86400));
      return { ok: true as const, orgName: acc.orgName };
    }),

  logout: publicQuery.mutation(async ({ ctx }) => {
    const token = readClinicToken(ctx.req);
    if (token) {
      try {
        await ensureClinicTables();
        await getDb().execute(sql.raw(`DELETE FROM clinic_sessions WHERE token = '${token.replace(/'/g, "")}'`));
      } catch { /* ignore */ }
    }
    ctx.resHeaders.append("Set-Cookie", clinicCookie(ctx.req, "", 0));
    return { ok: true };
  }),

  me: publicQuery.query(async ({ ctx }) => {
    const account = await getClinicAccount(ctx.req);
    if (!account) return { clinic: null };
    return {
      clinic: {
        id: Number(account.id),
        email: account.email,
        orgName: account.orgName,
        licenseNumber: account.licenseNumber,
      },
    };
  }),

  // ── Профиль клиники в агрегаторе ──────────────────────────────────────
  getProfile: clinicProcedure.query(async ({ ctx }) => {
    const db = getDb();
    const [p] = await db.select().from(clinicProfiles).where(eq(clinicProfiles.accountId, ctx.clinic.id)).limit(1);
    return { profile: p ? { ...p, id: Number(p.id), accountId: Number(p.accountId) } : null };
  }),

  saveProfile: clinicProcedure
    .input(z.object({
      name: z.string().min(2).max(255),
      city: z.string().min(2).max(128),
      address: z.string().max(512).optional(),
      phone: z.string().max(64).optional(),
      website: z.string().max(512).optional(),
      specialties: z.string().max(2000).optional(),
      services: z.string().max(4000).optional(),
      priceFrom: z.number().min(0).optional(),
      description: z.string().max(4000).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      await ensureClinicTables();
      const db = getDb();
      const [p] = await db.select().from(clinicProfiles).where(eq(clinicProfiles.accountId, ctx.clinic.id)).limit(1);
      if (p) {
        await db.update(clinicProfiles).set(input).where(eq(clinicProfiles.id, p.id));
      } else {
        await db.insert(clinicProfiles).values({ accountId: ctx.clinic.id, ...input });
      }
      return { ok: true };
    }),

  publish: clinicProcedure
    .input(z.object({ published: z.boolean() }))
    .mutation(async ({ ctx, input }) => {
      await ensureClinicTables();
      const db = getDb();
      const [p] = await db.select().from(clinicProfiles).where(eq(clinicProfiles.accountId, ctx.clinic.id)).limit(1);
      if (!p) return { ok: false, error: "Сначала заполните профиль клиники" };
      if (input.published && !ctx.clinic.licenseNumber) {
        return { ok: false, error: "Для публикации укажите номер медицинской лицензии в настройках аккаунта" };
      }
      await db.update(clinicProfiles).set({ isPublished: input.published }).where(eq(clinicProfiles.id, p.id));
      return { ok: true };
    }),

  // ── Продвижение (рекламные кампании по региону) ───────────────────────
  tariffs: publicQuery.query(() => ({
    items: [
      { code: "priority", name: "Приоритет в выдаче", description: "Клиника показывается первой в каталоге и в рекомендациях пользователям вашего региона. Помечается как «Реклама».", priceMonth: 15000 },
      { code: "banner", name: "Бренд-размещение", description: "Карточка клиники в ленте новостей и на главной у пользователей региона. Помечается как «Реклама».", priceMonth: 30000 },
    ],
  })),

  myPromotions: clinicProcedure.query(async ({ ctx }) => {
    const db = getDb();
    const rows = await db.select().from(clinicPromotions)
      .where(eq(clinicPromotions.accountId, ctx.clinic.id))
      .orderBy(desc(clinicPromotions.id));
    return { items: rows.map((r) => ({ ...r, id: Number(r.id), accountId: Number(r.accountId) })) };
  }),

  startPromotion: clinicProcedure
    .input(z.object({ tariff: z.enum(["priority", "banner"]) }))
    .mutation(async ({ ctx, input }) => {
      await ensureClinicTables();
      const db = getDb();
      const [p] = await db.select().from(clinicProfiles).where(eq(clinicProfiles.accountId, ctx.clinic.id)).limit(1);
      if (!p || !p.isPublished) return { ok: false, error: "Профиль клиники должен быть опубликован" };
      const price = input.tariff === "banner" ? 30000 : 15000;
      await db.insert(clinicPromotions).values({
        accountId: ctx.clinic.id,
        city: p.city,
        tariff: input.tariff,
        priceMonth: price,
        status: "active",
      });
      return { ok: true, note: "Кампания создана. Оплата — по счёту после согласования с менеджером." };
    }),

  stopPromotion: clinicProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      await db.update(clinicPromotions).set({ status: "stopped", endsAt: new Date() })
        .where(and(eq(clinicPromotions.id, input.id), eq(clinicPromotions.accountId, ctx.clinic.id)));
      return { ok: true };
    }),

  // ── Записи пациентов (кабинет клиники) ────────────────────────────────
  bookings: clinicProcedure.query(async ({ ctx }) => {
    const db = getDb();
    const rows = await db.select().from(clinicBookings)
      .where(eq(clinicBookings.accountId, ctx.clinic.id))
      .orderBy(desc(clinicBookings.id))
      .limit(200);
    return { items: rows.map((r) => ({ ...r, id: Number(r.id), userId: Number(r.userId), profileId: Number(r.profileId), accountId: Number(r.accountId) })) };
  }),

  setBookingStatus: clinicProcedure
    .input(z.object({ id: z.number(), status: z.enum(["confirmed", "done", "cancelled"]) }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      await db.update(clinicBookings).set({ status: input.status })
        .where(and(eq(clinicBookings.id, input.id), eq(clinicBookings.accountId, ctx.clinic.id)));
      return { ok: true };
    }),

  // ── Статистика кабинета ───────────────────────────────────────────────
  stats: clinicProcedure.query(async ({ ctx }) => {
    const db = getDb();
    const rows = await db.select().from(clinicBookings).where(eq(clinicBookings.accountId, ctx.clinic.id));
    const promos = await db.select().from(clinicPromotions).where(eq(clinicPromotions.accountId, ctx.clinic.id));
    return {
      bookingsTotal: rows.length,
      bookingsNew: rows.filter((r) => r.status === "new").length,
      bookingsDone: rows.filter((r) => r.status === "done").length,
      activePromotions: promos.filter((p) => p.status === "active").length,
    };
  }),

  // ══ ПАЦИЕНТСКАЯ СТОРОНА ══════════════════════════════════════════════

  // Каталог клиник агрегатора для пациента: продвигаемые первыми
  directory: userProcedure
    .input(z.object({ city: z.string().max(128).optional() }).optional())
    .query(async ({ input }) => {
      await ensureClinicTables();
      const db = getDb();
      const profiles = await db.select().from(clinicProfiles).where(eq(clinicProfiles.isPublished, true));
      const promos = await db.select().from(clinicPromotions).where(eq(clinicPromotions.status, "active"));
      const promoByAcc = new Map(promos.map((p) => [Number(p.accountId), p]));
      const city = input?.city?.trim().toLowerCase();
      const items = profiles
        .filter((p) => !city || p.city.toLowerCase().includes(city))
        .map((p) => {
          const promo = promoByAcc.get(Number(p.accountId));
          return {
            id: Number(p.id),
            name: p.name,
            city: p.city,
            address: p.address,
            phone: p.phone,
            website: p.website,
            specialties: p.specialties,
            services: p.services,
            priceFrom: p.priceFrom,
            description: p.description,
            promoted: Boolean(promo && (!city || promo.city.toLowerCase() === p.city.toLowerCase())),
            promoTariff: promo?.tariff ?? null,
          };
        })
        .sort((a, b) => Number(b.promoted) - Number(a.promoted));
      return { items };
    }),

  // Промо-баннер для главной/новостей (одна активная banner-кампания региона)
  promoBanner: userProcedure
    .input(z.object({ city: z.string().max(128).optional() }).optional())
    .query(async ({ input }) => {
      await ensureClinicTables();
      const db = getDb();
      const promos = await db.select().from(clinicPromotions)
        .where(and(eq(clinicPromotions.status, "active"), eq(clinicPromotions.tariff, "banner")));
      if (!promos.length) return { banner: null };
      const city = input?.city?.trim().toLowerCase();
      const promo = (city ? promos.find((p) => p.city.toLowerCase().includes(city)) : null) ?? promos[0];
      const [p] = await db.select().from(clinicProfiles)
        .where(and(eq(clinicProfiles.accountId, Number(promo.accountId)), eq(clinicProfiles.isPublished, true)))
        .limit(1);
      if (!p) return { banner: null };
      return {
        banner: {
          id: Number(p.id),
          name: p.name,
          city: p.city,
          phone: p.phone,
          website: p.website,
          description: p.description,
          priceFrom: p.priceFrom,
        },
      };
    }),

  // Запись пациента в клинику
  book: userProcedure
    .input(z.object({
      profileId: z.number(),
      specialty: z.string().max(128).optional(),
      preferredDate: z.string().max(32).optional(),
      contactPhone: z.string().min(5).max(64),
      comment: z.string().max(1000).optional(),
      reason: z.string().max(1000).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      await ensureClinicTables();
      const db = getDb();
      const [p] = await db.select().from(clinicProfiles)
        .where(and(eq(clinicProfiles.id, input.profileId), eq(clinicProfiles.isPublished, true)))
        .limit(1);
      if (!p) throw new TRPCError({ code: "NOT_FOUND", message: "Клиника не найдена" });
      await db.insert(clinicBookings).values({
        userId: ctx.user.id,
        profileId: Number(p.id),
        accountId: Number(p.accountId),
        specialty: input.specialty ?? null,
        preferredDate: input.preferredDate ?? null,
        contactPhone: input.contactPhone,
        comment: input.comment ?? null,
        reason: input.reason ?? null,
      });
      return { ok: true, clinicName: p.name };
    }),

  // Мои записи (пациент)
  myBookings: userProcedure.query(async ({ ctx }) => {
    await ensureClinicTables();
    const db = getDb();
    const rows = await db.select().from(clinicBookings)
      .where(eq(clinicBookings.userId, ctx.user.id))
      .orderBy(desc(clinicBookings.id))
      .limit(100);
    const profiles = await db.select().from(clinicProfiles);
    const nameById = new Map(profiles.map((p) => [Number(p.id), p.name]));
    return {
      items: rows.map((r) => ({
        id: Number(r.id),
        clinicName: nameById.get(Number(r.profileId)) ?? "Клиника",
        specialty: r.specialty,
        preferredDate: r.preferredDate,
        status: r.status,
        createdAt: r.createdAt,
      })),
    };
  }),
});
