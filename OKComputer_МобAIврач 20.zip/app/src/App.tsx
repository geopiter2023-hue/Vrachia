import { lazy, Suspense } from "react";
import { Routes, Route } from "react-router";
import { Toaster } from "@/components/ui/sonner";
import Layout from "@/components/Layout";
import Dashboard from "@/pages/Dashboard";
import { PrivacyPage, TermsPage } from "@/pages/LegalPages";

// Ленивая загрузка страниц — каждая попадает в отдельный чанк
const Biomarkers = lazy(() => import("@/pages/Biomarkers"));
const VitalsPage = lazy(() => import("@/pages/VitalsPage"));
const DocumentsPage = lazy(() => import("@/pages/DocumentsPage"));
const AssistantPage = lazy(() => import("@/pages/AssistantPage"));
const ClinicsPage = lazy(() => import("@/pages/ClinicsPage"));
const ReportsPage = lazy(() => import("@/pages/ReportsPage"));
const NotificationsPage = lazy(() => import("@/pages/NotificationsPage"));
const AuditPage = lazy(() => import("@/pages/AuditPage"));
const PetsPage = lazy(() => import("@/pages/PetsPage"));
const NewsPage = lazy(() => import("@/pages/NewsPage"));
const ImagingPage = lazy(() => import("@/pages/ImagingPage"));
const FamilyPage = lazy(() => import("@/pages/FamilyPage"));
const MedcardPage = lazy(() => import("@/pages/MedcardPage"));
const RecommendationsPage = lazy(() => import("@/pages/RecommendationsPage"));
const LabCatalogPage = lazy(() => import("@/pages/LabCatalogPage"));
const PressureDiaryPage = lazy(() => import("@/pages/PressureDiaryPage"));
const AchievementsPage = lazy(() => import("@/pages/AchievementsPage"));
const MedsPage = lazy(() => import("@/pages/MedsPage"));
const StepsPage = lazy(() => import("@/pages/StepsPage"));
const ClinicCabinetPage = lazy(() => import("@/pages/ClinicCabinetPage"));

function PageLoader() {
  return (
    <div className="flex min-h-[40vh] items-center justify-center">
      <div className="h-8 w-8 animate-spin rounded-full border-2 border-teal-600 border-t-transparent" />
    </div>
  );
}

export default function App() {
  return (
    <>
      <Routes>
        <Route element={<Layout />}>
          <Route path="/" element={<Dashboard />} />
          <Route
            path="/*"
            element={
              <Suspense fallback={<PageLoader />}>
                <Routes>
                  <Route path="biomarkers" element={<Biomarkers />} />
                  <Route path="vitals" element={<VitalsPage />} />
                  <Route path="documents" element={<DocumentsPage />} />
                  <Route path="assistant" element={<AssistantPage />} />
                  <Route path="clinics" element={<ClinicsPage />} />
                  <Route path="imaging" element={<ImagingPage />} />
                  <Route path="pets" element={<PetsPage />} />
                  <Route path="family" element={<FamilyPage />} />
                  <Route path="medcard" element={<MedcardPage />} />
                  <Route path="recommendations" element={<RecommendationsPage />} />
                  <Route path="catalog" element={<LabCatalogPage />} />
                  <Route path="pressure" element={<PressureDiaryPage />} />
                  <Route path="achievements" element={<AchievementsPage />} />
                  <Route path="meds" element={<MedsPage />} />
                  <Route path="steps" element={<StepsPage />} />
                  <Route path="news" element={<NewsPage />} />
                  <Route path="reports" element={<ReportsPage />} />
                  <Route path="notifications" element={<NotificationsPage />} />
                  <Route path="audit" element={<AuditPage />} />
                </Routes>
              </Suspense>
            }
          />
        </Route>
        <Route
          path="/clinic"
          element={
            <Suspense fallback={<PageLoader />}>
              <ClinicCabinetPage />
            </Suspense>
          }
        />
        <Route path="/legal/privacy" element={<div className="min-h-screen bg-background p-4 md:p-8"><PrivacyPage /></div>} />
        <Route path="/legal/terms" element={<div className="min-h-screen bg-background p-4 md:p-8"><TermsPage /></div>} />
      </Routes>
      <Toaster />
    </>
  );
}
