import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import MedOrgsSection from "@/pages/MedOrgsSection";
import {
  Hospital,
  Star,
  MapPin,
  Phone,
  BadgeCheck,
  Wrench,
  ChevronDown,
  Clock,
  Globe,
  Stethoscope,
  Info,
  ExternalLink,
} from "lucide-react";

type Clinic = {
  id: number | bigint;
  name: string;
  city: string;
  district: string | null;
  address: string | null;
  specialization: string;
  priceFrom: number | null;
  rating: number | null;
  reviewsCount: number | null;
  phone: string | null;
  hasLicense: boolean;
  equipment: string | null;
  source: string | null;
};

const WORK_HOURS: Record<string, string> = {
  "по ОМС": "Пн–Пт 08:00–20:00, Сб 09:00–15:00",
};

function priceText(c: Clinic) {
  return c.priceFrom ? `от ${c.priceFrom.toLocaleString("ru-RU")} ₽` : "по ОМС";
}

function mapsUrl(c: Clinic) {
  const q = encodeURIComponent(`${c.city}, ${c.address ?? c.name}`);
  return `https://yandex.ru/maps/?text=${q}`;
}

export default function ClinicsPage() {
  const [city, setCity] = useState("all");
  const [spec, setSpec] = useState("all");
  const [maxPrice, setMaxPrice] = useState("");
  const [sortBy, setSortBy] = useState<"value" | "price" | "rating">("value");
  const [openId, setOpenId] = useState<number | null>(null);
  const [tab, setTab] = useState<"picked" | "all">("picked");

  const { data: meta } = trpc.health.clinics.specializations.useQuery();
  const { data, isLoading } = trpc.health.clinics.list.useQuery({
    city: city === "all" ? undefined : city,
    specialization: spec === "all" ? undefined : spec,
    maxPrice: maxPrice ? Number(maxPrice) : undefined,
    sortBy,
  });

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl md:text-2xl font-bold">Клиники и врачи</h1>
        <p className="text-muted-foreground text-sm mt-1">
          Агрегированные данные по стоимости, рейтингу и отзывам · источники: DocDoc, НаПоправку, Yandex Health
        </p>
      </div>

      <div className="flex gap-1 rounded-xl bg-muted p-1">
        <button
          onClick={() => setTab("picked")}
          className={`flex-1 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
            tab === "picked" ? "bg-background shadow-sm text-foreground" : "text-muted-foreground"
          }`}
        >
          Подбор клиник
        </button>
        <button
          onClick={() => setTab("all")}
          className={`flex-1 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
            tab === "all" ? "bg-background shadow-sm text-foreground" : "text-muted-foreground"
          }`}
        >
          Все учреждения РФ
        </button>
      </div>

      {tab === "all" ? (
        <MedOrgsSection />
      ) : (
      <>
      <div className="flex flex-wrap gap-2">
        <Select value={city} onValueChange={setCity}>
          <SelectTrigger className="w-full sm:w-52">
            <SelectValue placeholder="Город" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Все города</SelectItem>
            {(meta?.cities ?? []).map((c) => (
              <SelectItem key={c} value={c}>{c}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={spec} onValueChange={setSpec}>
          <SelectTrigger className="w-full sm:w-52">
            <SelectValue placeholder="Специализация" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Все специализации</SelectItem>
            {(meta?.specializations ?? []).map((s) => (
              <SelectItem key={s} value={s}>{s}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Input
          className="w-full sm:w-44"
          type="number"
          placeholder="Цена до, ₽"
          value={maxPrice}
          onChange={(e) => setMaxPrice(e.target.value)}
        />
        <Select value={sortBy} onValueChange={(v) => setSortBy(v as any)}>
          <SelectTrigger className="w-full sm:w-56">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="value">Лучшее соотношение цена/качество</SelectItem>
            <SelectItem value="price">Сначала дешевле</SelectItem>
            <SelectItem value="rating">Сначала выше рейтинг</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {[0, 1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-40" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {(data ?? []).map((raw, idx) => {
            const c = raw as unknown as Clinic;
            const id = Number(c.id);
            const open = openId === id;
            const isBest = idx === 0 && sortBy === "value";
            return (
              <Card
                key={id}
                className={`cursor-pointer transition-all hover:shadow-sm ${isBest ? "border-primary" : ""}`}
                onClick={() => setOpenId(open ? null : id)}
              >
                <CardContent className="pt-5 space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                      <Hospital className="h-5 w-5 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium flex items-center gap-2 flex-wrap">
                        {c.name}
                        {isBest && (
                          <Badge className="bg-primary text-primary-foreground">Оптимальный выбор</Badge>
                        )}
                      </div>
                      <div className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                        <MapPin className="h-3 w-3" />
                        {c.city}{c.district ? `, ${c.district}` : ""}{c.address ? ` · ${c.address}` : ""}
                      </div>
                    </div>
                    <ChevronDown
                      className={`h-5 w-5 text-muted-foreground shrink-0 transition-transform ${open ? "rotate-180" : ""}`}
                    />
                  </div>

                  <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-sm">
                    <Badge variant="secondary">{c.specialization}</Badge>
                    <span className="font-semibold">{priceText(c)}</span>
                    <span className="flex items-center gap-1">
                      <Star className="h-4 w-4 fill-amber-400 text-amber-400" />
                      {c.rating} <span className="text-muted-foreground text-xs">({c.reviewsCount} отзывов)</span>
                    </span>
                    {c.hasLicense && (
                      <span className="flex items-center gap-1 text-xs text-emerald-600">
                        <BadgeCheck className="h-4 w-4" /> Лицензия
                      </span>
                    )}
                  </div>

                  {!open && c.equipment && (
                    <div className="text-xs text-muted-foreground flex items-center gap-1.5">
                      <Wrench className="h-3.5 w-3.5" /> {c.equipment}
                    </div>
                  )}

                  <div className="flex items-center justify-between text-xs text-muted-foreground pt-1 border-t">
                    <span className="flex items-center gap-1">
                      <Phone className="h-3 w-3" /> {c.phone ?? "—"}
                    </span>
                    <span>Источник: {c.source}</span>
                  </div>

                  {open && (
                    <div
                      className="space-y-3 pt-2 border-t"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <div className="grid grid-cols-1 gap-2.5 text-sm">
                        <div className="flex items-start gap-2.5">
                          <Stethoscope className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                          <div>
                            <div className="text-xs text-muted-foreground">Специализация</div>
                            <div>{c.specialization}</div>
                          </div>
                        </div>
                        <div className="flex items-start gap-2.5">
                          <MapPin className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                          <div>
                            <div className="text-xs text-muted-foreground">Адрес</div>
                            <div>
                              {c.city}{c.district ? `, ${c.district}` : ""}
                              {c.address ? `, ${c.address}` : ""}
                            </div>
                            <a
                              href={mapsUrl(c)}
                              target="_blank"
                              rel="noreferrer"
                              className="text-xs text-primary inline-flex items-center gap-1 mt-1 hover:underline"
                            >
                              Показать на карте <ExternalLink className="h-3 w-3" />
                            </a>
                          </div>
                        </div>
                        <div className="flex items-start gap-2.5">
                          <Clock className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                          <div>
                            <div className="text-xs text-muted-foreground">Часы работы</div>
                            <div>{c.priceFrom ? "Пн–Сб 08:00–21:00" : WORK_HOURS["по ОМС"]}</div>
                          </div>
                        </div>
                        <div className="flex items-start gap-2.5">
                          <Phone className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                          <div>
                            <div className="text-xs text-muted-foreground">Телефон</div>
                            {c.phone ? (
                              <a href={`tel:${c.phone.replace(/[^+\d]/g, "")}`} className="text-primary hover:underline">
                                {c.phone}
                              </a>
                            ) : (
                              <div>—</div>
                            )}
                          </div>
                        </div>
                        {c.equipment && (
                          <div className="flex items-start gap-2.5">
                            <Wrench className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                            <div>
                              <div className="text-xs text-muted-foreground">Оборудование и услуги</div>
                              <div>{c.equipment}</div>
                            </div>
                          </div>
                        )}
                        <div className="flex items-start gap-2.5">
                          <Info className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                          <div>
                            <div className="text-xs text-muted-foreground">Стоимость приёма</div>
                            <div className="font-medium">{priceText(c)}</div>
                          </div>
                        </div>
                        <div className="flex items-start gap-2.5">
                          <Star className="h-4 w-4 text-amber-400 fill-amber-400 mt-0.5 shrink-0" />
                          <div>
                            <div className="text-xs text-muted-foreground">Рейтинг и отзывы</div>
                            <div>
                              {c.rating} из 5 · {c.reviewsCount?.toLocaleString("ru-RU")} отзывов
                            </div>
                          </div>
                        </div>
                        {c.hasLicense && (
                          <div className="flex items-start gap-2.5">
                            <BadgeCheck className="h-4 w-4 text-emerald-600 mt-0.5 shrink-0" />
                            <div>
                              <div className="text-xs text-muted-foreground">Лицензия</div>
                              <div className="text-emerald-700">Медицинская лицензия действующая</div>
                            </div>
                          </div>
                        )}
                        <div className="flex items-start gap-2.5">
                          <Globe className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                          <div>
                            <div className="text-xs text-muted-foreground">Источник данных</div>
                            <div>{c.source}</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
          {(data ?? []).length === 0 && (
            <div className="col-span-2 text-center text-muted-foreground py-16">
              По заданным фильтрам клиник не найдено
            </div>
          )}
        </div>
      )}
      </>
      )}
    </div>
  );
}
