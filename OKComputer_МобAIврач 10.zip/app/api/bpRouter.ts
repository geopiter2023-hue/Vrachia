import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { bpEntries, vitals, notifications, auditLog } from "@db/schema";
import { desc, eq, gte } from "drizzle-orm";

export const bpRouter = createRouter({
  list: publicQuery
    .input(z.object({ days: z.number().default(365) }))
    .query(async ({ input }) => {
      const since = new Date(Date.now() - input.days * 864e5);
      return getDb()
        .select()
        .from(bpEntries)
        .where(gte(bpEntries.measuredAt, since))
        .orderBy(desc(bpEntries.measuredAt))
        .limit(1000);
    }),

  add: publicQuery
    .input(
      z.object({
        sys: z.number().int().min(50).max(300),
        dia: z.number().int().min(30).max(200),
        pulse: z.number().int().min(20).max(250).optional(),
        arm: z.enum(["left", "right"]).default("left"),
        wellbeing: z.enum(["none", "great", "good", "ok", "bad"]).default("none"),
        note: z.string().max(1000).optional(),
        measuredAt: z.string(), // ISO
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const at = new Date(input.measuredAt);
      await db.insert(bpEntries).values({
        sys: input.sys,
        dia: input.dia,
        pulse: input.pulse ?? null,
        arm: input.arm,
        wellbeing: input.wellbeing,
        note: input.note || null,
        measuredAt: at,
      });
      // Дублируем в общие физиологические показатели — чтобы работали аналитика и рекомендации
      const rows: (typeof vitals.$inferInsert)[] = [
        { vitalType: "pressure_sys", value: input.sys, measuredAt: at, source: "diary" },
        { vitalType: "pressure_dia", value: input.dia, measuredAt: at, source: "diary" },
      ];
      if (input.pulse) rows.push({ vitalType: "pulse", value: input.pulse, measuredAt: at, source: "diary" });
      await db.insert(vitals).values(rows);
      await db.insert(auditLog).values({
        action: "bp_entry",
        detail: `Дневник давления: ${input.sys}/${input.dia}${input.pulse ? `, пульс ${input.pulse}` : ""}`,
      });
      const { awardPoints } = await import("./botRouter");
      await awardPoints("bp_entry", 5, `${input.sys}/${input.dia}`);
      if (input.sys >= 160 || input.dia >= 100) {
        await db.insert(notifications).values({
          title: "Высокое артериальное давление",
          body: `Запись в дневнике: ${input.sys}/${input.dia} мм рт. ст. — критическое значение.`,
          severity: "critical",
        });
      }
      return { ok: true };
    }),

  remove: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await getDb().delete(bpEntries).where(eq(bpEntries.id, input.id));
      return { ok: true };
    }),

  stats: publicQuery.query(async () => {
    const rows = await getDb()
      .select()
      .from(bpEntries)
      .where(gte(bpEntries.measuredAt, new Date(Date.now() - 90 * 864e5)))
      .orderBy(desc(bpEntries.measuredAt));
    if (!rows.length) return null;
    const avg = (f: (r: (typeof rows)[0]) => number | null) => {
      const vals = rows.map(f).filter((v): v is number => v != null);
      return vals.length ? Math.round(vals.reduce((a, b) => a + b, 0) / vals.length) : null;
    };
    const maxSys = Math.max(...rows.map((r) => r.sys));
    const high = rows.filter((r) => r.sys >= 140 || r.dia >= 90).length;
    return {
      count: rows.length,
      avgSys: avg((r) => r.sys),
      avgDia: avg((r) => r.dia),
      avgPulse: avg((r) => r.pulse),
      maxSys,
      highCount: high,
      highPct: Math.round((high / rows.length) * 100),
    };
  }),
});
