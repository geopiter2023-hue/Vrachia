import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { newsCache, auditLog } from "@db/schema";
import { desc } from "drizzle-orm";

// ── Источники новостей здравоохранения ────────────────────────────────────
// 1) Официальный Минздрав России (несколько вариантов RSS-адресов)
// 2) Резерв: медицинская лента ТАСС (фильтр по ключевым словам)
const MINZDRAV_FEEDS = [
  "https://minzdrav.gov.ru/rss",
  "https://minzdrav.gov.ru/news/rss",
  "https://minzdrav.gov.ru/press/rss",
];
const FALLBACK_FEEDS = [
  { url: "https://tass.ru/rss/v2.xml", source: "ТАСС · Здоровье", filter: true },
  { url: "https://rssexport.rbc.ru/rbcnews/news/30/full.rss", source: "РБК · Здоровье", filter: true },
  { url: "https://ria.ru/export/rss2/index.xml", source: "РИА Новости · Здоровье", filter: true },
  { url: "https://rg.ru/xml/index.xml", source: "РГ · Здоровье", filter: true },
  { url: "https://lenta.ru/rss/news", source: "Lenta.ru · Здоровье", filter: true },
  { url: "https://www.vedomosti.ru/rss/news", source: "Ведомости · Здоровье", filter: true },
];

const HEALTH_RE =
  /здоров|минздрав|медицин|лекарств|вакцин|вирус|врач|больниц|клиник|пациент|препарат|заболев|эпидем|терапи|диагност|фарм/i;

const CACHE_TTL_MS = 30 * 60 * 1000; // 30 минут

type ParsedItem = {
  title: string;
  link: string;
  summary: string;
  publishedAt: string;
};

function stripTags(s: string) {
  return s.replace(/<!\[CDATA\[|\]\]>/g, "").replace(/<[^>]+>/g, "").replace(/\s+/g, " ").trim();
}

function parseRss(xml: string): ParsedItem[] {
  const items: ParsedItem[] = [];
  const blocks = xml.match(/<item[\s\S]*?<\/item>/g) ?? [];
  for (const b of blocks.slice(0, 60)) {
    const get = (tag: string) => {
      const m = b.match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)<\\/${tag}>`));
      return m ? stripTags(m[1]) : "";
    };
    const title = get("title");
    const link = get("link") || get("guid");
    if (!title || !link) continue;
    items.push({
      title: title.slice(0, 450),
      link: link.slice(0, 950),
      summary: get("description").slice(0, 600),
      publishedAt: get("pubDate") || get("published") || "",
    });
  }
  return items;
}

async function fetchFeed(url: string, timeoutMs = 12000): Promise<ParsedItem[]> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      signal: ctrl.signal,
      headers: { "User-Agent": "Mozilla/5.0 (compatible; AIDoctor/1.0)" },
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const text = await res.text();
    if (!text.includes("<item")) throw new Error("not rss");
    return parseRss(text);
  } finally {
    clearTimeout(t);
  }
}

async function refreshNews(): Promise<{ source: string; count: number }> {
  const db = getDb();
  let items: ParsedItem[] = [];
  let source = "";

  for (const url of MINZDRAV_FEEDS) {
    try {
      items = await fetchFeed(url);
      if (items.length) {
        source = "Минздрав России";
        break;
      }
    } catch {
      /* пробуем следующий адрес */
    }
  }

  if (!items.length) {
    // Собираем новости из всех доступных резервных лент, пока не наберём минимум
    const seen = new Set<string>();
    const sources = new Set<string>();
    for (const f of FALLBACK_FEEDS) {
      if (items.length >= 15) break;
      try {
        const all = await fetchFeed(f.url);
        const filtered = f.filter
          ? all.filter((i) => HEALTH_RE.test(i.title + " " + i.summary))
          : all;
        for (const it of filtered) {
          const key = it.title.toLowerCase().slice(0, 60);
          if (seen.has(key)) continue;
          seen.add(key);
          items.push(it);
          sources.add(f.source);
        }
      } catch {
        /* next */
      }
    }
    if (items.length) source = [...sources].slice(0, 2).join(", ") + (sources.size > 2 ? " и др." : "");
  }

  if (!items.length) throw new Error("Все источники новостей недоступны");

  await db.delete(newsCache);
  for (const i of items.slice(0, 40)) {
    await db.insert(newsCache).values({ ...i, source });
  }
  await getDb().insert(auditLog).values({
    action: "sync",
    detail: `Обновлена лента новостей: источник «${source}», новостей: ${items.length}`,
  });
  return { source, count: items.length };
}

export const newsRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    let rows = await db.select().from(newsCache).orderBy(desc(newsCache.fetchedAt)).limit(40);
    const stale =
      rows.length === 0 || Date.now() - new Date(rows[0].fetchedAt).getTime() > CACHE_TTL_MS;
    if (stale) {
      try {
        await refreshNews();
        rows = await db.select().from(newsCache).orderBy(desc(newsCache.fetchedAt)).limit(40);
      } catch {
        /* отдаём кэш как есть */
      }
    }
    return {
      items: rows,
      source: rows[0]?.source ?? null,
      updatedAt: rows[0]?.fetchedAt ?? null,
      stale,
    };
  }),
  refresh: publicQuery.mutation(async () => {
    const r = await refreshNews();
    const rows = await getDb().select().from(newsCache).orderBy(desc(newsCache.fetchedAt)).limit(40);
    return { ...r, items: rows, updatedAt: rows[0]?.fetchedAt ?? null };
  }),
});
