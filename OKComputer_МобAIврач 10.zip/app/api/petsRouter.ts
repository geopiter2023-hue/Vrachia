import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { pets, petEvents, auditLog } from "@db/schema";
import { eq, desc } from "drizzle-orm";

async function log(action: string, detail: string) {
  await getDb().insert(auditLog).values({ action, detail });
}

export const petsRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    const ps = await db.select().from(pets).orderBy(desc(pets.createdAt));
    const evs = await db.select().from(petEvents).orderBy(desc(petEvents.eventDate));
    return ps.map((p) => ({
      ...p,
      events: evs.filter((e) => e.petId === Number(p.id)),
    }));
  }),

  create: publicQuery
    .input(
      z.object({
        name: z.string().min(1),
        species: z.enum(["dog", "cat", "bird", "rodent", "other"]),
        breed: z.string().optional(),
        sex: z.enum(["male", "female"]).default("male"),
        birthDate: z.string().optional(),
        weightKg: z.number().optional(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const res = await getDb().insert(pets).values({
        name: input.name,
        species: input.species,
        breed: input.breed,
        sex: input.sex,
        birthDate: input.birthDate || null,
        weightKg: input.weightKg,
        notes: input.notes,
      });
      await log("pet", `Добавлен питомец «${input.name}» (${input.species})`);
      return { id: Number(res[0].insertId) };
    }),

  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        name: z.string().min(1),
        species: z.enum(["dog", "cat", "bird", "rodent", "other"]),
        breed: z.string().optional(),
        sex: z.enum(["male", "female"]),
        birthDate: z.string().optional(),
        weightKg: z.number().optional(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      await getDb()
        .update(pets)
        .set({
          name: input.name,
          species: input.species,
          breed: input.breed,
          sex: input.sex,
          birthDate: input.birthDate || null,
          weightKg: input.weightKg,
          notes: input.notes,
        })
        .where(eq(pets.id, input.id));
      await log("pet", `Обновлён профиль питомца «${input.name}»`);
      return { ok: true };
    }),

  remove: publicQuery.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
    const db = getDb();
    await db.delete(petEvents).where(eq(petEvents.petId, input.id));
    await db.delete(pets).where(eq(pets.id, input.id));
    await log("pet", `Удалён питомец #${input.id}`);
    return { ok: true };
  }),

  addEvent: publicQuery
    .input(
      z.object({
        petId: z.number(),
        eventType: z.enum(["visit", "vaccine", "analysis", "procedure", "note"]),
        title: z.string().min(1),
        eventDate: z.string(),
        detail: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      await getDb().insert(petEvents).values(input);
      await log("pet_event", `Событие для питомца #${input.petId}: ${input.title} (${input.eventDate})`);
      return { ok: true };
    }),

  removeEvent: publicQuery.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
    await getDb().delete(petEvents).where(eq(petEvents.id, input.id));
    return { ok: true };
  }),
});
