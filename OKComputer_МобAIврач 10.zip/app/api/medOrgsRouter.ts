import { z } from "zod";
import zlib from "node:zlib";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { medOrgs } from "@db/schema";
import { and, asc, eq, like, or, sql } from "drizzle-orm";
import { MED_ORGS_B64 } from "./medOrgsData";

const PAGE = 50;

// --- Автозагрузка базы учреждений, если таблица отсутствует/пуста ---
let seedState: "idle" | "running" | "done" | "failed" = "idle";

type SeedRow = [
  string | null, string | null, string | null, string | null, string | null,
  string | null, number | null, number | null, string | null, string | null,
  string | null, string | null, string | null, string | null, string | null,
];

function decodeSeed(): SeedRow[] {
  const buf = Buffer.from(MED_ORGS_B64, "base64");
  const json = zlib.gunzipSync(buf).toString("utf8");
  return JSON.parse(json) as SeedRow[];
}

async function ensureSeeded(): Promise<void> {
  if (seedState === "running" || seedState === "done") return;
  seedState = "running";
  try {
    const db = getDb();
    await db.execute(sql.raw(`CREATE TABLE IF NOT EXISTS med_orgs (
      id bigint unsigned NOT NULL AUTO_INCREMENT,
      category varchar(64),
      subtype varchar(128),
      name varchar(255),
      services text,
      specialties text,
      address varchar(512),
      lat double,
      lon double,
      phone varchar(128),
      phone2 varchar(128),
      email varchar(255),
      website varchar(512),
      opening_hours varchar(512),
      operator varchar(255),
      info text,
      PRIMARY KEY (id),
      KEY idx_cat (category),
      KEY idx_name (name)
    )`));
    const [cnt] = await db.select({ n: sql<number>`count(*)` }).from(medOrgs);
    if (Number(cnt?.n ?? 0) < 50000) {
      await db.delete(medOrgs);
      const rows = decodeSeed();
      for (let i = 0; i < rows.length; i += 400) {
        const batch = rows.slice(i, i + 400).map((r) => ({
          category: r[0] ?? "Прочие медучреждения", subtype: r[1], name: r[2] ?? "-", services: r[3],
          specialties: r[4], address: r[5], lat: r[6], lon: r[7],
          phone: r[8], phone2: r[9], email: r[10], website: r[11],
          openingHours: r[12], operator: r[13], info: r[14],
        }));
        await db.insert(medOrgs).values(batch);
      }
    }
    seedState = "done";
  } catch (e) {
    seedState = "failed";
    console.error("med_orgs seed failed:", e);
  }
}

export const medOrgsRouter = createRouter({
  // Сводка по категориям (кол-во учреждений)
  stats: publicQuery.query(async () => {
    const db = getDb();
    if (seedState === "running") return { total: 0, byCategory: [], seeding: true };
    try {
      const rows = await db
        .select({ category: medOrgs.category, count: sql<number>`count(*)` })
        .from(medOrgs)
        .groupBy(medOrgs.category)
        .orderBy(sql`count(*) desc`);
      const total = rows.reduce((s, r) => s + Number(r.count), 0);
      return { total, byCategory: rows.map((r) => ({ category: r.category, count: Number(r.count) })), seeding: false };
    } catch {
      // Таблица ещё не создана в этой базе — запускаем фоновую загрузку
      void ensureSeeded();
      return { total: 0, byCategory: [], seeding: true };
    }
  }),

  // Постраничная выдача с фильтрами — без нагрузки на клиент
  list: publicQuery
    .input(
      z.object({
        category: z.string().optional(),
        q: z.string().optional(),
        limit: z.number().min(1).max(200).default(PAGE),
        offset: z.number().min(0).default(0),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      if (seedState === "running") return { items: [], total: 0, seeding: true };
      const conds = [];
      if (input.category) conds.push(eq(medOrgs.category, input.category));
      const q = input.q?.trim();
      if (q) {
        const pat = `%${q}%`;
        conds.push(
          or(
            like(medOrgs.name, pat),
            like(medOrgs.address, pat),
            like(medOrgs.operator, pat),
            like(medOrgs.specialties, pat)
          )
        );
      }
      const where = conds.length ? and(...conds) : undefined;
      try {
        const rows = await db
          .select()
          .from(medOrgs)
          .where(where)
          .orderBy(asc(medOrgs.name))
          .limit(input.limit)
          .offset(input.offset);
        const [cnt] = await db
          .select({ count: sql<number>`count(*)` })
          .from(medOrgs)
          .where(where);
        return { items: rows, total: Number(cnt?.count ?? 0), seeding: false };
      } catch {
        void ensureSeeded();
        return { items: [], total: 0, seeding: true };
      }
    }),
});
