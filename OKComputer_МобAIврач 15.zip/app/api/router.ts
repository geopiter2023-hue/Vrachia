import { createRouter, publicQuery } from "./middleware";
import { healthRouter } from "./healthRouter";
import { petsRouter } from "./petsRouter";
import { newsRouter } from "./newsRouter";
import { familyRouter } from "./familyRouter";
import { bpRouter } from "./bpRouter";
import { medOrgsRouter } from "./medOrgsRouter";
import { aiDoctorRouter } from "./aiDoctorRouter";
import { wellnessRouter } from "./wellnessRouter";
import { botRouter } from "./botRouter";
import { coachRouter } from "./coachRouter";
import { authRouter } from "./authRouter";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  health: healthRouter,
  pets: petsRouter,
  news: newsRouter,
  family: familyRouter,
  bp: bpRouter,
  medOrgs: medOrgsRouter,
  aiDoctor: aiDoctorRouter,
  wellness: wellnessRouter,
  bot: botRouter,
  coach: coachRouter,
});

export type AppRouter = typeof appRouter;
