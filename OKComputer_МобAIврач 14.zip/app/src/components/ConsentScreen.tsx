import { useEffect, useState } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { ShieldCheck, FileText, ScrollText, AlertTriangle } from "lucide-react";
import { trpc } from "@/providers/trpc";

const KEY = "ai-vrach-consent-v1";
const CONSENT_VERSION = "1.0";

export function hasConsent(): boolean {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return false;
    return JSON.parse(raw).version === CONSENT_VERSION;
  } catch {
    return false;
  }
}

export default function ConsentScreen() {
  const [open, setOpen] = useState(false);
  const [checks, setChecks] = useState({ pdn: false, special: false, cross: false, age: false, notMedical: false });
  const recordMut = trpc.health.recordConsent.useMutation();

  useEffect(() => {
    if (!hasConsent()) setOpen(true);
  }, []);

  const all = Object.values(checks).every(Boolean);

  const accept = () => {
    const payload = { version: CONSENT_VERSION, at: new Date().toISOString() };
    try {
      localStorage.setItem(KEY, JSON.stringify(payload));
    } catch { /* ignore */ }
    recordMut.mutate(payload);
    setOpen(false);
  };

  const Item = ({ id, children }: { id: keyof typeof checks; children: React.ReactNode }) => (
    <label className="flex items-start gap-3 cursor-pointer rounded-lg border p-3 hover:bg-accent/50 transition-colors">
      <Checkbox
        checked={checks[id]}
        onCheckedChange={(v) => setChecks((c) => ({ ...c, [id]: Boolean(v) }))}
        className="mt-0.5"
      />
      <span className="text-sm leading-snug">{children}</span>
    </label>
  );

  return (
    <Dialog open={open}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto" showCloseButton={false}
        onInteractOutside={(e) => e.preventDefault()} onEscapeKeyDown={(e) => e.preventDefault()}>
        <div className="flex items-center gap-3">
          <div className="h-11 w-11 rounded-xl bg-teal-100 dark:bg-teal-950 flex items-center justify-center shrink-0">
            <ShieldCheck className="h-6 w-6 text-teal-600" />
          </div>
          <div>
            <h2 className="font-bold text-lg leading-tight">Согласие на обработку данных</h2>
            <p className="text-xs text-muted-foreground">Требуется по ФЗ-152 «О персональных данных» и ФЗ-323 «Об охране здоровья»</p>
          </div>
        </div>

        <div className="rounded-lg bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 p-3 flex items-start gap-2.5">
          <AlertTriangle className="h-4 w-4 text-amber-600 shrink-0 mt-0.5" />
          <p className="text-xs text-amber-800 dark:text-amber-300 leading-relaxed">
            «AI Врач» — информационный сервис. Он <b>не является медицинской организацией</b>, не оказывает медицинские
            услуги и не ставит диагнозы. Все материалы носят ознакомительный характер. По вопросам лечения обращайтесь к врачу.
          </p>
        </div>

        <div className="space-y-2">
          <Item id="pdn">
            Я даю согласие на обработку моих персональных данных (ФИО, контакты, данные документов)
            в целях работы сервиса (ст. 6, 9 ФЗ-152).
          </Item>
          <Item id="special">
            Я даю согласие на обработку <b>специальной категории персональных данных — сведений о моём здоровье</b>
            (результаты анализов, давление, жалобы), включая сведения, составляющие врачебную тайну (ст. 10 ФЗ-152, ст. 13 ФЗ-323),
            исключительно для отображения моей медицинской истории мне.
          </Item>
          <Item id="cross">
            Я уведомлён(а) и согласен(на), что данные могут обрабатываться на серверах за пределами РФ
            (трансграничная передача, ст. 12 ФЗ-152) и при использовании Telegram-бота — передаваться через инфраструктуру Telegram.
          </Item>
          <Item id="age">Мне исполнилось 18 лет.</Item>
          <Item id="notMedical">
            Я понимаю, что сервис не заменяет консультацию врача, и обязуюсь не откладывать обращение за
            медицинской помощью на основании информации из приложения.
          </Item>
        </div>

        <Button className="w-full h-11" disabled={!all} onClick={accept}>
          Принимаю условия и начинаю
        </Button>

        <div className="flex justify-center gap-4 text-xs">
          <a href="/legal/privacy" target="_blank" className="text-primary inline-flex items-center gap-1 hover:underline">
            <FileText className="h-3 w-3" /> Политика конфиденциальности
          </a>
          <a href="/legal/terms" target="_blank" className="text-primary inline-flex items-center gap-1 hover:underline">
            <ScrollText className="h-3 w-3" /> Пользовательское соглашение
          </a>
        </div>
      </DialogContent>
    </Dialog>
  );
}
