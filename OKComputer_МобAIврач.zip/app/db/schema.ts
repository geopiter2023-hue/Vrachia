import {
  mysqlTable,
  mysqlEnum,
  serial,
  bigint,
  varchar,
  text,
  longtext,
  double,
  int,
  timestamp,
  date,
  boolean,
} from "drizzle-orm/mysql-core";

// ── Медицинские документы (анализы, выписки, заключения) ──────────────────
export const documents = mysqlTable("documents", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  docType: mysqlEnum("doc_type", [
    "analysis", // результат анализа
    "conclusion", // заключение врача
    "discharge", // выписка
    "instrumental", // УЗИ/МРТ/КТ протокол
    "complaint", // жалобы
    "anamnesis", // анамнез
    "other",
  ])
    .notNull()
    .default("other"),
  docDate: date("doc_date", { mode: "string" }).notNull(),
  source: varchar("source", { length: 255 }), // лаборатория / клиника
  fileName: varchar("file_name", { length: 255 }),
  fileMime: varchar("file_mime", { length: 120 }),
  fileData: longtext("file_data"), // base64 исходного файла
  content: text("content"), // извлечённый / введённый текст
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ── Справочник биомаркеров ────────────────────────────────────────────────
export const biomarkers = mysqlTable("biomarkers", {
  id: serial("id").primaryKey(),
  code: varchar("code", { length: 32 }).notNull().unique(), // HGB, CHOL...
  name: varchar("name", { length: 255 }).notNull(),
  unit: varchar("unit", { length: 32 }).notNull(),
  refLow: double("ref_low"),
  refHigh: double("ref_high"),
  category: varchar("category", { length: 64 }).notNull(), // Общий анализ крови, Биохимия...
});

// ── Измерения биомаркеров ─────────────────────────────────────────────────
export const measurements = mysqlTable("measurements", {
  id: serial("id").primaryKey(),
  biomarkerId: bigint("biomarker_id", { mode: "number", unsigned: true }).notNull(),
  documentId: bigint("document_id", { mode: "number", unsigned: true }),
  value: double("value").notNull(),
  measuredAt: date("measured_at", { mode: "string" }).notNull(),
  note: varchar("note", { length: 500 }),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ── Физиологические показатели (давление, пульс, температура, вес) ───────
export const vitals = mysqlTable("vitals", {
  id: serial("id").primaryKey(),
  vitalType: mysqlEnum("vital_type", [
    "pressure_sys",
    "pressure_dia",
    "pulse",
    "temperature",
    "weight",
    "spo2",
  ]).notNull(),
  value: double("value").notNull(),
  measuredAt: timestamp("measured_at").notNull(),
  source: varchar("source", { length: 64 }).notNull().default("manual"), // manual / tracker / iot
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ── Клиники и врачи ───────────────────────────────────────────────────────
export const clinics = mysqlTable("clinics", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  city: varchar("city", { length: 64 }).notNull(),
  district: varchar("district", { length: 128 }),
  address: varchar("address", { length: 255 }),
  specialization: varchar("specialization", { length: 128 }).notNull(),
  priceFrom: double("price_from"), // цена приёма от, руб.
  rating: double("rating"),
  reviewsCount: bigint("reviews_count", { mode: "number" }),
  phone: varchar("phone", { length: 32 }),
  hasLicense: boolean("has_license").notNull().default(true),
  equipment: varchar("equipment", { length: 255 }),
  source: varchar("source", { length: 64 }), // агрегатор-источник
});

// ── Уведомления и напоминания ─────────────────────────────────────────────
export const notifications = mysqlTable("notifications", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  body: text("body"),
  severity: mysqlEnum("severity", ["info", "warning", "critical"])
    .notNull()
    .default("info"),
  isRead: boolean("is_read").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ── Журнал действий (Audit Log) ───────────────────────────────────────────
export const auditLog = mysqlTable("audit_log", {
  id: serial("id").primaryKey(),
  action: varchar("action", { length: 64 }).notNull(), // upload / ai_query / export / ...
  detail: text("detail"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ── Питомцы ───────────────────────────────────────────────────────────────
export const pets = mysqlTable("pets", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 64 }).notNull(),
  species: mysqlEnum("species", ["dog", "cat", "bird", "rodent", "other"]).notNull(),
  breed: varchar("breed", { length: 128 }),
  sex: mysqlEnum("sex", ["male", "female"]).notNull().default("male"),
  birthDate: date("birth_date", { mode: "string" }),
  weightKg: double("weight_kg"),
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ── События здоровья питомца (визиты, прививки, анализы) ─────────────────
export const petEvents = mysqlTable("pet_events", {
  id: serial("id").primaryKey(),
  petId: bigint("pet_id", { mode: "number", unsigned: true }).notNull(),
  eventType: mysqlEnum("event_type", ["visit", "vaccine", "analysis", "procedure", "note"]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  eventDate: date("event_date", { mode: "string" }).notNull(),
  detail: text("detail"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ── Кэш новостей (Минздрав / медицинские источники) ──────────────────────
export const newsCache = mysqlTable("news_cache", {
  id: serial("id").primaryKey(),
  source: varchar("source", { length: 128 }).notNull(),
  title: varchar("title", { length: 500 }).notNull(),
  link: varchar("link", { length: 1000 }).notNull(),
  summary: text("summary"),
  publishedAt: varchar("published_at", { length: 64 }),
  fetchedAt: timestamp("fetched_at").notNull().defaultNow(),
});

// ── Члены семьи ───────────────────────────────────────────────────────────
export const familyMembers = mysqlTable("family_members", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 128 }).notNull(),
  relation: varchar("relation", { length: 32 }).notNull(), // mother / father / son / daughter / spouse / grandmother / grandfather / other
  sex: mysqlEnum("sex", ["male", "female"]).notNull().default("male"),
  birthDate: date("birth_date", { mode: "string" }),
  bloodType: varchar("blood_type", { length: 24 }),
  notes: text("notes"), // хронические заболевания, аллергии
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ── Документы члена семьи ─────────────────────────────────────────────────
export const familyDocuments = mysqlTable("family_documents", {
  id: serial("id").primaryKey(),
  memberId: bigint("member_id", { mode: "number", unsigned: true }).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  docType: mysqlEnum("doc_type", ["analysis", "conclusion", "discharge", "instrumental", "vaccine", "other"])
    .notNull()
    .default("other"),
  docDate: date("doc_date", { mode: "string" }).notNull(),
  source: varchar("source", { length: 255 }),
  content: text("content"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ── Измерения биомаркеров члена семьи ─────────────────────────────────────
export const familyMeasurements = mysqlTable("family_measurements", {
  id: serial("id").primaryKey(),
  memberId: bigint("member_id", { mode: "number", unsigned: true }).notNull(),
  biomarkerId: bigint("biomarker_id", { mode: "number", unsigned: true }).notNull(),
  documentId: bigint("document_id", { mode: "number", unsigned: true }),
  value: double("value").notNull(),
  measuredAt: date("measured_at", { mode: "string" }).notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type FamilyMember = typeof familyMembers.$inferSelect;
export type FamilyDocument = typeof familyDocuments.$inferSelect;
export type FamilyMeasurement = typeof familyMeasurements.$inferSelect;

export type Pet = typeof pets.$inferSelect;
export type PetEvent = typeof petEvents.$inferSelect;
export type NewsItem = typeof newsCache.$inferSelect;

// Файлы документов — чанки base64 (обход лимита размера строки в БД)
export const documentFiles = mysqlTable("document_files", {
  docId: bigint("doc_id", { mode: "number", unsigned: true }).notNull(),
  chunk: int("chunk").notNull(),
  data: longtext("data").notNull(),
});
export type Document = typeof documents.$inferSelect;
export type Biomarker = typeof biomarkers.$inferSelect;
export type Measurement = typeof measurements.$inferSelect;
export type Vital = typeof vitals.$inferSelect;
export type Clinic = typeof clinics.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
export type AuditEntry = typeof auditLog.$inferSelect;

// ── Дневник артериального давления ───────────────────────────────────────
export const bpEntries = mysqlTable("bp_entries", {
  id: serial("id").primaryKey(),
  sys: int("sys").notNull(), // систолическое, мм рт. ст.
  dia: int("dia").notNull(), // диастолическое
  pulse: int("pulse"), // уд/мин, необязательно
  arm: mysqlEnum("arm", ["left", "right"]).notNull().default("left"),
  wellbeing: mysqlEnum("wellbeing", ["none", "great", "good", "ok", "bad"])
    .notNull()
    .default("none"),
  note: text("note"),
  measuredAt: timestamp("measured_at").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type BpEntry = typeof bpEntries.$inferSelect;
