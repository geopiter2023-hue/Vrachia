import { useMemo, useState } from "react";
import { trpc } from "@/providers/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import {
  HeartPulse,
  Plus,
  X,
  Check,
  Trash2,
  ChevronRight,
  ClipboardList,
  BarChart3,
  NotebookText,
} from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  ReferenceLine,
} from "recharts";

// ── Цвет по классификации АД (ESC/ESH) ──
function bpColor(sys: number, dia: number): string {
  if (sys >= 160 || dia >= 100) return "#f43f5e"; // гипертония 2 ст. — красный
  if (sys >= 140 || dia >= 90) return "#fb923c"; // гипертония 1 ст. — оранжевый
  if (sys >= 130 || dia >= 85) return "#fbbf24"; // высокое нормальное — жёлтый
  if (sys < 90 || dia < 60) return "#38bdf8"; // пониженное — голубой
  return "#34d399"; // норма — зелёный
}
function bpLabel(sys: number, dia: number): string {
  if (sys >= 160 || dia >= 100) return "Гипертония 2 ст.";
  if (sys >= 140 || dia >= 90) return "Гипертония 1 ст.";
  if (sys >= 130 || dia >= 85) return "Высокое нормальное";
  if (sys < 90 || dia < 60) return "Пониженное";
  return "Норма";
}

const WELLBEING = [
  { key: "none", label: "Не хочу указывать" },
  { key: "great", label: "Отличное" },
  { key: "good", label: "Хорошее" },
  { key: "ok", label: "Сносное" },
  { key: "bad", label: "Плохое" },
] as const;

const MONTHS_SHORT = ["Янв.", "Февр.", "Марта", "Апр.", "Мая", "Июня", "Июля", "Авг.", "Сент.", "Окт.", "Нояб.", "Дек."];

type Entry = {
  id: number;
  sys: number;
  dia: number;
  pulse: number | null;
  arm: "left" | "right";
  wellbeing: "none" | "great" | "good" | "ok" | "bad";
  note: string | null;
  measuredAt: string | Date;
};

// ── Колесо выбора числа (как в референсе) ──
function NumberWheel({
  value, min, max, onChange,
}: { value: number; min: number; max: number; onChange: (v: number) => void }) {
  const nums = [];
  for (let i = min; i <= max; i++) nums.push(i);
  return (
    <div
      style={{
        height: 132, overflowY: "auto", scrollbarWidth: "none",
        scrollSnapType: "y mandatory", textAlign: "center",
      }}
      onScroll={(e) => {
        const el = e.currentTarget;
        const idx = Math.round(el.scrollTop / 44);
        const v = Math.min(max, Math.max(min, min + idx));
        if (v !== value) onChange(v);
      }}
      ref={(el) => {
        if (el) el.scrollTop = (value - min) * 44;
      }}
    >
      {nums.map((n) => (
        <div
          key={n}
          onClick={(e) => {
            onChange(n);
            e.currentTarget.parentElement?.scrollTo({ top: (n - min) * 44, behavior: "smooth" });
          }}
          style={{
            height: 44, lineHeight: "44px", scrollSnapAlign: "center",
            fontSize: n === value ? 26 : 20,
            fontWeight: n === value ? 700 : 400,
            color: n === value ? "#0f766e" : "#a1a1aa",
            background: n === value ? "#f0fdfa" : "transparent",
            borderRadius: 12, cursor: "pointer",
          }}
        >
          {n}
        </div>
      ))}
    </div>
  );
}

// ── Форма новой записи ──
function EntrySheet({ onClose }: { onClose: () => void }) {
  const utils = trpc.useUtils();
  const now = new Date();
  const [sys, setSys] = useState(120);
  const [dia, setDia] = useState(80);
  const [pulse, setPulse] = useState(70);
  const [arm, setArm] = useState<"left" | "right">("left");
  const [wellbeing, setWellbeing] = useState<(typeof WELLBEING)[number]["key"]>("none");
  const [note, setNote] = useState("");
  const [time, setTime] = useState(
    `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`
  );
  const [step, setStep] = useState<null | "sys" | "dia" | "pulse" | "wellbeing">(null);

  const addMut = trpc.bp.add.useMutation({
    onSuccess: () => {
      toast.success("Запись добавлена в дневник");
      utils.bp.list.invalidate();
      utils.bp.stats.invalidate();
      utils.health.vitals.list.invalidate();
      onClose();
    },
    onError: () => toast.error("Не удалось сохранить запись"),
  });

  const save = () => {
    const [h, m] = time.split(":").map(Number);
    const at = new Date();
    at.setHours(h, m, 0, 0);
    addMut.mutate({ sys, dia, pulse, arm, wellbeing, note: note || undefined, measuredAt: at.toISOString() });
  };

  const Row = ({ label, val, s }: { label: string; val: string; s: "sys" | "dia" | "pulse" }) => (
    <div>
      <button
        onClick={() => setStep(step === s ? null : s)}
        className="w-full flex items-center justify-between py-3"
        style={{ borderBottom: step === s ? "none" : "1px solid #f1f5f9" }}
      >
        <span style={{ fontSize: 15, color: step === s ? "#0d9488" : "#0f172a", fontWeight: step === s ? 600 : 400 }}>
          {label}
        </span>
        <span style={{ fontSize: 20, fontWeight: 600, color: "#0d9488" }}>{val}</span>
      </button>
      {step === s && (
        <div style={{ borderBottom: "1px solid #f1f5f9" }}>
          <NumberWheel
            value={s === "sys" ? sys : s === "dia" ? dia : pulse}
            min={s === "sys" ? 60 : s === "dia" ? 40 : 30}
            max={s === "sys" ? 260 : s === "dia" ? 180 : 220}
            onChange={(v) => (s === "sys" ? setSys(v) : s === "dia" ? setDia(v) : setPulse(v))}
          />
        </div>
      )}
    </div>
  );

  return (
    <div
      onClick={onClose}
      style={{ position: "fixed", inset: 0, zIndex: 90, background: "rgba(0,0,0,0.5)", display: "flex", alignItems: "flex-end", justifyContent: "center" }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          width: "100%", maxWidth: 430, maxHeight: "92vh", overflowY: "auto",
          background: "#fff", borderRadius: "24px 24px 0 0", padding: "16px 18px 28px",
        }}
      >
        {/* Шапка */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
          <button onClick={onClose} style={{ width: 38, height: 38, borderRadius: "50%", border: "1px solid #e2e8f0", background: "none", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" }}>
            <X style={{ width: 18, height: 18 }} />
          </button>
          <b style={{ fontSize: 17 }}>Запись</b>
          <button
            onClick={save}
            disabled={addMut.isPending}
            style={{ width: 38, height: 38, borderRadius: "50%", border: "none", background: "#0d9488", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" }}
          >
            <Check style={{ width: 18, height: 18 }} />
          </button>
        </div>

        {/* Время */}
        <div className="rounded-2xl border px-4 py-3 mb-3 flex items-center justify-between">
          <span className="text-sm">Время</span>
          <input
            type="time"
            value={time}
            onChange={(e) => setTime(e.target.value)}
            className="text-lg font-semibold text-primary bg-transparent outline-none"
          />
        </div>

        {/* Рука */}
        <div className="rounded-2xl border px-4 py-3 mb-3 flex items-center justify-between">
          <span className="text-sm">Рука</span>
          <div className="flex gap-1.5">
            {(["left", "right"] as const).map((a) => (
              <button
                key={a}
                onClick={() => setArm(a)}
                className={
                  "text-xs rounded-full px-3 py-1.5 font-medium " +
                  (arm === a ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground")
                }
              >
                {a === "left" ? "Левая" : "Правая"}
              </button>
            ))}
          </div>
        </div>

        {/* Значения */}
        <div className="rounded-2xl border px-4 py-1 mb-3">
          <Row label="Систолическое" val={String(sys)} s="sys" />
          <Row label="Диастолическое" val={String(dia)} s="dia" />
          <Row label="Пульс" val={String(pulse)} s="pulse" />
          <div className="py-2.5 text-center text-xs font-medium" style={{ color: bpColor(sys, dia) }}>
            {bpLabel(sys, dia)}
          </div>
        </div>

        {/* Самочувствие */}
        <div className="rounded-2xl border px-4 py-2 mb-3">
          <button
            onClick={() => setStep(step === "wellbeing" ? null : "wellbeing")}
            className="w-full flex items-center justify-between py-2"
          >
            <span className="text-sm">Самочувствие</span>
            <span className="flex items-center gap-1 text-sm text-primary font-medium">
              {WELLBEING.find((w) => w.key === wellbeing)?.label}
              <ChevronRight className="h-4 w-4" style={{ transform: step === "wellbeing" ? "rotate(90deg)" : "none" }} />
            </span>
          </button>
          {step === "wellbeing" && (
            <div className="pb-2">
              {WELLBEING.map((w) => (
                <button
                  key={w.key}
                  onClick={() => { setWellbeing(w.key); setStep(null); }}
                  className="w-full flex items-center justify-between py-2.5 text-sm border-t first:border-t-0"
                  style={{ borderColor: "#f1f5f9" }}
                >
                  {w.label}
                  {wellbeing === w.key && <Check className="h-4 w-4 text-primary" />}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Примечание */}
        <textarea
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="Примечание"
          rows={3}
          className="w-full rounded-2xl border px-4 py-3 text-sm outline-none resize-none"
        />
      </div>
    </div>
  );
}

// ── Основная страница ──
export default function PressureDiaryPage() {
  const { data, isLoading } = trpc.bp.list.useQuery({ days: 365 });
  const { data: stats } = trpc.bp.stats.useQuery();
  const utils = trpc.useUtils();
  const [tab, setTab] = useState<"diary" | "chart" | "report">("diary");
  const [showAdd, setShowAdd] = useState(false);

  const removeMut = trpc.bp.remove.useMutation({
    onSuccess: () => {
      utils.bp.list.invalidate();
      utils.bp.stats.invalidate();
      toast.success("Запись удалена");
    },
  });

  const entries = (data ?? []) as Entry[];

  const chartData = useMemo(
    () =>
      [...entries]
        .sort((a, b) => new Date(a.measuredAt).getTime() - new Date(b.measuredAt).getTime())
        .slice(-60)
        .map((e) => ({
          date: new Date(e.measuredAt).toLocaleDateString("ru-RU", { day: "numeric", month: "short" }),
          SYS: e.sys,
          DIA: e.dia,
          Пульс: e.pulse,
        })),
    [entries]
  );

  return (
    <div className="space-y-4">
      {/* Шапка */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl md:text-2xl font-bold flex items-center gap-2">
            <HeartPulse className="h-6 w-6 text-rose-500" /> Дневник давления
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            Контроль АД и пульса по классификации ESC/ESH
          </p>
        </div>
        <button
          onClick={() => setShowAdd(true)}
          style={{
            width: 44, height: 44, borderRadius: "50%", border: "none",
            background: "#0d9488", color: "#fff", display: "flex",
            alignItems: "center", justifyContent: "center", cursor: "pointer",
            boxShadow: "0 4px 12px rgba(13,148,136,0.35)",
          }}
        >
          <Plus style={{ width: 22, height: 22 }} />
        </button>
      </div>

      {/* Статистика */}
      {stats && (
        <div className="grid grid-cols-3 gap-2">
          <Card><CardContent className="p-3 text-center">
            <div className="text-lg font-bold">{stats.avgSys}/{stats.avgDia}</div>
            <div className="text-[10px] text-muted-foreground">среднее АД · 90 дн</div>
          </CardContent></Card>
          <Card><CardContent className="p-3 text-center">
            <div className="text-lg font-bold">{stats.avgPulse ?? "—"}</div>
            <div className="text-[10px] text-muted-foreground">средний пульс</div>
          </CardContent></Card>
          <Card><CardContent className="p-3 text-center">
            <div className="text-lg font-bold" style={{ color: stats.highPct > 25 ? "#fb923c" : "#34d399" }}>
              {stats.highPct}%
            </div>
            <div className="text-[10px] text-muted-foreground">записей ≥140/90</div>
          </CardContent></Card>
        </div>
      )}

      {/* Вкладки */}
      <div
        style={{
          display: "flex", gap: 4, background: "#f1f5f9",
          borderRadius: 14, padding: 4,
        }}
      >
        {([
          { key: "diary", label: "Дневник", icon: NotebookText },
          { key: "chart", label: "График", icon: BarChart3 },
          { key: "report", label: "Отчёт", icon: ClipboardList },
        ] as const).map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            style={{
              flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: 5,
              padding: "8px 0", borderRadius: 11, border: "none", cursor: "pointer",
              fontSize: 13, fontWeight: 600,
              background: tab === t.key ? "#fff" : "transparent",
              color: tab === t.key ? "#0d9488" : "#71717a",
              boxShadow: tab === t.key ? "0 1px 3px rgba(0,0,0,0.08)" : "none",
            }}
          >
            <t.icon style={{ width: 15, height: 15 }} /> {t.label}
          </button>
        ))}
      </div>

      {isLoading ? (
        <div className="space-y-2">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-16" />)}</div>
      ) : tab === "diary" ? (
        /* ─── Дневник ─── */
        entries.length === 0 ? (
          <Card><CardContent className="py-14 text-center space-y-2">
            <div className="text-sm font-medium">Записей пока нет</div>
            <p className="text-xs text-muted-foreground">Нажмите «+», чтобы добавить первое измерение давления</p>
          </CardContent></Card>
        ) : (
          <div className="space-y-2">
            {entries.map((e) => {
              const d = new Date(e.measuredAt);
              const cSys = bpColor(e.sys, e.dia);
              const cDia = bpColor(e.sys, e.dia);
              return (
                <div key={e.id} className="flex items-stretch gap-2.5">
                  {/* Дата */}
                  <div
                    style={{
                      width: 74, borderRadius: 14, background: "#f0fdfa",
                      display: "flex", flexDirection: "column", alignItems: "center",
                      justifyContent: "center", padding: "8px 4px", flexShrink: 0,
                    }}
                  >
                    <span style={{ fontSize: 22, fontWeight: 800, color: "#0f766e", lineHeight: 1 }}>{d.getDate()}</span>
                    <span style={{ fontSize: 10, color: "#0f766e", fontWeight: 600 }}>{MONTHS_SHORT[d.getMonth()]}</span>
                    <span style={{ fontSize: 10, color: "#5eead4" }}>
                      {String(d.getHours()).padStart(2, "0")}:{String(d.getMinutes()).padStart(2, "0")}
                    </span>
                  </div>
                  {/* SYS / DIA / Пульс */}
                  <div className="flex-1 flex gap-2">
                    <div
                      style={{
                        flex: 1, borderRadius: 14, background: "#fff", border: "1px solid #f1f5f9",
                        borderRight: `4px solid ${cSys}`, padding: "8px 10px",
                      }}
                    >
                      <div style={{ fontSize: 9, color: "#a1a1aa", fontWeight: 700, letterSpacing: 1 }}>SYS</div>
                      <div style={{ fontSize: 24, fontWeight: 800, lineHeight: 1.1 }}>{e.sys}</div>
                    </div>
                    <div
                      style={{
                        flex: 1, borderRadius: 14, background: "#fff", border: "1px solid #f1f5f9",
                        borderRight: `4px solid ${cDia}`, padding: "8px 10px",
                      }}
                    >
                      <div style={{ fontSize: 9, color: "#a1a1aa", fontWeight: 700, letterSpacing: 1 }}>DIA</div>
                      <div style={{ fontSize: 24, fontWeight: 800, lineHeight: 1.1 }}>{e.dia}</div>
                    </div>
                    {e.pulse != null && (
                      <div
                        style={{
                          flex: 1, borderRadius: 14, background: "#fff", border: "1px solid #f1f5f9",
                          borderRight: "4px solid #c4b5fd", padding: "8px 10px",
                        }}
                      >
                        <div style={{ fontSize: 9, color: "#a1a1aa", fontWeight: 700, letterSpacing: 1 }}>ПУЛЬС</div>
                        <div style={{ fontSize: 24, fontWeight: 800, lineHeight: 1.1 }}>{e.pulse}</div>
                      </div>
                    )}
                  </div>
                  {/* Удалить */}
                  <button
                    onClick={() => removeMut.mutate({ id: e.id })}
                    style={{
                      border: "none", background: "none", cursor: "pointer",
                      color: "#d4d4d8", padding: 4, alignSelf: "center",
                    }}
                  >
                    <Trash2 style={{ width: 16, height: 16 }} />
                  </button>
                </div>
              );
            })}
          </div>
        )
      ) : tab === "chart" ? (
        /* ─── График ─── */
        <Card>
          <CardContent className="pt-4 pb-2">
            {chartData.length < 2 ? (
              <div className="py-14 text-center text-sm text-muted-foreground">
                Нужно минимум 2 записи для графика
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={chartData} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="date" tick={{ fontSize: 10 }} stroke="#a1a1aa" />
                  <YAxis tick={{ fontSize: 10 }} stroke="#a1a1aa" domain={[40, "auto"]} />
                  <Tooltip />
                  <ReferenceLine y={140} stroke="#fb923c" strokeDasharray="4 4" />
                  <ReferenceLine y={90} stroke="#fbbf24" strokeDasharray="4 4" />
                  <Line type="monotone" dataKey="SYS" stroke="#fb7185" strokeWidth={2} dot={{ r: 2 }} />
                  <Line type="monotone" dataKey="DIA" stroke="#38bdf8" strokeWidth={2} dot={{ r: 2 }} />
                  <Line type="monotone" dataKey="Пульс" stroke="#c4b5fd" strokeWidth={1.5} dot={{ r: 1.5 }} strokeDasharray="5 3" />
                </LineChart>
              </ResponsiveContainer>
            )}
            <div className="flex gap-4 justify-center pb-2 text-xs text-muted-foreground">
              <span className="flex items-center gap-1"><span style={{ width: 10, height: 3, background: "#fb7185", borderRadius: 2 }} /> SYS</span>
              <span className="flex items-center gap-1"><span style={{ width: 10, height: 3, background: "#38bdf8", borderRadius: 2 }} /> DIA</span>
              <span className="flex items-center gap-1"><span style={{ width: 10, height: 3, background: "#c4b5fd", borderRadius: 2 }} /> Пульс</span>
            </div>
          </CardContent>
        </Card>
      ) : (
        /* ─── Отчёт ─── */
        <div className="space-y-3">
          <Card>
            <CardContent className="pt-4 pb-4 space-y-3 text-sm">
              <h3 className="font-semibold">Сводка за 90 дней</h3>
              {stats ? (
                <div className="space-y-2">
                  <div className="flex justify-between border-b pb-2"><span className="text-muted-foreground">Всего измерений</span><b>{stats.count}</b></div>
                  <div className="flex justify-between border-b pb-2"><span className="text-muted-foreground">Среднее АД</span><b>{stats.avgSys}/{stats.avgDia} мм рт. ст.</b></div>
                  <div className="flex justify-between border-b pb-2"><span className="text-muted-foreground">Средний пульс</span><b>{stats.avgPulse ?? "—"} уд/мин</b></div>
                  <div className="flex justify-between border-b pb-2"><span className="text-muted-foreground">Максимум систолического</span><b style={{ color: bpColor(stats.maxSys, 0) }}>{stats.maxSys}</b></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Измерений ≥140/90</span><b style={{ color: stats.highPct > 25 ? "#fb923c" : "#34d399" }}>{stats.highCount} ({stats.highPct}%)</b></div>
                </div>
              ) : (
                <p className="text-muted-foreground text-xs">Нет данных за период</p>
              )}
            </CardContent>
          </Card>
          <Card className="border-primary/30 bg-primary/5">
            <CardContent className="pt-4 pb-4 text-xs text-muted-foreground leading-relaxed">
              <b className="text-foreground">Классификация АД (ESC/ESH):</b><br />
              Норма — до 129/84 · Высокое нормальное — 130–139/85–89 ·
              Гипертония 1 ст. — 140–159/90–99 · Гипертония 2 ст. — от 160/100.
              Оптимально измерять утром и вечером, сидя, после 5 минут покоя.
              Результат не является диагнозом — при устойчивом повышении обратитесь к врачу.
            </CardContent>
          </Card>
        </div>
      )}

      {showAdd && <EntrySheet onClose={() => setShowAdd(false)} />}
    </div>
  );
}
