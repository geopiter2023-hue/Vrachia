import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { DOC_TYPE_LABEL, fmtDate } from "@/lib/health-utils";
import { Eye, FileText, Plus, Trash2, UploadCloud, Sparkles } from "lucide-react";
import { toast } from "sonner";

export default function DocumentsPage() {
  const utils = trpc.useUtils();
  const { data, isLoading } = trpc.health.documents.list.useQuery();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    title: "",
    docType: "analysis",
    docDate: new Date().toISOString().slice(0, 10),
    source: "",
    fileName: "",
    fileMime: "",
    fileData: "",
    content: "",
  });
  const [viewer, setViewer] = useState<{ title: string; content: string } | null>(null);

  const createMut = trpc.health.documents.create.useMutation({
    onSuccess: (res) => {
      if (res.extracted.length) {
        toast.success(
          `Документ сохранён. Автоматически извлечено показателей: ${res.extracted.length} — ${res.extracted
            .map((e) => `${e.name} ${e.value}`)
            .join(", ")}`,
          { duration: 8000 }
        );
      } else {
        toast.success("Документ сохранён");
      }
      utils.health.documents.list.invalidate();
      utils.health.biomarkers.list.invalidate();
      utils.health.dashboard.invalidate();
      setOpen(false);
      setForm({ title: "", docType: "analysis", docDate: new Date().toISOString().slice(0, 10), source: "", fileName: "", fileMime: "", fileData: "", content: "" });
    },
    onError: (e) => {
      toast.error(`Не удалось сохранить документ: ${e.message.slice(0, 120)}`);
    },
  });

  const delMut = trpc.health.documents.remove.useMutation({
    onSuccess: () => {
      toast.success("Документ удалён");
      utils.health.documents.list.invalidate();
      utils.health.biomarkers.list.invalidate();
      utils.health.dashboard.invalidate();
    },
  });

  const onFile = (f: File | undefined) => {
    if (!f) return;
    if (f.size > 30 * 1024 * 1024) {
      toast.error("Файл слишком большой — максимум 30 МБ");
      return;
    }
    setForm((p) => ({ ...p, fileName: f.name, fileMime: f.type || "application/octet-stream", title: p.title || f.name.replace(/\.[^.]+$/, "") }));
    // Сохраняем сам файл (base64), чтобы его можно было открыть позже
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = String(reader.result ?? "");
      const base64 = dataUrl.split(",")[1] ?? "";
      setForm((p) => ({ ...p, fileData: base64 }));
    };
    reader.readAsDataURL(f);
    // Текстовые файлы читаем сразу (эмуляция OCR-извлечения текста)
    if (/\.(txt|csv|xml|json)$/i.test(f.name)) {
      f.text().then((t) => setForm((p) => ({ ...p, content: t.slice(0, 20000) })));
    } else {
      toast.info(
        "Файл прикреплён. Для автоматического извлечения показателей вставьте текст документа (в продакшн-версии здесь работает OCR-движок)."
      );
    }
  };

  const openDoc = (d: any) => {
    if (d.hasFile) {
      window.open(`/api/documents/${Number(d.id)}/file`, "_blank");
    } else if (d.content) {
      setViewer({ title: d.title, content: d.content });
    } else {
      toast.info("У этого документа нет прикреплённого файла");
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-xl md:text-2xl font-bold">Медицинские документы</h1>
          <p className="text-muted-foreground text-sm mt-1">
            Анализы, заключения, выписки — с автоматическим извлечением биомаркеров
          </p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-1.5" /> Загрузить документ
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Новый документ</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-2">
              <label className="flex flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed px-4 py-8 cursor-pointer hover:bg-accent/50 transition-colors">
                <UploadCloud className="h-8 w-8 text-muted-foreground" />
                <span className="text-sm text-muted-foreground">
                  {form.fileName || "PDF, JPG, XML, TXT — выберите файл"}
                </span>
                <input type="file" className="hidden" onChange={(e) => onFile(e.target.files?.[0])} />
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label>Название</Label>
                  <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
                </div>
                <div className="space-y-1.5">
                  <Label>Тип</Label>
                  <Select value={form.docType} onValueChange={(v) => setForm({ ...form, docType: v })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(DOC_TYPE_LABEL).map(([k, v]) => (
                        <SelectItem key={k} value={k}>{v}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label>Дата документа</Label>
                  <Input type="date" value={form.docDate} onChange={(e) => setForm({ ...form, docDate: e.target.value })} />
                </div>
                <div className="space-y-1.5">
                  <Label>Источник (лаборатория / клиника)</Label>
                  <Input value={form.source} onChange={(e) => setForm({ ...form, source: e.target.value })} />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label className="flex items-center gap-1.5">
                  <Sparkles className="h-3.5 w-3.5 text-primary" />
                  Текст документа — биомаркеры будут извлечены автоматически
                </Label>
                <Textarea
                  rows={6}
                  placeholder="Например: Гемоглобин 145 г/л. Глюкоза 5.6 ммоль/л. Холестерин общий 5.8..."
                  value={form.content}
                  onChange={(e) => setForm({ ...form, content: e.target.value })}
                />
              </div>
              <Button
                className="w-full"
                disabled={!form.title || createMut.isPending}
                onClick={() =>
                  createMut.mutate({
                    title: form.title,
                    docType: form.docType as any,
                    docDate: form.docDate,
                    source: form.source || undefined,
                    fileName: form.fileName || undefined,
                    fileMime: form.fileMime || undefined,
                    fileData: form.fileData || undefined,
                    content: form.content || undefined,
                    autoExtract: true,
                  })
                }
              >
                {createMut.isPending ? "Обработка…" : "Сохранить и распознать"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {[0, 1, 2].map((i) => (
            <Skeleton key={i} className="h-20" />
          ))}
        </div>
      ) : (
        <div className="space-y-2.5">
          {(data ?? []).map((d) => (
            <Card
              key={Number(d.id)}
              className="cursor-pointer hover:border-primary/40 hover:shadow-sm transition-all"
              onClick={() => openDoc(d)}
            >
              <CardContent className="py-4 flex items-start gap-4">
                <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                  <FileText className="h-5 w-5 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-medium">{d.title}</span>
                    <Badge variant="outline">{DOC_TYPE_LABEL[d.docType]}</Badge>
                  </div>
                  <div className="text-xs text-muted-foreground mt-1">
                    {fmtDate(String(d.docDate))}
                    {d.source ? ` · ${d.source}` : ""}
                    {d.fileName ? ` · ${d.fileName}` : ""}
                  </div>
                  {d.content && (
                    <p className="text-sm text-muted-foreground mt-2 line-clamp-2">{d.content}</p>
                  )}
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  {(d.hasFile || d.content) && (
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-muted-foreground hover:text-primary"
                      title="Открыть документ"
                      onClick={(e) => {
                        e.stopPropagation();
                        openDoc(d);
                      }}
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-muted-foreground hover:text-destructive"
                    onClick={(e) => {
                      e.stopPropagation();
                      if (confirm("Удалить документ вместе со связанными измерениями?"))
                        delMut.mutate({ id: Number(d.id) });
                    }}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={!!viewer} onOpenChange={(o) => !o && setViewer(null)}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{viewer?.title}</DialogTitle>
          </DialogHeader>
          <p className="text-sm whitespace-pre-wrap text-muted-foreground">{viewer?.content}</p>
        </DialogContent>
      </Dialog>
    </div>
  );
}
