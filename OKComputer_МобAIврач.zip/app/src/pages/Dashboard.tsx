import { trpc } from "@/providers/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  STATUS_LABEL,
  STATUS_CLASS,
  TREND_LABEL,
  DOC_TYPE_LABEL,
  fmtDate,
  fmtDateTime,
} from "@/lib/health-utils";
import {
  Activity,
  AlertTriangle,
  FileText,
  TrendingUp,
  TrendingDown,
  Minus,
  Bell,
  Link2,
  ChevronDown,
} from "lucide-react";
import { useState } from "react";
import { Link } from "react-router";
import NewsStories from "@/components/NewsStories";

export default function Dashboard() {
  const { data, isLoading } = trpc.health.dashboard.useQuery();
  const [risksOpen, setRisksOpen] = useState(false);
  const [corrOpen, setCorrOpen] = useState(false);

  if (isLoading || !data) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-9 w-64" />
        <div className="grid grid-cols-3 gap-4">
          {[0, 1, 2].map((i) => (
            <Skeleton key={i} className="h-28" />
          ))}
        </div>
        <Skeleton className="h-64" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl md:text-2xl font-bold">Обзор здоровья</h1>
        <p className="text-muted-foreground text-sm mt-1">
          Динамическая модель состояния на основе всей медицинской истории
        </p>
      </div>

      {/* Новости-сторис */}
      <NewsStories />

      {/* Сводка */}
      <div className="grid grid-cols-3 gap-2">
        <Card>
          <CardContent className="p-3 flex flex-col items-center text-center gap-1.5">
            <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center">
              <Activity className="h-4 w-4 text-primary" />
            </div>
            <div className="text-lg font-bold leading-none">{data.totalBiomarkers}</div>
            <div className="text-[10px] leading-tight text-muted-foreground">биомаркеров под наблюдением</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-3 flex flex-col items-center text-center gap-1.5">
            <div className="h-8 w-8 rounded-lg bg-orange-100 dark:bg-orange-950 flex items-center justify-center">
              <AlertTriangle className="h-4 w-4 text-orange-600" />
            </div>
            <div className="text-lg font-bold leading-none">{data.abnormalCount}</div>
            <div className="text-[10px] leading-tight text-muted-foreground">показателей с отклонениями</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-3 flex flex-col items-center text-center gap-1.5">
            <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center">
              <FileText className="h-4 w-4 text-primary" />
            </div>
            <div className="text-lg font-bold leading-none">{data.documentsCount}</div>
            <div className="text-[10px] leading-tight text-muted-foreground">документов в архиве</div>
          </CardContent>
        </Card>
      </div>

      {/* Риски */}
      {data.risks.length > 0 && (
        <Card className="border-orange-200 dark:border-orange-900">
          <CardHeader
            className="pb-3 cursor-pointer select-none"
            onClick={() => setRisksOpen((v) => !v)}
          >
            <CardTitle className="text-base flex items-center justify-between gap-2">
              <span className="flex items-center gap-2">
                <AlertTriangle className="h-4.5 w-4.5 text-orange-500" size={18} />
                Требуют внимания
                <span className="text-xs font-normal text-orange-600 bg-orange-100 dark:bg-orange-950 rounded-full px-2 py-0.5">
                  {data.risks.length}
                </span>
              </span>
              <ChevronDown
                className={`h-5 w-5 text-muted-foreground transition-transform ${risksOpen ? "rotate-180" : ""}`}
              />
            </CardTitle>
          </CardHeader>
          {risksOpen && (
            <CardContent className="space-y-2">
              {data.risks.map((r, i) => (
                <div key={i} className="text-sm rounded-lg bg-orange-50 dark:bg-orange-950/40 px-3 py-2.5">
                  {r}
                </div>
              ))}
            </CardContent>
          )}
        </Card>
      )}

      {/* Взаимосвязи */}
      {data.correlations.length > 0 && (
        <Card>
          <CardHeader
            className="pb-3 cursor-pointer select-none"
            onClick={() => setCorrOpen((v) => !v)}
          >
            <CardTitle className="text-base flex items-center justify-between gap-2">
              <span className="flex items-center gap-2">
                <Link2 className="h-4.5 w-4.5 text-primary" size={18} />
                Выявленные взаимосвязи
                <span className="text-xs font-normal text-primary bg-primary/10 rounded-full px-2 py-0.5">
                  {data.correlations.length}
                </span>
              </span>
              <ChevronDown
                className={`h-5 w-5 text-muted-foreground transition-transform ${corrOpen ? "rotate-180" : ""}`}
              />
            </CardTitle>
          </CardHeader>
          {corrOpen && (
            <CardContent className="space-y-2">
              {data.correlations.map((c, i) => (
                <div key={i} className="text-sm rounded-lg bg-muted px-3 py-2.5">
                  {c}
                </div>
              ))}
            </CardContent>
          )}
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Ключевые показатели */}
        <Card>
          <CardHeader className="pb-3 flex flex-row items-center justify-between">
            <CardTitle className="text-base">Ключевые показатели</CardTitle>
            <Link to="/biomarkers" className="text-xs text-primary hover:underline">
              Все показатели →
            </Link>
          </CardHeader>
          <CardContent className="space-y-1.5">
            {data.topBiomarkers.map((b) => (
              <div key={b.code} className="flex items-center gap-3 rounded-lg border px-3 py-2.5">
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium truncate">{b.name}</div>
                  <div className="text-xs text-muted-foreground">
                    норма {b.refLow}–{b.refHigh} {b.unit}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-semibold">
                    {b.latest?.value} <span className="text-xs font-normal text-muted-foreground">{b.unit}</span>
                  </div>
                  <div className="text-xs text-muted-foreground flex items-center justify-end gap-1">
                    {b.trend === "up" && <TrendingUp className="h-3 w-3 text-orange-500" />}
                    {b.trend === "down" && <TrendingDown className="h-3 w-3 text-emerald-500" />}
                    {b.trend === "stable" && <Minus className="h-3 w-3" />}
                    {TREND_LABEL[b.trend as keyof typeof TREND_LABEL]}
                  </div>
                </div>
                <Badge className={STATUS_CLASS[b.status as keyof typeof STATUS_CLASS]} variant="secondary">
                  {STATUS_LABEL[b.status as keyof typeof STATUS_LABEL]}
                </Badge>
              </div>
            ))}
          </CardContent>
        </Card>

        <div className="space-y-4">
          {/* Уведомления */}
          <Card>
            <CardHeader className="pb-3 flex flex-row items-center justify-between">
              <CardTitle className="text-base flex items-center gap-2">
                <Bell className="h-4 w-4" /> Уведомления
              </CardTitle>
              <Link to="/notifications" className="text-xs text-primary hover:underline">
                Все →
              </Link>
            </CardHeader>
            <CardContent className="space-y-2">
              {data.notifications.slice(0, 4).map((n) => (
                <div key={Number(n.id)} className="rounded-lg border px-3 py-2.5">
                  <div className="flex items-center gap-2">
                    <span
                      className={
                        "h-2 w-2 rounded-full shrink-0 " +
                        (n.severity === "critical"
                          ? "bg-red-500"
                          : n.severity === "warning"
                            ? "bg-orange-500"
                            : "bg-sky-500")
                      }
                    />
                    <span className="text-sm font-medium">{n.title}</span>
                  </div>
                  <div className="text-xs text-muted-foreground mt-1">{n.body}</div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Последние документы */}
          <Card>
            <CardHeader className="pb-3 flex flex-row items-center justify-between">
              <CardTitle className="text-base">Последние документы</CardTitle>
              <Link to="/documents" className="text-xs text-primary hover:underline">
                Архив →
              </Link>
            </CardHeader>
            <CardContent className="space-y-1.5">
              {data.recentDocs.map((d) => (
                <div key={Number(d.id)} className="flex items-center gap-3 rounded-lg border px-3 py-2">
                  <FileText className="h-4 w-4 text-muted-foreground shrink-0" />
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium truncate">{d.title}</div>
                    <div className="text-xs text-muted-foreground">
                      {d.source} · {fmtDate(String(d.docDate))}
                    </div>
                  </div>
                  <Badge variant="outline" className="text-xs shrink-0">
                    {DOC_TYPE_LABEL[d.docType]}
                  </Badge>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>

      <p className="text-xs text-muted-foreground">
        Сводка сформирована локальным аналитическим движком. Последнее обновление: {fmtDateTime(new Date())}
      </p>
    </div>
  );
}
