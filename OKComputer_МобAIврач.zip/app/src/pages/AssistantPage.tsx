import { useEffect, useRef, useState } from "react";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { BotMessageSquare, Send, User, ShieldCheck } from "lucide-react";

const SUGGESTIONS = [
  "Что означают мои показатели?",
  "Какая динамика за последний год?",
  "Есть ли ухудшение?",
  "Расскажи про мой холестерин",
  "Есть ли связь между показателями?",
  "Какая мочевая кислота?",
];

type Msg = { role: "user" | "ai"; text: string };

function renderMd(text: string) {
  return text.split("\n").map((line, i) => {
    const parts = line.split(/(\*\*[^*]+\*\*)/g).map((p, j) =>
      p.startsWith("**") && p.endsWith("**") ? <b key={j}>{p.slice(2, -2)}</b> : <span key={j}>{p}</span>
    );
    return (
      <p key={i} className={line.trim() === "" ? "h-2" : ""}>
        {parts}
      </p>
    );
  });
}

export default function AssistantPage() {
  const [messages, setMessages] = useState<Msg[]>([
    {
      role: "ai",
      text: "Здравствуйте! Я ваш персональный AI-ассистент здоровья. Анализирую всю вашу медицинскую историю локально — данные не покидают систему.\n\nСпросите о динамике показателей, отклонениях, рисках или конкретном биомаркере.",
    },
  ]);
  const [input, setInput] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);

  const askMut = trpc.health.assistant.ask.useMutation({
    onSuccess: (res) => setMessages((m) => [...m, { role: "ai", text: res.answer }]),
    onError: () => setMessages((m) => [...m, { role: "ai", text: "Произошла ошибка при обработке запроса. Попробуйте ещё раз." }]),
  });

  const ask = (q: string) => {
    if (!q.trim() || askMut.isPending) return;
    setMessages((m) => [...m, { role: "user", text: q }]);
    setInput("");
    askMut.mutate({ question: q });
  };

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, askMut.isPending]);

  return (
    <div className="flex flex-col h-[calc(100dvh-10.5rem)] md:h-[calc(100vh-3rem)]">
      <div className="mb-4">
        <h1 className="text-xl md:text-2xl font-bold flex items-center gap-2">
          <BotMessageSquare className="h-6 w-6 text-primary" /> AI-ассистент
        </h1>
        <p className="text-muted-foreground text-sm mt-1 flex items-center gap-1.5">
          <ShieldCheck className="h-4 w-4 text-primary" />
          Полностью локальная обработка. Ответы основаны на ваших данных, с цитированием источников. Не является диагнозом.
        </p>
      </div>

      <div className="flex-1 overflow-y-auto rounded-xl border bg-card p-4 space-y-4">
        {messages.map((m, i) => (
          <div key={i} className={"flex gap-3 " + (m.role === "user" ? "justify-end" : "")}>
            {m.role === "ai" && (
              <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center shrink-0 mt-0.5">
                <BotMessageSquare className="h-4 w-4 text-primary-foreground" />
              </div>
            )}
            <div
              className={
                "max-w-[88%] md:max-w-[80%] rounded-2xl px-4 py-3 text-sm " +
                (m.role === "user"
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted")
              }
            >
              {m.role === "ai" ? renderMd(m.text) : m.text}
            </div>
            {m.role === "user" && (
              <div className="h-8 w-8 rounded-full bg-secondary flex items-center justify-center shrink-0 mt-0.5">
                <User className="h-4 w-4" />
              </div>
            )}
          </div>
        ))}
        {askMut.isPending && (
          <div className="flex gap-3">
            <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center shrink-0">
              <BotMessageSquare className="h-4 w-4 text-primary-foreground animate-pulse" />
            </div>
            <div className="rounded-2xl bg-muted px-4 py-3 text-sm text-muted-foreground">
              Анализирую данные…
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      <div className="mt-3 flex flex-wrap gap-1.5">
        {SUGGESTIONS.map((s) => (
          <button
            key={s}
            onClick={() => ask(s)}
            className="text-xs rounded-full border px-3 py-1.5 hover:bg-accent transition-colors text-muted-foreground hover:text-foreground"
          >
            {s}
          </button>
        ))}
      </div>

      <div className="mt-3 flex gap-2">
        <Input
          placeholder="Задайте вопрос о ваших показателях…"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && ask(input)}
        />
        <Button onClick={() => ask(input)} disabled={askMut.isPending || !input.trim()}>
          <Send className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
