import { NavLink, Outlet } from "react-router";
import {
  LayoutDashboard,
  Activity,
  HeartPulse,
  FileText,
  BotMessageSquare,
  Hospital,
  FileBarChart,
  Bell,
  ScrollText,
  ShieldCheck,
  Menu,
  PawPrint,
  Landmark,
  FileScan,
  Users,
  CalendarClock,
  Sparkles,
  BookOpenText,
} from "lucide-react";
import { trpc } from "@/providers/trpc";
import { Badge } from "@/components/ui/badge";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useState } from "react";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Дашборд", icon: LayoutDashboard, short: "Главная" },
  { to: "/biomarkers", label: "Показатели", icon: Activity, short: "Показатели" },
  { to: "/vitals", label: "Физиология", icon: HeartPulse, short: "Физиология" },
  { to: "/pressure", label: "Дневник давления", icon: HeartPulse, short: "Давление" },
  { to: "/documents", label: "Документы", icon: FileText, short: "Документы" },
  { to: "/assistant", label: "AI-ассистент", icon: BotMessageSquare, short: "AI" },
  { to: "/imaging", label: "AI-анализ снимков", icon: FileScan, short: "Снимки" },
  { to: "/family", label: "Семья", icon: Users, short: "Семья" },
  { to: "/pets", label: "Питомцы", icon: PawPrint, short: "Питомцы" },
  { to: "/clinics", label: "Клиники и врачи", icon: Hospital, short: "Клиники" },
  { to: "/news", label: "Новости Минздрава", icon: Landmark, short: "Новости" },
  { to: "/medcard", label: "Медкарта", icon: CalendarClock, short: "Медкарта" },
  { to: "/recommendations", label: "Рекомендации", icon: Sparkles, short: "Советы" },
  { to: "/catalog", label: "Справочник анализов", icon: BookOpenText, short: "Справочник" },
  { to: "/reports", label: "Отчёты и экспорт", icon: FileBarChart, short: "Отчёты" },
  { to: "/notifications", label: "Уведомления", icon: Bell, short: "Уведомления" },
  { to: "/audit", label: "Журнал действий", icon: ScrollText, short: "Журнал" },
];

// Нижняя панель мобильной навигации — 4 основных раздела + меню
const TAB_BAR = [NAV[0], NAV[1], NAV[5], NAV[8]];

function Logo() {
  return (
    <div className="flex items-center gap-2.5">
      <div className="h-9 w-9 rounded-xl bg-primary flex items-center justify-center shrink-0">
        <HeartPulse className="h-5 w-5 text-primary-foreground" />
      </div>
      <div>
        <div className="font-bold leading-tight">AI Врач</div>
        <div className="text-xs text-muted-foreground">Цифровой двойник здоровья</div>
      </div>
    </div>
  );
}

function PrivacyNote() {
  return (
    <div className="flex items-start gap-2 text-xs text-muted-foreground">
      <ShieldCheck className="h-4 w-4 shrink-0 mt-0.5 text-primary" />
      <span>Данные обрабатываются локально и не передаются третьим лицам. AI-выводы не являются диагнозом.</span>
    </div>
  );
}

export default function Layout() {
  const { data: notifs } = trpc.health.notifications.list.useQuery();
  const unread = notifs?.filter((n) => !n.isRead).length ?? 0;
  const [menuOpen, setMenuOpen] = useState(false);

  const navItem = (
    item: (typeof NAV)[number],
    onClick?: () => void
  ) => (
    <NavLink
      key={item.to}
      to={item.to}
      end={item.to === "/"}
      onClick={onClick}
      className={({ isActive }) =>
        cn(
          "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
          isActive
            ? "bg-primary text-primary-foreground"
            : "text-muted-foreground hover:bg-accent hover:text-foreground"
        )
      }
    >
      <item.icon className="shrink-0" size={18} />
      <span className="flex-1">{item.label}</span>
      {item.to === "/notifications" && unread > 0 && (
        <Badge variant="destructive" className="h-5 px-1.5 text-xs">
          {unread}
        </Badge>
      )}
    </NavLink>
  );

  return (
    <div className="min-h-screen bg-background">
      {/* ── Десктопный сайдбар ── */}
      <aside className="hidden md:flex w-64 shrink-0 border-r bg-card flex-col fixed inset-y-0 z-30">
        <div className="px-5 py-5 border-b">
          <Logo />
        </div>
        <nav className="flex-1 p-3 space-y-0.5 overflow-y-auto">{NAV.map((n) => navItem(n))}</nav>
        <div className="p-4 border-t">
          <PrivacyNote />
        </div>
      </aside>

      {/* ── Мобильная шапка ── */}
      <header className="md:hidden sticky top-0 z-50 border-b bg-card px-4 py-3">
        <Logo />
      </header>

      {/* ── Контент ── */}
      <main className="md:ml-64 min-w-0 pb-24 md:pb-0">
        <div className="mx-auto max-w-6xl px-4 md:px-6 py-4 md:py-6">
          <Outlet />
        </div>
      </main>

      {/* ── Мобильная нижняя панель с кнопками (инлайн-стили — гарантированный рендер) ── */}
      <nav
        className="md:hidden"
        style={{
          position: "fixed",
          bottom: 0,
          left: 0,
          right: 0,
          zIndex: 50,
          padding: "4px 12px 12px",
        }}
      >
        <div
          style={{
            display: "flex",
            flexDirection: "row",
            margin: "0 auto",
            maxWidth: 430,
            background: "#ffffff",
            border: "1px solid #e4e4e7",
            borderRadius: 20,
            boxShadow: "0 4px 24px rgba(0,0,0,0.14)",
            padding: 6,
            gap: 4,
          }}
        >
          {TAB_BAR.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === "/"}
              style={({ isActive }) => ({
                flex: 1,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                gap: 2,
                height: 56,
                borderRadius: 14,
                fontSize: 10,
                fontWeight: 500,
                textDecoration: "none",
                background: isActive ? "#0f766e" : "transparent",
                color: isActive ? "#ffffff" : "#71717a",
              })}
            >
              <item.icon size={20} />
              {item.short}
            </NavLink>
          ))}
          <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
            <SheetTrigger asChild>
              <button
                style={{
                  flex: 1,
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 2,
                  height: 56,
                  borderRadius: 14,
                  fontSize: 10,
                  fontWeight: 500,
                  background: "transparent",
                  color: "#71717a",
                  border: "none",
                  cursor: "pointer",
                  position: "relative",
                }}
              >
                <Menu size={20} />
                Меню
                {unread > 0 && (
                  <span
                    style={{
                      position: "absolute",
                      top: 4,
                      right: "18%",
                      height: 16,
                      minWidth: 16,
                      padding: "0 4px",
                      borderRadius: 999,
                      background: "#dc2626",
                      color: "#fff",
                      fontSize: 9,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    {unread}
                  </span>
                )}
              </button>
            </SheetTrigger>
            <SheetContent side="left" className="w-72 p-0 flex flex-col">
              <div className="px-5 py-5 border-b">
                <Logo />
              </div>
              <nav className="flex-1 p-3 space-y-0.5 overflow-y-auto">
                {NAV.map((n) => navItem(n, () => setMenuOpen(false)))}
              </nav>
              <div className="p-4 border-t">
                <PrivacyNote />
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </nav>
    </div>
  );
}
