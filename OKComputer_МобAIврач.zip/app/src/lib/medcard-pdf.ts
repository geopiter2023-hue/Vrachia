// Генерация PDF медкарты на клиенте (pdfmake + Roboto с кириллицей)
import pdfMake from "pdfmake/build/pdfmake";

// Шрифты лежат локально в public/fonts — не зависят от внешних CDN
const ROBOTO_REG = "/fonts/Roboto-Regular.ttf";
const ROBOTO_BOLD = "/fonts/Roboto-Bold.ttf";

let vfsReady: Promise<void> | null = null;

async function ensureFonts(): Promise<void> {
  if (vfsReady) return vfsReady;
  vfsReady = (async () => {
    const toB64 = async (url: string) => {
      const r = await fetch(url);
      if (!r.ok) throw new Error("font fetch failed");
      const buf = await r.arrayBuffer();
      let bin = "";
      const bytes = new Uint8Array(buf);
      for (let i = 0; i < bytes.length; i += 0x8000) {
        bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
      }
      return btoa(bin);
    };
    const [reg, bold] = await Promise.all([toB64(ROBOTO_REG), toB64(ROBOTO_BOLD)]);
    const pm = pdfMake as any;
    // pdfmake 0.2.x: регистрируем файлы шрифтов в виртуальной ФС
    if (typeof pm.addVirtualFileSystem === "function") {
      pm.addVirtualFileSystem({ "Roboto-Regular.ttf": reg, "Roboto-Bold.ttf": bold });
    } else if (pm.vfs) {
      pm.vfs["Roboto-Regular.ttf"] = reg;
      pm.vfs["Roboto-Bold.ttf"] = bold;
    }
    pm.fonts = {
      ...(pm.fonts ?? {}),
      Roboto: {
        normal: "Roboto-Regular.ttf",
        bold: "Roboto-Bold.ttf",
        italics: "Roboto-Regular.ttf",
        bolditalics: "Roboto-Bold.ttf",
      },
    };
  })();
  return vfsReady;
}

export type PdfItem = { date: string; category: string; title: string; detail: string };
export type PdfYear = { year: number; months: { month: number; items: PdfItem[] }[] };

const MONTHS = [
  "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
  "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь",
];

const CAT_LABEL: Record<string, string> = {
  document: "Документ",
  measurement: "Анализы",
  vaccine: "Прививка",
  vital: "Физиология",
};

const CAT_COLOR: Record<string, string> = {
  document: "#0369a1",
  measurement: "#0f766e",
  vaccine: "#7c3aed",
  vital: "#be123c",
};

const fmtDateRu = (d: string) =>
  new Date(d + (d.length === 10 ? "T00:00:00" : "")).toLocaleDateString("ru-RU", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });

export async function exportMedcardPdf(
  years: PdfYear[],
  meta: { period: string; filterLabel: string }
): Promise<void> {
  await ensureFonts();

  const content: any[] = [
    { text: "МЕДИЦИНСКАЯ КАРТА", style: "h1" },
    { text: "AI Врач · Цифровой двойник здоровья", style: "sub" },
    {
      text: `Сформировано: ${new Date().toLocaleString("ru-RU")} · Период: ${meta.period} · Фильтр: ${meta.filterLabel}`,
      style: "meta",
      margin: [0, 2, 0, 10],
    },
  ];

  for (const y of years) {
    content.push({
      text: `${y.year} год`,
      style: "year",
      margin: [0, 10, 0, 4],
    });
    for (const m of y.months) {
      content.push({
        text: `${MONTHS[m.month - 1]} ${y.year}`,
        style: "month",
        margin: [0, 6, 0, 3],
      });
      content.push({
        table: {
          widths: [70, 62, "*"],
          body: m.items.map((i) => [
            { text: fmtDateRu(i.date), style: "td" },
            {
              text: CAT_LABEL[i.category] ?? i.category,
              style: "td",
              color: CAT_COLOR[i.category] ?? "#334155",
              bold: true,
            },
            {
              stack: [
                { text: i.title, style: "td", bold: true },
                ...(i.detail
                  ? [{ text: i.detail.replace(/ ⚠/g, " [ОТКЛОНЕНИЕ]"), style: "tdSmall" }]
                  : []),
              ],
            },
          ]),
        },
        layout: {
          hLineWidth: () => 0.5,
          vLineWidth: () => 0,
          hLineColor: () => "#e2e8f0",
          paddingTop: () => 4,
          paddingBottom: () => 4,
        },
      });
    }
  }

  content.push({
    text: "Результат не является диагнозом — при отклонениях требуется консультация врача.",
    style: "meta",
    margin: [0, 14, 0, 0],
  });

  pdfMake
    .createPdf({
      content,
      styles: {
        h1: { fontSize: 18, bold: true, color: "#0f766e" },
        sub: { fontSize: 11, color: "#475569" },
        meta: { fontSize: 8, color: "#64748b" },
        year: { fontSize: 14, bold: true, color: "#0f172a" },
        month: { fontSize: 11, bold: true, color: "#0f766e" },
        td: { fontSize: 9, color: "#0f172a" },
        tdSmall: { fontSize: 8, color: "#475569", margin: [0, 1, 0, 0] },
      },
      defaultStyle: { font: "Roboto" },
      pageMargins: [36, 36, 36, 36],
    })
    .download(`медкарта-${meta.period === "все годы" ? "все-годы" : meta.period}.pdf`);
}
