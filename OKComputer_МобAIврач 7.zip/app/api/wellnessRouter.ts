import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import {
  wellnessChecks,
  userAchievements,
  biomarkers,
  measurements,
  vitals,
  bpEntries,
  documents,
  notifications,
  auditLog,
} from "@db/schema";
import { eq, desc, sql } from "drizzle-orm";
import { analyzeBiomarker, type BiomarkerAnalysis } from "./analysis";

// ─── Самовосстановление: таблицы создаются при первом обращении ───────────
let tablesReady = false;
async function ensureTables() {
  if (tablesReady) return;
  const db = getDb();
  await db.execute(sql.raw(`CREATE TABLE IF NOT EXISTS wellness_checks (
    id bigint unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
    check_date date NOT NULL,
    mood enum('great','good','ok','bad') NOT NULL,
    sleep int NULL,
    energy int NULL,
    note varchar(500) NULL,
    created_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_wellness_date (check_date)
  )`));
  await db.execute(sql.raw(`CREATE TABLE IF NOT EXISTS user_achievements (
    id bigint unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
    code varchar(48) NOT NULL UNIQUE,
    unlocked_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
  )`));
  tablesReady = true;
}

function todayStr(d = new Date()): string {
  return d.toISOString().slice(0, 10);
}

// ─── Индекс здоровья 0–100 ────────────────────────────────────────────────
// Состав: биомаркеры (45) + витальные показатели (25) + регулярность (20) + самочувствие (10)
export async function computeHealthScore(): Promise<{
  score: number;
  parts: { key: string; label: string; value: number; max: number; hint: string }[];
}> {
  const db = getDb();
  const parts: { key: string; label: string; value: number; max: number; hint: string }[] = [];

  // 1. Биомаркеры: доля показателей в норме (свежесть — бонус)
  const [bs, ms] = await Promise.all([db.select().from(biomarkers), db.select().from(measurements)]);
  const analyses: BiomarkerAnalysis[] = bs.map((b) =>
    analyzeBiomarker(b, ms.filter((m) => m.biomarkerId === Number(b.id)))
  );
  const withData = analyses.filter((a) => a.latest);
  let bioVal = 0;
  let bioHint = "Загрузите результаты анализов";
  if (withData.length > 0) {
    const normal = withData.filter((a) => a.status === "normal").length;
    // отклонения штрафуют по силе отклонения
    const penalty = withData.reduce((acc, a) => {
      if (a.status === "normal") return acc;
      const dev = Math.min(a.deviationPct ?? 20, 60);
      return acc + (a.status === "critical" ? dev / 40 : dev / 80);
    }, 0);
    const ratio = Math.max(0, (normal - penalty * 0.5) / withData.length);
    bioVal = Math.round(45 * Math.min(1, Math.max(0, ratio)));
    const abnormal = withData.length - normal;
    bioHint = abnormal === 0
      ? `Все ${withData.length} показателей в норме`
      : `${abnormal} из ${withData.length} показателей вне нормы`;
  }
  parts.push({ key: "biomarkers", label: "Анализы", value: bioVal, max: 45, hint: bioHint });

  // 2. Витальные: давление и пульс за 14 дней
  const since14 = new Date(Date.now() - 14 * 864e5);
  const bp = await db.select().from(bpEntries).orderBy(desc(bpEntries.measuredAt)).limit(60);
  const recentBp = bp.filter((e) => new Date(e.measuredAt) >= since14);
  let vitVal = 0;
  let vitHint = "Нет измерений давления за 2 недели";
  if (recentBp.length > 0) {
    const inNorm = recentBp.filter((e) => e.sys < 130 && e.dia < 85).length;
    const mild = recentBp.filter((e) => e.sys < 140 && e.dia < 90).length;
    const ratio = (inNorm + (mild - inNorm) * 0.6) / recentBp.length;
    vitVal = Math.round(25 * ratio);
    const avgSys = Math.round(recentBp.reduce((a, e) => a + e.sys, 0) / recentBp.length);
    const avgDia = Math.round(recentBp.reduce((a, e) => a + e.dia, 0) / recentBp.length);
    vitHint = `Среднее АД ${avgSys}/${avgDia} за 2 недели`;
  } else {
    // fallback на vitals pressure_sys
    const vs = await db.select().from(vitals).orderBy(desc(vitals.measuredAt)).limit(100);
    const ps = vs.filter((v) => v.vitalType === "pressure_sys" && new Date(v.measuredAt) >= since14);
    if (ps.length) {
      const avg = ps.reduce((a, v) => a + v.value, 0) / ps.length;
      vitVal = avg < 130 ? 22 : avg < 140 ? 15 : 8;
      vitHint = `Среднее систолическое АД ${Math.round(avg)}`;
    }
  }
  parts.push({ key: "vitals", label: "Давление и пульс", value: vitVal, max: 25, hint: vitHint });

  // 3. Регулярность ведения дневника (30 дней): измерения, чек-ины, документы
  await ensureTables();
  const since30 = todayStr(new Date(Date.now() - 30 * 864e5));
  const [checks, docs, msr30] = await Promise.all([
    db.select({ d: wellnessChecks.checkDate }).from(wellnessChecks),
    db.select({ d: documents.docDate }).from(documents),
    db.select({ d: measurements.measuredAt }).from(measurements),
  ]);
  const activeDays = new Set<string>();
  for (const c of checks) if (c.d >= since30) activeDays.add(String(c.d).slice(0, 10));
  for (const m of msr30) if (m.d >= since30) activeDays.add(String(m.d).slice(0, 10));
  const bpDays = new Set(recentBp.map((e) => todayStr(new Date(e.measuredAt))));
  for (const d of bpDays) activeDays.add(d);
  const days = activeDays.size;
  const regVal = Math.min(20, Math.round((days / 20) * 20));
  parts.push({
    key: "regularity",
    label: "Регулярность",
    value: regVal,
    max: 20,
    hint: days === 0 ? "Начните с ежедневного чек-ина" : `${days} активных дней за месяц`,
  });
  void docs;

  // 4. Самочувствие по чек-инам (последние 7)
  const recentChecks = checks
    .map((c) => c.d)
    .sort()
    .slice(-7);
  let moodVal = 5;
  let moodHint = "Отмечайте самочувствие ежедневно";
  if (recentChecks.length) {
    const rows = await db
      .select()
      .from(wellnessChecks)
      .orderBy(desc(wellnessChecks.checkDate))
      .limit(7);
    const moodScore = { great: 1, good: 0.85, ok: 0.55, bad: 0.2 } as const;
    const avg = rows.reduce((a, r) => a + moodScore[r.mood], 0) / rows.length;
    moodVal = Math.round(10 * avg);
    moodHint = rows.length >= 5 ? "Стабильные отметки самочувствия" : "Продолжайте отмечать самочувствие";
  }
  parts.push({ key: "mood", label: "Самочувствие", value: moodVal, max: 10, hint: moodHint });

  const score = Math.max(0, Math.min(100, parts.reduce((a, p) => a + p.value, 0)));
  return { score, parts };
}

// ─── Серия дней (streak) по чек-инам ──────────────────────────────────────
function calcStreak(dates: string[]): { current: number; best: number } {
  const set = new Set(dates);
  let current = 0;
  const d = new Date();
  // сегодня ещё может быть без чек-ина — тогда серия считается со вчера
  if (!set.has(todayStr(d))) d.setDate(d.getDate() - 1);
  while (set.has(todayStr(d))) {
    current++;
    d.setDate(d.getDate() - 1);
  }
  // лучшая серия
  const sorted = [...set].sort();
  let best = 0;
  let run = 0;
  let prev = "";
  for (const s of sorted) {
    if (prev) {
      const diff = (new Date(s).getTime() - new Date(prev).getTime()) / 864e5;
      run = diff === 1 ? run + 1 : 1;
    } else run = 1;
    best = Math.max(best, run);
    prev = s;
  }
  return { current, best: Math.max(best, current) };
}

// ─── Достижения ───────────────────────────────────────────────────────────
const ACHIEVEMENTS: { code: string; title: string; text: string; icon: string }[] = [
  { code: "first_checkin", title: "Первый шаг", text: "Первый чек-ин самочувствия", icon: "🌱" },
  { code: "streak3", title: "Три подряд", text: "3 дня чек-инов подряд", icon: "🔥" },
  { code: "streak7", title: "Неделя заботы", text: "7 дней чек-инов подряд", icon: "🏅" },
  { code: "streak30", title: "Железная привычка", text: "30 дней чек-инов подряд", icon: "💎" },
  { code: "first_doc", title: "Архивариус", text: "Первый загруженный документ", icon: "📄" },
  { code: "docs5", title: "Личный архив", text: "5 документов в системе", icon: "🗂" },
  { code: "first_measurement", title: "Под контролем", text: "Первый распознанный показатель", icon: "🧪" },
  { code: "markers30", title: "Полная картина", text: "30 измерений биомаркеров", icon: "🔬" },
  { code: "bp10", title: "Кардиолог одобряет", text: "10 записей в дневнике давления", icon: "❤️" },
  { code: "score80", title: "Отличник", text: "Индекс здоровья 80+", icon: "🏆" },
];

async function unlock(code: string, newly: string[]) {
  const db = getDb();
  try {
    await db.insert(userAchievements).values({ code });
    newly.push(code);
  } catch {
    /* уже есть */
  }
}

async function checkAchievements(stats: {
  checks: number;
  streak: number;
  docs: number;
  markers: number;
  bp: number;
  score: number;
}): Promise<string[]> {
  await ensureTables();
  const newly: string[] = [];
  if (stats.checks >= 1) await unlock("first_checkin", newly);
  if (stats.streak >= 3) await unlock("streak3", newly);
  if (stats.streak >= 7) await unlock("streak7", newly);
  if (stats.streak >= 30) await unlock("streak30", newly);
  if (stats.docs >= 1) await unlock("first_doc", newly);
  if (stats.docs >= 5) await unlock("docs5", newly);
  if (stats.markers >= 1) await unlock("first_measurement", newly);
  if (stats.markers >= 30) await unlock("markers30", newly);
  if (stats.bp >= 10) await unlock("bp10", newly);
  if (stats.score >= 80) await unlock("score80", newly);
  return newly;
}

// ─── Умные напоминания ────────────────────────────────────────────────────
export async function generateSmartReminders(): Promise<number> {
  const db = getDb();
  await ensureTables();
  const existing = await db
    .select({ t: notifications.title })
    .from(notifications)
    .where(eq(notifications.isRead, false));
  const has = (s: string) => existing.some((n) => n.t === s);
  let created = 0;
  const add = async (title: string, body: string, severity: "info" | "warning" | "critical" = "info") => {
    if (has(title)) return;
    await db.insert(notifications).values({ title, body, severity });
    created++;
  };

  // 1. Давно нет измерения давления (если дневник когда-то вёлся)
  const bp = await db.select().from(bpEntries).orderBy(desc(bpEntries.measuredAt)).limit(1);
  if (bp.length) {
    const days = Math.floor((Date.now() - new Date(bp[0].measuredAt).getTime()) / 864e5);
    if (days >= 3) {
      await add(
        "Пора измерить давление",
        `Последнее измерение было ${days} дн. назад (${bp[0].sys}/${bp[0].dia}). Регулярный контроль — основа профилактики.`,
        days >= 7 ? "warning" : "info"
      );
    }
  }

  // 2. Отклонения биомаркеров, которым больше 3 месяцев — пересдать
  const [bs, ms] = await Promise.all([db.select().from(biomarkers), db.select().from(measurements)]);
  const analyses = bs.map((b) => analyzeBiomarker(b, ms.filter((m) => m.biomarkerId === Number(b.id))));
  for (const a of analyses) {
    if (!a.latest || a.status === "normal") continue;
    const days = Math.floor((Date.now() - new Date(a.latest.date).getTime()) / 864e5);
    if (days >= 90) {
      await add(
        `Пересдайте: ${a.biomarker.name}`,
        `Последний результат ${a.latest.value} ${a.biomarker.unit} был ${a.status === "critical" ? "критически " : ""}вне нормы ${Math.floor(days / 30)} мес. назад. Рекомендуется контрольный анализ.`,
        a.status === "critical" ? "critical" : "warning"
      );
    } else if (a.status === "critical") {
      await add(
        `Внимание: ${a.biomarker.name}`,
        `Значение ${a.latest.value} ${a.biomarker.unit} критически отклоняется от нормы. Обсудите с врачом.`,
        "critical"
      );
    }
  }

  // 3. Пропущен чек-ин (вёл серию, а вчера не отметился)
  const checks = await db.select({ d: wellnessChecks.checkDate }).from(wellnessChecks);
  const { current } = calcStreak(checks.map((c) => String(c.d).slice(0, 10)));
  if (current >= 3) {
    const today = todayStr();
    if (!checks.some((c) => String(c.d).slice(0, 10) === today)) {
      await add(
        "Не забудьте чек-ин",
        `У вас серия ${current} дн. подряд — отметьте самочувствие сегодня, чтобы не потерять её.`,
        "info"
      );
    }
  }
  return created;
}

// ─── Роутер ───────────────────────────────────────────────────────────────
export const wellnessRouter = createRouter({
  // Индекс здоровья
  healthScore: publicQuery.query(async () => {
    const { score, parts } = await computeHealthScore();
    // достижение за высокий индекс
    const [mCnt] = await getDb().select({ n: sql`count(*)` }).from(measurements);
    await checkAchievements({
      checks: 0,
      streak: 0,
      docs: 0,
      markers: Number(mCnt?.n ?? 0),
      bp: 0,
      score,
    }).catch(() => []);
    return { score, parts };
  }),

  // Чек-ин самочувствия на сегодня
  checkin: publicQuery
    .input(
      z.object({
        mood: z.enum(["great", "good", "ok", "bad"]),
        sleep: z.number().min(1).max(5).optional(),
        energy: z.number().min(1).max(5).optional(),
        note: z.string().max(500).optional(),
      })
    )
    .mutation(async ({ input }) => {
      await ensureTables();
      const db = getDb();
      const today = todayStr();
      await db
        .insert(wellnessChecks)
        .values({ checkDate: today, mood: input.mood, sleep: input.sleep, energy: input.energy, note: input.note })
        .onDuplicateKeyUpdate({
          set: { mood: input.mood, sleep: input.sleep ?? null, energy: input.energy ?? null, note: input.note ?? null },
        });
      const checks = await db.select({ d: wellnessChecks.checkDate }).from(wellnessChecks);
      const streak = calcStreak(checks.map((c) => String(c.d).slice(0, 10)));
      const [docCnt] = await db.select({ n: sql`count(*)` }).from(documents);
      const [mCnt] = await db.select({ n: sql`count(*)` }).from(measurements);
      const [bpCnt] = await db.select({ n: sql`count(*)` }).from(bpEntries);
      const newly = await checkAchievements({
        checks: checks.length,
        streak: streak.current,
        docs: Number(docCnt?.n ?? 0),
        markers: Number(mCnt?.n ?? 0),
        bp: Number(bpCnt?.n ?? 0),
        score: 0,
      });
      await db.insert(auditLog).values({ action: "checkin", detail: `Чек-ин: ${input.mood}, серия ${streak.current} дн.` });
      return {
        ok: true,
        streak,
        newAchievements: ACHIEVEMENTS.filter((a) => newly.includes(a.code)),
      };
    }),

  // Сегодняшний чек-ин + серия
  today: publicQuery.query(async () => {
    await ensureTables();
    const db = getDb();
    const today = todayStr();
    const rows = await db.select().from(wellnessChecks).orderBy(desc(wellnessChecks.checkDate)).limit(400);
    const streak = calcStreak(rows.map((c) => String(c.checkDate).slice(0, 10)));
    const todayCheck = rows.find((c) => String(c.checkDate).slice(0, 10) === today) ?? null;
    // история настроения для мини-графика (последние 14)
    const recent = rows.slice(0, 14).reverse().map((c) => ({
      date: String(c.checkDate).slice(0, 10),
      mood: c.mood,
      energy: c.energy,
    }));
    return { todayCheck, streak, total: rows.length, recent };
  }),

  // Достижения
  achievements: publicQuery.query(async () => {
    await ensureTables();
    const db = getDb();
    const unlocked = await db.select().from(userAchievements);
    const map = new Map(unlocked.map((u) => [u.code, u.unlockedAt]));
    return ACHIEVEMENTS.map((a) => ({
      ...a,
      unlocked: map.has(a.code),
      unlockedAt: map.get(a.code) ?? null,
    }));
  }),

  // Принудительная генерация умных напоминаний
  refreshReminders: publicQuery.mutation(async () => {
    const n = await generateSmartReminders();
    return { created: n };
  }),
});
