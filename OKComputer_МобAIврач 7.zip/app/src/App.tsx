import { Routes, Route } from "react-router";
import { Toaster } from "@/components/ui/sonner";
import Layout from "@/components/Layout";
import Dashboard from "@/pages/Dashboard";
import Biomarkers from "@/pages/Biomarkers";
import VitalsPage from "@/pages/VitalsPage";
import DocumentsPage from "@/pages/DocumentsPage";
import AssistantPage from "@/pages/AssistantPage";
import ClinicsPage from "@/pages/ClinicsPage";
import ReportsPage from "@/pages/ReportsPage";
import NotificationsPage from "@/pages/NotificationsPage";
import AuditPage from "@/pages/AuditPage";
import PetsPage from "@/pages/PetsPage";
import NewsPage from "@/pages/NewsPage";
import ImagingPage from "@/pages/ImagingPage";
import FamilyPage from "@/pages/FamilyPage";
import MedcardPage from "@/pages/MedcardPage";
import RecommendationsPage from "@/pages/RecommendationsPage";
import LabCatalogPage from "@/pages/LabCatalogPage";
import PressureDiaryPage from "@/pages/PressureDiaryPage";
import AchievementsPage from "@/pages/AchievementsPage";

export default function App() {
  return (
    <>
      <Routes>
        <Route element={<Layout />}>
          <Route path="/" element={<Dashboard />} />
          <Route path="/biomarkers" element={<Biomarkers />} />
          <Route path="/vitals" element={<VitalsPage />} />
          <Route path="/documents" element={<DocumentsPage />} />
          <Route path="/assistant" element={<AssistantPage />} />
          <Route path="/clinics" element={<ClinicsPage />} />
          <Route path="/imaging" element={<ImagingPage />} />
          <Route path="/pets" element={<PetsPage />} />
          <Route path="/family" element={<FamilyPage />} />
          <Route path="/medcard" element={<MedcardPage />} />
          <Route path="/recommendations" element={<RecommendationsPage />} />
          <Route path="/catalog" element={<LabCatalogPage />} />
          <Route path="/pressure" element={<PressureDiaryPage />} />
          <Route path="/achievements" element={<AchievementsPage />} />
          <Route path="/news" element={<NewsPage />} />
          <Route path="/reports" element={<ReportsPage />} />
          <Route path="/notifications" element={<NotificationsPage />} />
          <Route path="/audit" element={<AuditPage />} />
        </Route>
      </Routes>
      <Toaster />
    </>
  );
}
