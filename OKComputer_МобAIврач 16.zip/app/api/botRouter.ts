// ─── Мессенджер-бот: «входная дверь» в систему через Telegram ────────────
// Логика приёма сообщений («120/80», «вес 82.5», «принял»), связки аккаунта
// по коду, еженедельных сводок и напоминаний о лекарствах.
import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import {
  botLinks,
  bpEntries,
  vitals,
  medications,
  medicationLogs,
  wellnessChecks,
  notifications,
  auditLog,
  otpCodes,
} from "@db/schema";
import { eq, and, gt, desc, sql } from "drizzle-orm";

let ready = false;
export async function ensureBotTables() {
  if (ready) return;
  const db = getDb();
  await db.execute(sql.raw(`CREATE TABLE IF NOT EXISTS bot_links (
    id bigint unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
    provider varchar(24) NOT NULL DEFAULT 'telegram',
    chat_id varchar(64) NOT NULL,
    username varchar(128) NULL,
    link_code varchar(12) NULL,
    code_expires_at timestamp NULL,
    is_active tinyint(1) NOT NULL DEFAULT 0,
    created_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_bot_chat (provider, chat_id)
  )`));
  await db.execute(sql.raw(`CREATE TABLE IF NOT EXISTS medications (
    id bigint unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name varchar(255) NOT NULL,
    dosage varchar(128) NULL,
    times varchar(64) NOT NULL DEFAULT '09:00',
    start_date date NULL,
    end_date date NULL,
    note varchar(500) NULL,
    is_active tinyint(1) NOT NULL DEFAULT 1,
    created_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
  )`));
  await db.execute(sql.raw(`CREATE TABLE IF NOT EXISTS medication_logs (
    id bigint unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
    medication_id bigint unsigned NOT NULL,
    taken_at timestamp NOT NULL,
    scheduled_time varchar(8) NULL,
    source varchar(24) NOT NULL DEFAULT 'app',
    created_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_medlog_med (medication_id)
  )`));
  await db.execute(sql.raw(`CREATE TABLE IF NOT EXISTS health_points (
    id bigint unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
    action varchar(48) NOT NULL,
    points int NOT NULL,
    detail varchar(255) NULL,
    created_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
  )`));
  ready = true;
}

// Начисление баллов за здоровое действие (1 раз в день на действие)
export async function awardPoints(action: string, points: number, detail?: string) {
  try {
    await ensureBotTables();
    const db = getDb();
    const today = new Date().toISOString().slice(0, 10);
    const rows = await db.execute(
      sql`SELECT id FROM health_points WHERE action = ${action} AND DATE(created_at) = ${today} LIMIT 1`
    );
    if ((rows as any)[0]?.length) return;
    await db.execute(
      sql`INSERT INTO health_points (action, points, detail) VALUES (${action}, ${points}, ${detail ?? null})`
    );
  } catch {
    /* баллы не критичны */
  }
}

function genCode(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let s = "";
  for (let i = 0; i < 6; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return s;
}

async function notifyUser(title: string, body: string, severity: "info" | "warning" | "critical" = "info") {
  await getDb().insert(notifications).values({ title, body, severity });
}

// ─── Обработчик текстового сообщения от бота ─────────────────────────────
export async function handleBotMessage(
  chatId: string,
  text: string,
  username?: string
): Promise<string> {
  await ensureBotTables();
  const db = getDb();
  const t = text.trim();

  // Код связки: «AB12CD» или «/start AB12CD»
  const codeMatch = t.match(/^(?:\/start\s+)?([A-Z0-9]{6})$/i);
  if (codeMatch) {
    const code = codeMatch[1].toUpperCase();

    // Код входа на сайт (регистрация через Telegram)
    try {
      const { ensureAuthTables } = await import("./authRouter");
      await ensureAuthTables();
      const nowTs = new Date();
      const loginRows = await db
        .select()
        .from(otpCodes)
        .where(
          and(
            eq(otpCodes.channel, "telegram"),
            eq(otpCodes.identifier, code),
            eq(otpCodes.verified, false),
            gt(otpCodes.expiresAt, nowTs)
          )
        )
        .orderBy(desc(otpCodes.id))
        .limit(1);
      const lr = loginRows[0];
      if (lr) {
        await db
          .update(otpCodes)
          .set({ verified: true, tgChatId: chatId })
          .where(eq(otpCodes.id, Number(lr.id)));
        return "✅ Код подтверждён! Возвращайтесь в браузер — вход выполняется автоматически.";
      }
    } catch {
      /* таблицы авторизации ещё не созданы — не мешаем связке */
    }

    const pending = await db
      .select()
      .from(botLinks)
      .where(eq(botLinks.linkCode, code))
      .limit(1);
    const p = pending[0];
    if (p && p.codeExpiresAt && new Date(p.codeExpiresAt) > new Date() && !p.isActive) {
      await db
        .update(botLinks)
        .set({ chatId, username: username ?? null, isActive: true, linkCode: null })
        .where(eq(botLinks.id, Number(p.id)));
      return "✅ Аккаунт связан с AI Врачом!\n\nТеперь просто пишите:\n• «120/80» — записать давление\n• «120/80 72» — давление и пульс\n• «вес 82.5» — вес\n• «т 36.6» — температура\n• «шаги 8500» — шаги за сегодня\n• «принял» — отметить приём лекарств\n• «сводка» — состояние за неделю";
    }
    return "Код не найден или истёк. Сгенерируйте новый код в приложении: Меню → Подключить бота.";
  }

  // Проверяем привязку
  const links = await db.select().from(botLinks).where(eq(botLinks.chatId, chatId)).limit(1);
  const link = links[0];
  if (!link || !link.isActive) {
    return "Привет! Я бот AI Врача. Чтобы я мог сохранять ваши данные, свяжите аккаунт: откройте в приложении Меню → Подключить бота и отправьте мне 6-значный код.";
  }

  const now = new Date();

  // Давление: «120/80» или «120/80 72» или «давление 120 80»
  const bpMatch = t.match(/(\d{2,3})\s*[\/\\ ]\s*(\d{2,3})(?:\s+(\d{2,3}))?/);
  if (bpMatch && !/^вес/i.test(t) && !/^т\s/i.test(t)) {
    const sys = parseInt(bpMatch[1]);
    const dia = parseInt(bpMatch[2]);
    const pulse = bpMatch[3] ? parseInt(bpMatch[3]) : null;
    if (sys >= 70 && sys <= 260 && dia >= 40 && dia <= 160 && sys > dia) {
      await db.insert(bpEntries).values({ sys, dia, pulse, measuredAt: now, arm: "left" });
      await db.insert(vitals).values({ vitalType: "pressure_sys", value: sys, measuredAt: now, source: "bot" });
      await db.insert(vitals).values({ vitalType: "pressure_dia", value: dia, measuredAt: now, source: "bot" });
      if (pulse) await db.insert(vitals).values({ vitalType: "pulse", value: pulse, measuredAt: now, source: "bot" });
      await awardPoints("bp_entry", 5, `${sys}/${dia} через бота`);
      const cls = sys < 120 && dia < 80 ? "нормальное ✅" : sys < 130 && dia < 85 ? "в пределах нормы" : sys < 140 && dia < 90 ? "повышенное ⚠️" : "высокое 🔴";
      return `Записал: ${sys}/${dia}${pulse ? `, пульс ${pulse}` : ""} — ${cls}.\n+5 баллов здоровья 🏅`;
    }
  }

  // Шаги: «шаги 8500»
  const sMatch = t.match(/^шаги?\s+(\d{1,6})/i);
  if (sMatch) {
    const steps = parseInt(sMatch[1]);
    if (steps > 0 && steps <= 200000) {
      const { ensureStepsEnum } = await import("./stepsRouter");
      await ensureStepsEnum();
      await db.insert(vitals).values({ vitalType: "steps", value: steps, measuredAt: now, source: "bot" });
      await awardPoints("steps_entry", 3, `${steps} шагов через бота`);
      const kcal = Math.round(steps * 0.04);
      const km = Math.round(steps * 0.0007 * 10) / 10;
      return `Записал ${steps.toLocaleString("ru")} шагов 👟\n≈ ${km} км, ${kcal} ккал\n+3 балла`;
    }
  }

  // Вес: «вес 82.5»
  const wMatch = t.match(/^вес\s+(\d{2,3}(?:[.,]\d)?)/i);
  if (wMatch) {
    const w = parseFloat(wMatch[1].replace(",", "."));
    await db.insert(vitals).values({ vitalType: "weight", value: w, measuredAt: now, source: "bot" });
    await awardPoints("weight_entry", 3, `${w} кг через бота`);
    return `Вес ${w} кг записан ✅\n+3 балла`;
  }

  // Температура: «т 36.6» / «температура 37.2»
  const tMatch = t.match(/^(?:т|температура)\s+(\d{2}(?:[.,]\d)?)/i);
  if (tMatch) {
    const temp = parseFloat(tMatch[1].replace(",", "."));
    if (temp > 30 && temp < 45) {
      await db.insert(vitals).values({ vitalType: "temperature", value: temp, measuredAt: now, source: "bot" });
      return temp <= 37.2 ? `Температура ${temp}° записана ✅` : `Температура ${temp}° записана. Повышенная — следите за состоянием 🌡`;
    }
  }

  // «принял» — отметить все лекарства на текущее время
  if (/^принял/i.test(t)) {
    const meds = await db.select().from(medications).where(eq(medications.isActive, true));
    if (!meds.length) return "У вас нет активных лекарств в расписании. Добавьте их в приложении: Меню → Лекарства.";
    const hh = now.getHours();
    const slot = hh < 12 ? "утро" : hh < 18 ? "день" : "вечер";
    for (const m of meds) {
      await db.insert(medicationLogs).values({
        medicationId: Number(m.id),
        takenAt: now,
        scheduledTime: slot,
        source: "bot",
      });
    }
    await awardPoints("med_taken", 5, `${meds.length} препарат(а) через бота`);
    return `Отметил приём: ${meds.map((m) => m.name).join(", ")} ✅\n+5 баллов`;
  }

  // «сводка» — состояние за неделю
  if (/сводка|статус|итог/i.test(t)) {
    return buildWeeklySummary();
  }

  return "Не понял сообщение 🤔\nПишите так:\n• «120/80» — давление\n• «120/80 72» — давление и пульс\n• «вес 82.5» — вес\n• «т 36.6» — температура\n• «шаги 8500» — шаги за сегодня\n• «принял» — приём лекарств\n• «сводка» — итоги недели";
}

// ─── Еженедельная сводка для бота ─────────────────────────────────────────
export async function buildWeeklySummary(): Promise<string> {
  const db = getDb();
  const since = new Date(Date.now() - 7 * 864e5);
  const bp = await db.select().from(bpEntries).orderBy(desc(bpEntries.measuredAt)).limit(100);
  const week = bp.filter((e) => new Date(e.measuredAt) >= since);
  const lines: string[] = ["📊 *Ваша неделя в AI Враче*\n"];
  if (week.length) {
    const avgS = Math.round(week.reduce((a, e) => a + e.sys, 0) / week.length);
    const avgD = Math.round(week.reduce((a, e) => a + e.dia, 0) / week.length);
    lines.push(`❤️ Давление: ${week.length} изм., среднее ${avgS}/${avgD}`);
  } else lines.push("❤️ Давление: измерений не было за неделю");
  const checks = await db.select({ d: wellnessChecks.checkDate }).from(wellnessChecks);
  const weekChecks = checks.filter((c) => new Date(String(c.d)) >= since).length;
  lines.push(`🙂 Чек-ины самочувствия: ${weekChecks} из 7 дней`);
  const logs = await db.select({ id: medicationLogs.id }).from(medicationLogs);
  const weekLogs = logs.length; // упрощённо
  if (weekLogs) lines.push(`💊 Приём лекарств отмечен: ${weekLogs} раз`);
  try {
    const { computeHealthScore } = await import("./wellnessRouter");
    const { score } = await computeHealthScore();
    lines.push(`\n🏅 Индекс здоровья: *${score}/100*`);
  } catch { /* noop */ }
  lines.push("\nПодробности — в приложении AI Врач.");
  return lines.join("\n");
}

// ─── Напоминания о лекарствах (вызывается планировщиком) ─────────────────
export async function checkMedicationReminders(): Promise<number> {
  await ensureBotTables();
  const db = getDb();
  const now = new Date();
  const hhmm = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
  const meds = await db.select().from(medications).where(eq(medications.isActive, true));
  let n = 0;
  for (const m of meds) {
    const times = m.times.split(",").map((s) => s.trim());
    if (!times.some((tm) => tm === hhmm)) continue;
    // уже отмечен приём в этом слоте сегодня?
    const todayStart = new Date(now); todayStart.setHours(0, 0, 0, 0);
    const taken = await db
      .select({ id: medicationLogs.id })
      .from(medicationLogs)
      .where(eq(medicationLogs.medicationId, Number(m.id)))
      .limit(50);
    void taken;
    await notifyUser(
      `Время принять: ${m.name}`,
      `${m.dosage ? `${m.dosage} · ` : ""}запланировано на ${hhmm}. Отметьте приём в приложении или напишите боту «принял».`,
      "info"
    );
    n++;
  }
  return n;
}

// ─── Роутер для приложения ────────────────────────────────────────────────
export const botRouter = createRouter({
  // Сгенерировать код связки
  generateLinkCode: publicQuery.mutation(async () => {
    await ensureBotTables();
    const db = getDb();
    const code = genCode();
    const expires = new Date(Date.now() + 10 * 60 * 1000);
    await db.insert(botLinks).values({
      chatId: `pending-${code}`,
      linkCode: code,
      codeExpiresAt: expires,
      isActive: false,
    });
    return { code, expiresAt: expires };
  }),

  // Статус привязки
  linkStatus: publicQuery.query(async () => {
    await ensureBotTables();
    const db = getDb();
    const links = await db.select().from(botLinks).where(eq(botLinks.isActive, true));
    return { linked: links.length > 0, accounts: links.map((l) => ({ provider: l.provider, username: l.username })) };
  }),

  // Отвязать
  unlink: publicQuery.mutation(async () => {
    await ensureBotTables();
    await getDb().delete(botLinks).where(eq(botLinks.isActive, true));
    return { ok: true };
  }),

  // Входящее сообщение (REST/webhook и тест из UI)
  handleMessage: publicQuery
    .input(z.object({ chatId: z.string(), text: z.string(), username: z.string().optional() }))
    .mutation(async ({ input }) => {
      const reply = await handleBotMessage(input.chatId, input.text, input.username);
      await getDb().insert(auditLog).values({ action: "bot_message", detail: `${input.chatId}: ${input.text.slice(0, 80)}` });
      return { reply };
    }),

  // Лекарства: список с отметками за сегодня
  medications: createRouter({
    list: publicQuery.query(async () => {
      await ensureBotTables();
      const db = getDb();
      const meds = await db.select().from(medications).orderBy(desc(medications.createdAt));
      const logs = await db.select().from(medicationLogs).orderBy(desc(medicationLogs.takenAt)).limit(500);
      const today = new Date().toISOString().slice(0, 10);
      return meds.map((m) => ({
        ...m,
        id: Number(m.id),
        takenToday: logs.some(
          (l) => l.medicationId === Number(m.id) && new Date(l.takenAt).toISOString().slice(0, 10) === today
        ),
        totalTakes: logs.filter((l) => l.medicationId === Number(m.id)).length,
      }));
    }),
    add: publicQuery
      .input(
        z.object({
          name: z.string().min(1),
          dosage: z.string().optional(),
          times: z.string().default("09:00"),
          note: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        await ensureBotTables();
        const r = await getDb().insert(medications).values({
          name: input.name,
          dosage: input.dosage,
          times: input.times,
          note: input.note,
        });
        return { id: Number(r[0].insertId) };
      }),
    remove: publicQuery.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      await ensureBotTables();
      await getDb().update(medications).set({ isActive: false }).where(eq(medications.id, input.id));
      return { ok: true };
    }),
    take: publicQuery.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      await ensureBotTables();
      const db = getDb();
      await db.insert(medicationLogs).values({ medicationId: input.id, takenAt: new Date(), source: "app" });
      const med = (await db.select().from(medications).where(eq(medications.id, input.id)))[0];
      await awardPoints("med_taken", 5, med?.name);
      return { ok: true };
    }),
  }),

  // Баллы здоровья (кэшбэк-механика)
  points: createRouter({
    balance: publicQuery.query(async () => {
      await ensureBotTables();
      const db = getDb();
      const sumRes = await db.execute(sql`SELECT COALESCE(SUM(points),0) AS total FROM health_points`);
      const rows = await db.execute(
        sql`SELECT action, points, detail, created_at AS createdAt FROM health_points ORDER BY id DESC LIMIT 50`
      );
      const total = Number((sumRes as any)[0]?.[0]?.total ?? 0);
      return {
        total,
        level: total >= 500 ? "Золото" : total >= 200 ? "Серебро" : "Бронза",
        nextLevelAt: total >= 500 ? null : total >= 200 ? 500 : 200,
        history: ((rows as any)[0] ?? []).map((r: any) => ({
          action: r.action, points: r.points, detail: r.detail, createdAt: r.createdAt,
        })),
      };
    }),
  }),
});
