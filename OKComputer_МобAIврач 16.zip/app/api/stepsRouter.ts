// ─── Шагомер: дневные шаги, цель, статистика ─────────────────────────────
// Хранение: таблица vitals (vital_type = 'steps'), одна запись = одно внесение;
// дневная сумма агрегируется по дате measured_at.
import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { vitals } from "@db/schema";
import { sql } from "drizzle-orm";

export const STEP_GOAL = 10000;
// Расчётные коэффициенты (средние для взрослого)
export const KCAL_PER_STEP = 0.04;
export const KM_PER_STEP = 0.0007; // ~70 см шаг
export const MIN_PER_STEP = 1 / 110; // ~110 шагов в минуту ходьбы

function dayStr(d: Date): string {
  return d.toISOString().slice(0, 10);
}

// Колонка vital_type — ENUM; добавляем значение 'steps' при первом обращении
let enumReady = false;
export async function ensureStepsEnum() {
  if (enumReady) return;
  try {
    await getDb().execute(sql.raw(
      `ALTER TABLE vitals MODIFY COLUMN vital_type ENUM('pressure_sys','pressure_dia','pulse','temperature','weight','spo2','steps') NOT NULL`
    ));
  } catch { /* уже добавлено или таблица создастся drizzle-ом */ }
  enumReady = true;
}

export const stepsRouter = createRouter({
  // Добавить шаги за день (по умолчанию — сегодня)
  add: publicQuery
    .input(z.object({
      steps: z.number().int().min(1).max(200000),
      date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
    }))
    .mutation(async ({ input }) => {
      await ensureStepsEnum();
      const db = getDb();
      const measuredAt = input.date ? new Date(input.date + "T12:00:00") : new Date();
      await db.insert(vitals).values({
        vitalType: "steps",
        value: input.steps,
        measuredAt,
        source: "manual",
      });
      return { ok: true };
    }),

  // Сегодня: сумма, цель, производные
  today: publicQuery.query(async () => {
    await ensureStepsEnum();
    const db = getDb();
    const rows = await db.execute(
      sql`SELECT COALESCE(SUM(value),0) AS total FROM vitals WHERE vital_type='steps' AND DATE(measured_at)=CURDATE()`
    );
    const total = Number((rows as any)[0]?.[0]?.total ?? 0);
    return {
      steps: total,
      goal: STEP_GOAL,
      kcal: Math.round(total * KCAL_PER_STEP),
      km: Math.round(total * KM_PER_STEP * 10) / 10,
      activeMin: Math.round(total * MIN_PER_STEP),
    };
  }),

  // Статистика по дням за период
  stats: publicQuery
    .input(z.object({ period: z.enum(["7d", "30d", "6m", "1y"]) }))
    .query(async ({ input }) => {
      await ensureStepsEnum();
      const days = input.period === "7d" ? 7 : input.period === "30d" ? 30 : input.period === "6m" ? 183 : 365;
      const db = getDb();
      const rows = await db.execute(
        sql`SELECT DATE(measured_at) AS d, SUM(value) AS total FROM vitals
            WHERE vital_type='steps' AND measured_at >= DATE_SUB(CURDATE(), INTERVAL ${days} DAY)
            GROUP BY DATE(measured_at) ORDER BY d`
      );
      const byDay = new Map<string, number>();
      for (const r of (rows as any)[0] ?? []) byDay.set(dayStr(new Date(r.d)), Number(r.total));

      // Для длинных периодов — агрегация по месяцам, для коротких — по дням
      const monthly = input.period === "6m" || input.period === "1y";
      const out: { label: string; steps: number }[] = [];
      if (monthly) {
        const months = input.period === "6m" ? 6 : 12;
        const monthNames = ["янв.", "февр.", "март", "апр.", "май", "июнь", "июль", "авг.", "сент.", "окт.", "нояб.", "дек."];
        const now = new Date();
        for (let i = months - 1; i >= 0; i--) {
          const m = new Date(now.getFullYear(), now.getMonth() - i, 1);
          let sum = 0, cnt = 0;
          for (const [d, v] of byDay) {
            const dd = new Date(d);
            if (dd.getFullYear() === m.getFullYear() && dd.getMonth() === m.getMonth()) { sum += v; cnt++; }
          }
          out.push({ label: monthNames[m.getMonth()], steps: cnt ? Math.round(sum / cnt) : 0 });
        }
      } else {
        const now = new Date();
        for (let i = days - 1; i >= 0; i--) {
          const d = new Date(now.getTime() - i * 864e5);
          const key = dayStr(d);
          out.push({
            label: days === 7
              ? ["вс", "пн", "вт", "ср", "чт", "пт", "сб"][d.getDay()]
              : `${d.getDate()}.${String(d.getMonth() + 1).padStart(2, "0")}`,
            steps: byDay.get(key) ?? 0,
          });
        }
      }
      const vals = [...byDay.values()];
      const totalAll = vals.reduce((a, b) => a + b, 0);
      return {
        series: out,
        monthly,
        avg: vals.length ? Math.round(totalAll / vals.length) : 0,
        total: totalAll,
        daysWithData: vals.length,
        goal: STEP_GOAL,
      };
    }),

  // Удалить записи за день (если ошиблись)
  clearDay: publicQuery
    .input(z.object({ date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/) }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.execute(sql`DELETE FROM vitals WHERE vital_type='steps' AND DATE(measured_at)=${input.date}`);
      return { ok: true };
    }),
});
