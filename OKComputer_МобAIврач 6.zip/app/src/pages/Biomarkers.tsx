import { useMemo, useState } from "react";
import { trpc } from "@/providers/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceArea,
  ResponsiveContainer,
} from "recharts";
import { STATUS_LABEL, STATUS_CLASS, TREND_LABEL, fmtDate, STATUS_DOT, type Status, type Trend } from "@/lib/health-utils";
import { Plus, TrendingUp, TrendingDown, Minus } from "lucide-react";
import { toast } from "sonner";

type BmItem = {
  biomarker: { id: number | bigint; code: string; name: string; unit: string; refLow: number | null; refHigh: number | null; category: string };
  points: { date: string; value: number }[];
  latest: { date: string; value: number } | null;
  status: Status;
  trend: Trend;
  trendPct: number | null;
};

export default function Biomarkers() {
  const utils = trpc.useUtils();
  const { data, isLoading } = trpc.health.biomarkers.list.useQuery();
  const [selected, setSelected] = useState<string | null>(null);
  const [category, setCategory] = useState<string>("all");

  const addMut = trpc.health.biomarkers.addMeasurement.useMutation({
    onSuccess: () => {
      toast.success("Измерение добавлено");
      utils.health.biomarkers.list.invalidate();
      utils.health.dashboard.invalidate();
      utils.health.notifications.list.invalidate();
    },
  });

  const categories = useMemo(
    () => [...new Set((data ?? []).map((d) => d.biomarker.category))].sort(),
    [data]
  );
  const filtered = (data ?? []).filter(
    (d) => category === "all" || d.biomarker.category === category
  ) as BmItem[];
  const current = (data ?? []).find((d) => d.biomarker.code === selected) as BmItem | undefined;

  const [form, setForm] = useState({ biomarkerId: "", value: "", date: new Date().toISOString().slice(0, 10) });
  const [open, setOpen] = useState(false);

  if (isLoading) return <Skeleton className="h-96" />;

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-xl md:text-2xl font-bold">Биомаркеры</h1>
          <p className="text-muted-foreground text-sm mt-1">Динамика показателей с референтными диапазонами</p>
        </div>
        <div className="flex gap-2">
          <Select value={category} onValueChange={setCategory}>
            <SelectTrigger className="w-full sm:w-56">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Все категории</SelectItem>
              {categories.map((c) => (
                <SelectItem key={c} value={c}>{c}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-1.5" /> Добавить измерение
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Новое измерение</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-2">
                <div className="space-y-1.5">
                  <Label>Показатель</Label>
                  <Select value={form.biomarkerId} onValueChange={(v) => setForm({ ...form, biomarkerId: v })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Выберите биомаркер" />
                    </SelectTrigger>
                    <SelectContent>
                      {(data ?? []).map((d) => (
                        <SelectItem key={d.biomarker.code} value={String(Number(d.biomarker.id))}>
                          {d.biomarker.name} ({d.biomarker.unit})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label>Значение</Label>
                    <Input
                      type="number"
                      step="any"
                      value={form.value}
                      onChange={(e) => setForm({ ...form, value: e.target.value })}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label>Дата</Label>
                    <Input
                      type="date"
                      value={form.date}
                      onChange={(e) => setForm({ ...form, date: e.target.value })}
                    />
                  </div>
                </div>
                <Button
                  className="w-full"
                  disabled={!form.biomarkerId || !form.value || addMut.isPending}
                  onClick={() =>
                    addMut.mutate(
                      { biomarkerId: Number(form.biomarkerId), value: Number(form.value), measuredAt: form.date },
                      { onSuccess: () => setOpen(false) }
                    )
                  }
                >
                  Сохранить
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* График выбранного показателя */}
      {current && current.points.length > 0 && (
        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <CardTitle className="text-base">
                {current.biomarker.name}, {current.biomarker.unit}
              </CardTitle>
              <div className="flex items-center gap-3 text-sm">
                {current.trendPct != null && (
                  <span className="flex items-center gap-1 text-muted-foreground">
                    {current.trend === "up" && <TrendingUp className="h-4 w-4 text-orange-500" />}
                    {current.trend === "down" && <TrendingDown className="h-4 w-4 text-emerald-500" />}
                    {current.trend === "stable" && <Minus className="h-4 w-4" />}
                    {TREND_LABEL[current.trend]} ({current.trendPct > 0 ? "+" : ""}
                    {current.trendPct.toFixed(1)}%)
                  </span>
                )}
                <Badge className={STATUS_CLASS[current.status]} variant="secondary">
                  {STATUS_LABEL[current.status]}
                </Badge>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="h-56 md:h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={current.points} margin={{ top: 8, right: 16, bottom: 0, left: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                  <XAxis dataKey="date" tickFormatter={(d) => fmtDate(d)} fontSize={11} />
                  <YAxis domain={["auto", "auto"]} fontSize={11} width={50} />
                  <Tooltip
                    labelFormatter={(d) => fmtDate(String(d))}
                    formatter={(v: any) => [`${v} ${current.biomarker.unit}`, current.biomarker.name]}
                  />
                  {current.biomarker.refLow != null && current.biomarker.refHigh != null && (
                    <ReferenceArea
                      y1={current.biomarker.refLow}
                      y2={current.biomarker.refHigh}
                      fill="#10b981"
                      fillOpacity={0.08}
                      label={{ value: "норма", position: "insideTopRight", fontSize: 11, fill: "#10b981" }}
                    />
                  )}
                  <Line
                    type="monotone"
                    dataKey="value"
                    stroke={STATUS_DOT[current.status]}
                    strokeWidth={2.5}
                    dot={{ r: 4 }}
                    activeDot={{ r: 6 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Таблица показателей */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {filtered.map((d) => (
          <button
            key={d.biomarker.code}
            onClick={() => setSelected(d.biomarker.code)}
            className={
              "text-left rounded-xl border bg-card px-4 py-3.5 transition-all hover:shadow-sm " +
              (selected === d.biomarker.code ? "ring-2 ring-primary border-primary" : "")
            }
          >
            <div className="flex items-center gap-3">
              <span className="h-2.5 w-2.5 rounded-full shrink-0" style={{ background: STATUS_DOT[d.status] }} />
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium truncate">{d.biomarker.name}</div>
                <div className="text-xs text-muted-foreground">{d.biomarker.category}</div>
              </div>
              {d.latest ? (
                <div className="text-right shrink-0">
                  <div className="font-semibold">
                    {d.latest.value}{" "}
                    <span className="text-xs font-normal text-muted-foreground">{d.biomarker.unit}</span>
                  </div>
                  <div className="text-xs text-muted-foreground">{fmtDate(d.latest.date)}</div>
                </div>
              ) : (
                <span className="text-xs text-muted-foreground">нет данных</span>
              )}
              <Badge className={STATUS_CLASS[d.status]} variant="secondary">
                {STATUS_LABEL[d.status]}
              </Badge>
            </div>
            {d.trend !== "insufficient" && d.trendPct != null && (
              <div className="text-xs text-muted-foreground mt-1.5 pl-5.5 flex items-center gap-1">
                {d.trend === "up" && <TrendingUp className="h-3 w-3 text-orange-500" />}
                {d.trend === "down" && <TrendingDown className="h-3 w-3 text-emerald-500" />}
                {d.trend === "stable" && <Minus className="h-3 w-3" />}
                {TREND_LABEL[d.trend]} за период ({d.trendPct > 0 ? "+" : ""}
                {d.trendPct.toFixed(1)}%)
              </div>
            )}
          </button>
        ))}
      </div>
    </div>
  );
}
