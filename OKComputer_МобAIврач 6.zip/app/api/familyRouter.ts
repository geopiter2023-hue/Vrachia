import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import {
  familyMembers,
  familyDocuments,
  familyMeasurements,
  biomarkers,
  auditLog,
} from "@db/schema";
import { eq, desc } from "drizzle-orm";
import { analyzeBiomarker, answerQuestion, type BiomarkerAnalysis } from "./analysis";

async function log(action: string, detail: string) {
  await getDb().insert(auditLog).values({ action, detail });
}

async function extractFromText(text: string) {
  const bs = await getDb().select().from(biomarkers);
  const found: { biomarkerId: number; name: string; value: number; unit: string }[] = [];
  for (const b of bs) {
    const name = b.name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const re = new RegExp(`${name}[^0-9]{0,40}?(\\d+[.,]?\\d*)`, "i");
    const m = text.match(re);
    if (m) {
      const value = parseFloat(m[1].replace(",", "."));
      if (!isNaN(value)) found.push({ biomarkerId: Number(b.id), name: b.name, value, unit: b.unit });
    }
  }
  return found;
}

async function memberAnalyses(memberId: number): Promise<BiomarkerAnalysis[]> {
  const db = getDb();
  const [bs, ms] = await Promise.all([
    db.select().from(biomarkers),
    db.select().from(familyMeasurements).where(eq(familyMeasurements.memberId, memberId)),
  ]);
  return bs.map((b) =>
    analyzeBiomarker(b, ms.filter((m) => m.biomarkerId === Number(b.id)))
  );
}

export const familyRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    const members = await db.select().from(familyMembers).orderBy(desc(familyMembers.createdAt));
    const result = [];
    for (const m of members) {
      const docs = await db
        .select()
        .from(familyDocuments)
        .where(eq(familyDocuments.memberId, Number(m.id)))
        .orderBy(desc(familyDocuments.docDate));
      const analyses = await memberAnalyses(Number(m.id));
      const withData = analyses.filter((a) => a.latest);
      result.push({
        ...m,
        documents: docs,
        stats: {
          biomarkers: withData.length,
          abnormal: withData.filter((a) => a.status !== "normal").length,
          documents: docs.length,
        },
        top: withData
          .slice()
          .sort((a, b) => (b.deviationPct ?? 0) - (a.deviationPct ?? 0))
          .slice(0, 4)
          .map((a) => ({
            code: a.biomarker.code,
            name: a.biomarker.name,
            unit: a.biomarker.unit,
            latest: a.latest,
            status: a.status,
          })),
      });
    }
    return result;
  }),

  detail: publicQuery.input(z.object({ id: z.number() })).query(async ({ input }) => {
    const db = getDb();
    const member = (await db.select().from(familyMembers).where(eq(familyMembers.id, input.id)))[0];
    if (!member) return null;
    const docs = await db
      .select()
      .from(familyDocuments)
      .where(eq(familyDocuments.memberId, input.id))
      .orderBy(desc(familyDocuments.docDate));
    const analyses = await memberAnalyses(input.id);
    return {
      member,
      documents: docs,
      biomarkers: analyses.map((a) => ({
        biomarker: a.biomarker,
        points: a.points,
        latest: a.latest,
        status: a.status,
        trend: a.trend,
        trendPct: a.trendPct,
      })),
    };
  }),

  create: publicQuery
    .input(
      z.object({
        name: z.string().min(1),
        relation: z.string().min(1),
        sex: z.enum(["male", "female"]),
        birthDate: z.string().optional(),
        bloodType: z.string().optional(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const res = await getDb().insert(familyMembers).values({
        name: input.name,
        relation: input.relation,
        sex: input.sex,
        birthDate: input.birthDate || null,
        bloodType: input.bloodType,
        notes: input.notes,
      });
      await log("family", `Добавлен член семьи: ${input.name} (${input.relation})`);
      return { id: Number(res[0].insertId) };
    }),

  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        name: z.string().min(1),
        relation: z.string().min(1),
        sex: z.enum(["male", "female"]),
        birthDate: z.string().optional(),
        bloodType: z.string().optional(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      await getDb()
        .update(familyMembers)
        .set({
          name: input.name,
          relation: input.relation,
          sex: input.sex,
          birthDate: input.birthDate || null,
          bloodType: input.bloodType,
          notes: input.notes,
        })
        .where(eq(familyMembers.id, input.id));
      return { ok: true };
    }),

  remove: publicQuery.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
    const db = getDb();
    await db.delete(familyMeasurements).where(eq(familyMeasurements.memberId, input.id));
    await db.delete(familyDocuments).where(eq(familyDocuments.memberId, input.id));
    await db.delete(familyMembers).where(eq(familyMembers.id, input.id));
    await log("family", `Удалён член семьи #${input.id}`);
    return { ok: true };
  }),

  addDocument: publicQuery
    .input(
      z.object({
        memberId: z.number(),
        title: z.string().min(1),
        docType: z.enum(["analysis", "conclusion", "discharge", "instrumental", "vaccine", "other"]),
        docDate: z.string(),
        source: z.string().optional(),
        content: z.string().optional(),
        autoExtract: z.boolean().default(true),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const res = await db.insert(familyDocuments).values({
        memberId: input.memberId,
        title: input.title,
        docType: input.docType,
        docDate: input.docDate,
        source: input.source,
        content: input.content,
      });
      const docId = Number(res[0].insertId);
      let extracted: { name: string; value: number; unit: string }[] = [];
      if (input.autoExtract && input.content) {
        const found = await extractFromText(input.content);
        for (const f of found) {
          await db.insert(familyMeasurements).values({
            memberId: input.memberId,
            biomarkerId: f.biomarkerId,
            documentId: docId,
            value: f.value,
            measuredAt: input.docDate,
          });
        }
        extracted = found.map(({ name, value, unit }) => ({ name, value, unit }));
      }
      await log("family", `Документ «${input.title}» для члена семьи #${input.memberId}, извлечено: ${extracted.length}`);
      return { id: docId, extracted };
    }),

  removeDocument: publicQuery.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
    const db = getDb();
    await db.delete(familyMeasurements).where(eq(familyMeasurements.documentId, input.id));
    await db.delete(familyDocuments).where(eq(familyDocuments.id, input.id));
    return { ok: true };
  }),

  addMeasurement: publicQuery
    .input(
      z.object({
        memberId: z.number(),
        biomarkerId: z.number(),
        value: z.number(),
        measuredAt: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      await getDb().insert(familyMeasurements).values(input);
      return { ok: true };
    }),

  ask: publicQuery
    .input(z.object({ memberId: z.number(), question: z.string().min(1) }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const member = (await db.select().from(familyMembers).where(eq(familyMembers.id, input.memberId)))[0];
      const analyses = await memberAnalyses(input.memberId);
      const docs = await db
        .select()
        .from(familyDocuments)
        .where(eq(familyDocuments.memberId, input.memberId));
      const answer = answerQuestion(input.question, analyses, docs);
      await log("ai_query", `AI по члену семьи (${member?.name}): «${input.question.slice(0, 200)}»`);
      return { answer, memberName: member?.name };
    }),
});
