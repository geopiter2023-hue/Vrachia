import { createRouter, publicQuery } from "./middleware";
import { healthRouter } from "./healthRouter";
import { petsRouter } from "./petsRouter";
import { newsRouter } from "./newsRouter";
import { familyRouter } from "./familyRouter";
import { bpRouter } from "./bpRouter";
import { medOrgsRouter } from "./medOrgsRouter";
import { aiDoctorRouter } from "./aiDoctorRouter";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  health: healthRouter,
  pets: petsRouter,
  news: newsRouter,
  family: familyRouter,
  bp: bpRouter,
  medOrgs: medOrgsRouter,
  aiDoctor: aiDoctorRouter,
});

export type AppRouter = typeof appRouter;
