import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import {
  documents,
  biomarkers,
  measurements,
  vitals,
  clinics,
  notifications,
  auditLog,
  documentFiles,
} from "@db/schema";
import {
  CODE_DEFAULT_UNIT,
  extractBiomarkersFromText,
  pdfToText,
} from "./pdfExtract";
import { eq, desc, asc, and, gte, sql } from "drizzle-orm";
import {
  analyzeBiomarker,
  answerQuestion,
  buildRecommendations,
  detectCorrelations,
  detectRisks,
  describeBiomarker,
  type BiomarkerAnalysis,
} from "./analysis";

async function log(action: string, detail: string) {
  await getDb().insert(auditLog).values({ action, detail });
}

async function loadAnalyses(): Promise<{ analyses: BiomarkerAnalysis[]; docs: any[] }> {
  const db = getDb();
  const [bs, ms, docs] = await Promise.all([
    db.select().from(biomarkers),
    db.select().from(measurements),
    db.select().from(documents).orderBy(desc(documents.docDate)),
  ]);
  const analyses = bs.map((b) => analyzeBiomarker(b, ms.filter((m) => m.biomarkerId === Number(b.id))));
  return { analyses, docs };
}

// ── Извлечение биомаркеров из свободного текста (словарь синонимов) ──────
async function extractFromText(text: string) {
  const db = getDb();
  const bs = await db.select().from(biomarkers);
  const byCode = new Map(bs.map((b) => [b.code, b]));
  const items = extractBiomarkersFromText(text);
  const found: { biomarkerId: number; name: string; value: number; unit: string }[] = [];
  for (const it of items) {
    let bm = byCode.get(it.code);
    if (!bm) {
      // Создаём новый биомаркер автоматически
      try {
        const r = await db.insert(biomarkers).values({
          code: it.code,
          name: it.name,
          unit: it.unit || CODE_DEFAULT_UNIT[it.code] || "",
          refLow: it.refLow,
          refHigh: it.refHigh,
          category: it.category,
        });
        bm = {
          id: Number(r[0].insertId),
          code: it.code,
          name: it.name,
          unit: it.unit || CODE_DEFAULT_UNIT[it.code] || "",
          refLow: it.refLow,
          refHigh: it.refHigh,
          category: it.category,
        };
        byCode.set(it.code, bm);
      } catch {
        bm = byCode.get(it.code);
        if (!bm) continue;
      }
    }
    if (!bm) continue;
    found.push({ biomarkerId: Number(bm.id), name: bm.name, value: it.value, unit: bm.unit });
  }
  return found;
}

export const healthRouter = createRouter({
  // ─── Дашборд ──────────────────────────────────────────────────────────
  dashboard: publicQuery.query(async () => {
    const { analyses, docs } = await loadAnalyses();
    const withData = analyses.filter((a) => a.latest);
    const abnormal = withData.filter((a) => a.status !== "normal");
    const risks = detectRisks(withData);
    const corr = detectCorrelations(withData);
    const notifs = await getDb()
      .select()
      .from(notifications)
      .orderBy(desc(notifications.createdAt))
      .limit(10);
    return {
      totalBiomarkers: withData.length,
      abnormalCount: abnormal.length,
      documentsCount: docs.length,
      risks,
      correlations: corr,
      topBiomarkers: withData
        .slice()
        .sort((a, b) => (b.deviationPct ?? 0) - (a.deviationPct ?? 0))
        .slice(0, 6)
        .map((a) => ({
          code: a.biomarker.code,
          name: a.biomarker.name,
          unit: a.biomarker.unit,
          refLow: a.biomarker.refLow,
          refHigh: a.biomarker.refHigh,
          latest: a.latest,
          status: a.status,
          trend: a.trend,
          trendPct: a.trendPct,
        })),
      notifications: notifs,
      recentDocs: docs.slice(0, 5),
    };
  }),

  // ─── Документы ────────────────────────────────────────────────────────
  documents: createRouter({
    list: publicQuery.query(async () => {
      const db = getDb();
      const rows = await db.select().from(documents).orderBy(desc(documents.docDate));
      const chunked = await db
        .selectDistinct({ docId: documentFiles.docId })
        .from(documentFiles);
      const chunkedIds = new Set(chunked.map((r) => Number(r.docId)));
      return rows.map(({ fileData, ...d }) => ({
        ...d,
        hasFile: Boolean(fileData) || chunkedIds.has(Number(d.id)),
      }));
    }),
    create: publicQuery
      .input(
        z.object({
          title: z.string().min(1),
          docType: z.enum(["analysis", "conclusion", "discharge", "instrumental", "complaint", "anamnesis", "other"]),
          docDate: z.string(),
          source: z.string().optional(),
          fileName: z.string().optional(),
          fileMime: z.string().optional(),
          fileData: z.string().optional(),
          content: z.string().optional(),
          autoExtract: z.boolean().default(true),
        })
      )
      .mutation(async ({ input }) => {
        const db = getDb();

        // Распознаём текст PDF на сервере (если приложен текстовый PDF)
        let ocrText = "";
        const isPdf =
          (input.fileMime ?? "").includes("pdf") || /\.pdf$/i.test(input.fileName ?? "");
        if (input.fileData && isPdf) {
          try {
            const buf = Buffer.from(input.fileData, "base64");
            ocrText = (await pdfToText(buf)).slice(0, 50000);
          } catch {
            ocrText = "";
          }
        }
        const content = input.content || ocrText || undefined;

        // Дедупликация: такой же документ на ту же дату уже есть — не создаём дубль
        const dup = await db
          .select({ id: documents.id })
          .from(documents)
          .where(and(eq(documents.title, input.title), eq(documents.docDate, input.docDate)))
          .limit(1);
        if (dup.length) {
          return { id: Number(dup[0].id), extracted: [], duplicated: true };
        }

        const res = await db.insert(documents).values({
          title: input.title,
          docType: input.docType,
          docDate: input.docDate,
          source: input.source,
          fileName: input.fileName,
          fileMime: input.fileMime,
          content,
        });
        const docId = Number(res[0].insertId);
        // Файл храним чанками — в БД действует лимит ~6 МБ на одну строку
        if (input.fileData) {
          const CHUNK = 1_500_000;
          const chunks: { docId: number; chunk: number; data: string }[] = [];
          for (let i = 0; i < input.fileData.length; i += CHUNK) {
            chunks.push({ docId, chunk: chunks.length, data: input.fileData.slice(i, i + CHUNK) });
          }
          for (const c of chunks) {
            await db.insert(documentFiles).values(c);
          }
        }
        let extracted: { name: string; value: number; unit: string }[] = [];
        if (input.autoExtract && content) {
          const found = await extractFromText(content);
          for (const f of found) {
            await db.insert(measurements).values({
              biomarkerId: f.biomarkerId,
              documentId: docId,
              value: f.value,
              measuredAt: input.docDate,
            });
          }
          extracted = found.map(({ name, value, unit }) => ({ name, value, unit }));
        }
        await log("upload", `Загружен документ «${input.title}» (${input.docType}), извлечено показателей: ${extracted.length}`);
        return { id: docId, extracted };
      }),
    remove: publicQuery.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(measurements).where(eq(measurements.documentId, input.id));
      await db.delete(documentFiles).where(eq(documentFiles.docId, input.id));
      await db.delete(documents).where(eq(documents.id, input.id));
      await log("delete", `Удалён документ #${input.id}`);
      return { ok: true };
    }),

    // Переобработать все документы: распознать PDF, извлечь биомаркеры, убрать дубли
    reprocess: publicQuery.mutation(async () => {
      const db = getDb();
      const docs = await db.select().from(documents).orderBy(asc(documents.id));
      const seen = new Map<string, number>();
      let docsProcessed = 0, docsDeleted = 0, markersFound = 0;
      for (const d of docs) {
        const id = Number(d.id);
        const dateStr = String(d.docDate).slice(0, 10);
        const key = `${d.title}|${dateStr}`;
        if (seen.has(key)) {
          // дубль документа — удаляем
          await db.delete(measurements).where(eq(measurements.documentId, id));
          await db.delete(documentFiles).where(eq(documentFiles.docId, id));
          await db.delete(documents).where(eq(documents.id, id));
          docsDeleted++;
          continue;
        }
        seen.set(key, id);

        // Достаём текст: content либо OCR из сохранённого PDF
        let text = d.content ?? "";
        if (!text) {
          let base64 = d.fileData ?? "";
          if (!base64) {
            const chunks = await db
              .select({ data: documentFiles.data })
              .from(documentFiles)
              .where(eq(documentFiles.docId, id))
              .orderBy(asc(documentFiles.chunk));
            base64 = chunks.map((r) => r.data).join("");
          }
          if (base64) {
            try {
              text = (await pdfToText(Buffer.from(base64, "base64"))).slice(0, 50000);
            } catch {
              text = "";
            }
            if (text) {
              await db.update(documents).set({ content: text }).where(eq(documents.id, id));
            }
          }
        }
        if (!text) continue;

        // Старые измерения этого документа удаляем, извлекаем заново
        await db.delete(measurements).where(eq(measurements.documentId, id));
        const found = await extractFromText(text);
        for (const f of found) {
          await db.insert(measurements).values({
            biomarkerId: f.biomarkerId,
            documentId: id,
            value: f.value,
            measuredAt: dateStr,
          });
        }
        markersFound += found.length;
        docsProcessed++;
      }
      await log("reprocess", `Переобработка документов: обработано ${docsProcessed}, удалено дублей ${docsDeleted}, извлечено показателей ${markersFound}`);
      return { docsProcessed, docsDeleted, markersFound };
    }),
  }),

  // ─── Биомаркеры и измерения ───────────────────────────────────────────
  biomarkers: createRouter({
    list: publicQuery.query(async () => {
      const { analyses } = await loadAnalyses();
      return analyses.map((a) => ({
        biomarker: a.biomarker,
        points: a.points,
        latest: a.latest,
        status: a.status,
        trend: a.trend,
        trendPct: a.trendPct,
        deviationPct: a.deviationPct,
      }));
    }),
    addMeasurement: publicQuery
      .input(
        z.object({
          biomarkerId: z.number(),
          value: z.number(),
          measuredAt: z.string(),
          note: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const db = getDb();
        await db.insert(measurements).values({
          biomarkerId: input.biomarkerId,
          value: input.value,
          measuredAt: input.measuredAt,
          note: input.note,
        });
        const b = (await db.select().from(biomarkers).where(eq(biomarkers.id, input.biomarkerId)))[0];
        await log("measurement", `Добавлено измерение: ${b?.name ?? input.biomarkerId} = ${input.value} (${input.measuredAt})`);
        // Уведомление при отклонении
        if (b && b.refLow != null && b.refHigh != null && (input.value < b.refLow || input.value > b.refHigh)) {
          await db.insert(notifications).values({
            title: `Отклонение: ${b.name}`,
            body: `Значение ${input.value} ${b.unit} вне нормы (${b.refLow}–${b.refHigh}) от ${input.measuredAt}.`,
            severity: "warning",
          });
        }
        return { ok: true };
      }),
  }),

  // ─── Физиологические показатели ───────────────────────────────────────
  vitals: createRouter({
    list: publicQuery
      .input(z.object({ type: z.string().optional(), days: z.number().default(90) }))
      .query(async ({ input }) => {
        const db = getDb();
        const since = new Date(Date.now() - input.days * 864e5);
        const conds = [gte(vitals.measuredAt, since)];
        if (input.type) conds.push(eq(vitals.vitalType, input.type as any));
        return db.select().from(vitals).where(and(...conds)).orderBy(asc(vitals.measuredAt));
      }),
    add: publicQuery
      .input(
        z.object({
          vitalType: z.enum(["pressure_sys", "pressure_dia", "pulse", "temperature", "weight", "spo2"]),
          value: z.number(),
          measuredAt: z.string(), // ISO
        })
      )
      .mutation(async ({ input }) => {
        const db = getDb();
        await db.insert(vitals).values({
          vitalType: input.vitalType,
          value: input.value,
          measuredAt: new Date(input.measuredAt),
          source: "manual",
        });
        await log("vital", `Добавлен показатель ${input.vitalType} = ${input.value}`);
        if (input.vitalType === "pressure_sys" && input.value >= 160) {
          await db.insert(notifications).values({
            title: "Высокое артериальное давление",
            body: `Систолическое давление ${input.value} мм рт. ст. — критическое значение.`,
            severity: "critical",
          });
        }
        return { ok: true };
      }),
  }),

  // ─── AI-ассистент ─────────────────────────────────────────────────────
  assistant: createRouter({
    ask: publicQuery.input(z.object({ question: z.string().min(1) })).mutation(async ({ input }) => {
      const { analyses, docs } = await loadAnalyses();
      const answer = answerQuestion(input.question, analyses, docs);
      await log("ai_query", `Вопрос: «${input.question.slice(0, 200)}»`);
      return { answer };
    }),
  }),

  // ─── Рекомендации по питанию и спорту ─────────────────────────────────
  recommendations: publicQuery.query(async () => {
    const db = getDb();
    const { analyses } = await loadAnalyses();
    const recentVitals = await db
      .select()
      .from(vitals)
      .orderBy(desc(vitals.measuredAt))
      .limit(200);
    const lastOf = (t: string) => recentVitals.find((v) => v.vitalType === t)?.value;
    const recs = buildRecommendations(analyses.filter((a) => a.latest), {
      weight: lastOf("weight"),
      pressureSys: lastOf("pressure_sys"),
      pressureDia: lastOf("pressure_dia"),
      pulse: lastOf("pulse"),
    });
    return recs;
  }),

  // ─── Клиники ──────────────────────────────────────────────────────────
  clinics: createRouter({
    list: publicQuery
      .input(
        z.object({
          city: z.string().optional(),
          specialization: z.string().optional(),
          maxPrice: z.number().optional(),
          minRating: z.number().optional(),
          sortBy: z.enum(["value", "price", "rating"]).default("value"),
        })
      )
      .query(async ({ input }) => {
        const db = getDb();
        let rows = await db.select().from(clinics);
        if (input.city) rows = rows.filter((c) => c.city.toLowerCase().includes(input.city!.toLowerCase()));
        if (input.specialization)
          rows = rows.filter((c) => c.specialization.toLowerCase().includes(input.specialization!.toLowerCase()));
        if (input.maxPrice != null) rows = rows.filter((c) => (c.priceFrom ?? Infinity) <= input.maxPrice!);
        if (input.minRating != null) rows = rows.filter((c) => (c.rating ?? 0) >= input.minRating!);
        const score = (c: any) => (((c.rating ?? 0) * 20) / Math.max(c.priceFrom ?? 1, 1)) * 1000 + (c.reviewsCount ?? 0) / 500;
        rows.sort((a, b) =>
          input.sortBy === "price"
            ? (a.priceFrom ?? Infinity) - (b.priceFrom ?? Infinity)
            : input.sortBy === "rating"
              ? (b.rating ?? 0) - (a.rating ?? 0)
              : score(b) - score(a)
        );
        return rows;
      }),
    specializations: publicQuery.query(async () => {
      const rows = await getDb().select({ s: clinics.specialization, c: clinics.city }).from(clinics);
      return {
        specializations: [...new Set(rows.map((r) => r.s))].sort(),
        cities: [...new Set(rows.map((r) => r.c))].sort(),
      };
    }),
  }),

  // ─── Уведомления ──────────────────────────────────────────────────────
  notifications: createRouter({
    list: publicQuery.query(async () =>
      getDb().select().from(notifications).orderBy(desc(notifications.createdAt)).limit(50)
    ),
    markRead: publicQuery.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      await getDb().update(notifications).set({ isRead: true }).where(eq(notifications.id, input.id));
      return { ok: true };
    }),
    markAllRead: publicQuery.mutation(async () => {
      await getDb().update(notifications).set({ isRead: true }).where(eq(notifications.isRead, false));
      return { ok: true };
    }),
  }),

  // ─── Отчёты и экспорт ─────────────────────────────────────────────────
  reports: createRouter({
    data: publicQuery
      .input(z.object({ from: z.string().optional(), to: z.string().optional() }))
      .query(async ({ input }) => {
        const { analyses, docs } = await loadAnalyses();
        const inRange = (d: string) =>
          (!input.from || d >= input.from) && (!input.to || d <= input.to);
        const filteredDocs = docs.filter((d) => inRange(String(d.docDate)));
        const filteredAnalyses = analyses
          .map((a) => ({ ...a, points: a.points.filter((p) => inRange(p.date)) }))
          .filter((a) => a.points.length);
        return {
          docs: filteredDocs,
          biomarkers: filteredAnalyses.map((a) => ({
            biomarker: a.biomarker,
            points: a.points,
            status: a.status,
            trend: a.trend,
            trendPct: a.trendPct,
          })),
          interpretations: filteredAnalyses
            .filter((a) => a.status !== "normal" && a.latest)
            .map((a) => describeBiomarker(a, docs)),
          risks: detectRisks(analyses.filter((a) => a.latest)),
          correlations: detectCorrelations(analyses.filter((a) => a.latest)),
        };
      }),
    fhir: publicQuery.query(async () => {
      const { analyses } = await loadAnalyses();
      const entries: any[] = [];
      for (const a of analyses) {
        for (const p of a.points) {
          entries.push({
            resource: {
              resourceType: "Observation",
              status: "final",
              code: { coding: [{ code: a.biomarker.code, display: a.biomarker.name }] },
              effectiveDateTime: p.date,
              valueQuantity: { value: p.value, unit: a.biomarker.unit },
              referenceRange:
                a.biomarker.refLow != null && a.biomarker.refHigh != null
                  ? [{ low: { value: a.biomarker.refLow }, high: { value: a.biomarker.refHigh } }]
                  : undefined,
            },
          });
        }
      }
      await log("export", "Экспорт данных в формате FHIR R4 (Bundle)");
      return {
        resourceType: "Bundle",
        type: "collection",
        timestamp: new Date().toISOString(),
        total: entries.length,
        entry: entries,
      };
    }),
    csv: publicQuery.query(async () => {
      const { analyses } = await loadAnalyses();
      const rows = ["code;name;date;value;unit;ref_low;ref_high"];
      for (const a of analyses)
        for (const p of a.points)
          rows.push(
            `${a.biomarker.code};${a.biomarker.name};${p.date};${p.value};${a.biomarker.unit};${a.biomarker.refLow ?? ""};${a.biomarker.refHigh ?? ""}`
          );
      await log("export", "Экспорт данных в CSV");
      return { csv: rows.join("\n") };
    }),
  }),

  // ─── Медкарта: хронология по годам и месяцам ──────────────────────────
  timeline: publicQuery.query(async () => {
    const db = getDb();
    const [docs, bs, ms, vs] = await Promise.all([
      db.select().from(documents).orderBy(desc(documents.docDate)),
      db.select().from(biomarkers),
      db.select().from(measurements),
      db.select().from(vitals),
    ]);
    const bmById = new Map(bs.map((b) => [Number(b.id), b]));
    const docById = new Map(docs.map((d) => [Number(d.id), d]));

    type TlItem = {
      date: string;
      year: number;
      month: number;
      category: "document" | "measurement" | "vaccine" | "vital";
      title: string;
      detail: string;
      extra?: any;
    };
    const items: TlItem[] = [];

    // Документы
    for (const d of docs) {
      const date = String(d.docDate);
      const [y, m] = date.split("-").map(Number);
      const isVaccine = /привив|вакцин/i.test(d.title + " " + (d.content ?? ""));
      items.push({
        date, year: y, month: m,
        category: isVaccine ? "vaccine" : "document",
        title: d.title,
        detail: [d.docType, d.source].filter(Boolean).join(" · "),
        extra: { docType: d.docType, content: d.content },
      });
    }
    // Измерения, сгруппированные по документу/дате — как пункт «Анализы»
    const byKey = new Map<string, { values: string[]; docId: number | null }>();
    for (const m of ms) {
      const b = bmById.get(m.biomarkerId);
      if (!b) continue;
      const key = String(m.measuredAt) + "|" + (m.documentId ?? "manual");
      if (!byKey.has(key)) byKey.set(key, { values: [], docId: m.documentId });
      const entry = byKey.get(key)!;
      const abnormal = b.refLow != null && b.refHigh != null && (m.value < b.refLow || m.value > b.refHigh);
      entry.values.push(`${b.name} ${m.value} ${b.unit}${abnormal ? " ⚠" : ""}`);
    }
    for (const [key, v] of byKey) {
      const [date] = key.split("|");
      const [y, m] = date.split("-").map(Number);
      const doc = v.docId ? docById.get(v.docId) : null;
      items.push({
        date, year: y, month: m,
        category: "measurement",
        title: doc ? `Показатели: ${doc.title}` : "Ручной ввод показателей",
        detail: v.values.join("; "),
      });
    }
    // Физиология — агрегация по месяцу (средние значения)
    const vitalByMonth = new Map<string, Record<string, number[]>>();
    const VITAL_NAMES: Record<string, string> = {
      pressure_sys: "АД сист.", pressure_dia: "АД диаст.", pulse: "Пульс",
      temperature: "Температура", weight: "Вес", spo2: "SpO₂",
    };
    for (const v of vs) {
      const d = new Date(v.measuredAt);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      if (!vitalByMonth.has(key)) vitalByMonth.set(key, {});
      const rec = vitalByMonth.get(key)!;
      (rec[v.vitalType] ??= []).push(v.value);
    }
    for (const [key, rec] of vitalByMonth) {
      const [y, m] = key.split("-").map(Number);
      const parts = Object.entries(rec).map(([t, vals]) => {
        const avg = vals.reduce((a, c) => a + c, 0) / vals.length;
        const min = Math.min(...vals), max = Math.max(...vals);
        return `${VITAL_NAMES[t]}: ср. ${avg.toFixed(0)} (${min}–${max})`;
      });
      items.push({
        date: `${key}-15`, year: y, month: m,
        category: "vital",
        title: "Физиология за месяц",
        detail: parts.join("; "),
      });
    }

    // Сортировка и группировка по годам/месяцам
    items.sort((a, b) => b.date.localeCompare(a.date));
    const years: Record<number, Record<number, TlItem[]>> = {};
    for (const i of items) {
      (years[i.year] ??= {});
      (years[i.year][i.month] ??= []).push(i);
    }
    await log("export", "Просмотр медкарты (хронология)");
    return { years: Object.keys(years).map(Number).sort((a, b) => b - a).map((y) => ({
      year: y,
      months: Object.keys(years[y]).map(Number).sort((a, b) => b - a).map((m) => ({
        month: m,
        items: years[y][m],
      })),
    }))};
  }),

  // ─── Аудит ────────────────────────────────────────────────────────────
  audit: createRouter({
    list: publicQuery.query(async () =>
      getDb().select().from(auditLog).orderBy(desc(auditLog.createdAt)).limit(100)
    ),
  }),
});

// ── Автоматическое извлечение показателей при старте сервера ────────────
// Если в базе есть документы, но нет ни одного измерения (например, документы
// были загружены старой версией приложения), запускаем переобработку фоном.
export async function autoReprocessIfNeeded() {
  try {
    const db = getDb();
    const [docCnt] = await db.select({ n: sql`count(*)` }).from(documents);
    if (!Number(docCnt?.n ?? 0)) return;
    const [mCnt] = await db.select({ n: sql`count(*)` }).from(measurements);
    if (Number(mCnt?.n ?? 0) > 0) return;
    const docs = await db.select().from(documents).orderBy(asc(documents.id));
    for (const d of docs) {
      const id = Number(d.id);
      const dateStr = String(d.docDate).slice(0, 10);
      let text = d.content ?? "";
      if (!text) {
        let base64 = d.fileData ?? "";
        if (!base64) {
          try {
            const chunks = await db
              .select({ data: documentFiles.data })
              .from(documentFiles)
              .where(eq(documentFiles.docId, id))
              .orderBy(asc(documentFiles.chunk));
            base64 = chunks.map((r) => r.data).join("");
          } catch {
            base64 = "";
          }
        }
        if (base64) {
          try {
            text = (await pdfToText(Buffer.from(base64, "base64"))).slice(0, 50000);
          } catch {
            text = "";
          }
          if (text) await db.update(documents).set({ content: text }).where(eq(documents.id, id));
        }
      }
      if (!text) continue;
      const found = await extractFromText(text);
      for (const f of found) {
        await db.insert(measurements).values({
          biomarkerId: f.biomarkerId,
          documentId: id,
          value: f.value,
          measuredAt: dateStr,
        });
      }
    }
    await log("auto_reprocess", "Автоматическое извлечение показателей из загруженных документов");
  } catch (e) {
    console.error("autoReprocessIfNeeded failed:", e);
  }
}
