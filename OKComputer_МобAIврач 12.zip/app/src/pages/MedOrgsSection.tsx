import { useEffect, useMemo, useState } from "react";
import { trpc } from "@/providers/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Building2,
  MapPin,
  Phone,
  Mail,
  Globe,
  Clock,
  ChevronDown,
  Search,
  ExternalLink,
  Stethoscope,
  Syringe,
  User,
  Info,
  PawPrint,
  FlaskConical,
} from "lucide-react";

const CAT_ICONS: Record<string, typeof Building2> = {
  "Больницы": Building2,
  "Поликлиники и клиники": Stethoscope,
  "Кабинеты врачей": User,
  "Стоматологии": Syringe,
  "Ветклиники": PawPrint,
  "Прочие медучреждения": FlaskConical,
};

type MedOrg = {
  id: number | bigint;
  category: string;
  subtype: string | null;
  name: string;
  services: string | null;
  specialties: string | null;
  address: string | null;
  lat: number | null;
  lon: number | null;
  phone: string | null;
  phone2: string | null;
  email: string | null;
  website: string | null;
  openingHours: string | null;
  operator: string | null;
  info: string | null;
};

function mapUrl(o: MedOrg) {
  if (o.lat != null && o.lon != null) {
    return `https://yandex.ru/maps/?pt=${o.lon},${o.lat}&z=16&l=map`;
  }
  return `https://yandex.ru/maps/?text=${encodeURIComponent(`${o.address ?? ""} ${o.name}`)}`;
}

function OrgCard({ org }: { org: MedOrg }) {
  const [open, setOpen] = useState(false);
  const Icon = CAT_ICONS[org.category] ?? Building2;
  return (
    <Card className="cursor-pointer transition-all hover:shadow-sm" onClick={() => setOpen(!open)}>
      <CardContent className="py-4 space-y-2.5">
        <div className="flex items-start gap-3">
          <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
            <Icon className="h-5 w-5 text-primary" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="font-medium leading-snug">{org.name}</div>
            <div className="flex flex-wrap items-center gap-x-2 gap-y-1 mt-1">
              <Badge variant="secondary" className="text-[11px]">{org.category}</Badge>
              {org.subtype && <Badge variant="outline" className="text-[11px]">{org.subtype}</Badge>}
            </div>
            {org.address && (
              <div className="text-xs text-muted-foreground flex items-center gap-1 mt-1.5">
                <MapPin className="h-3 w-3 shrink-0" /> {org.address}
              </div>
            )}
          </div>
          <ChevronDown className={`h-5 w-5 text-muted-foreground shrink-0 transition-transform ${open ? "rotate-180" : ""}`} />
        </div>

        {open && (
          <div className="space-y-2.5 pt-2 border-t text-sm" onClick={(e) => e.stopPropagation()}>
            {org.address && (
              <div className="flex items-start gap-2.5">
                <MapPin className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                <div>
                  <div className="text-xs text-muted-foreground">Адрес</div>
                  <div>{org.address}</div>
                  <a href={mapUrl(org)} target="_blank" rel="noreferrer"
                     className="text-xs text-primary inline-flex items-center gap-1 mt-1 hover:underline">
                    Показать на карте <ExternalLink className="h-3 w-3" />
                  </a>
                </div>
              </div>
            )}
            {!org.address && org.lat != null && (
              <a href={mapUrl(org)} target="_blank" rel="noreferrer"
                 className="text-xs text-primary inline-flex items-center gap-1 hover:underline">
                <MapPin className="h-3.5 w-3.5" /> Показать на карте <ExternalLink className="h-3 w-3" />
              </a>
            )}
            {org.openingHours && (
              <div className="flex items-start gap-2.5">
                <Clock className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                <div>
                  <div className="text-xs text-muted-foreground">Часы работы</div>
                  <div>{org.openingHours}</div>
                </div>
              </div>
            )}
            {(org.phone || org.phone2) && (
              <div className="flex items-start gap-2.5">
                <Phone className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                <div>
                  <div className="text-xs text-muted-foreground">Телефон</div>
                  <div className="space-y-0.5">
                    {[org.phone, org.phone2].filter(Boolean).map((p) => (
                      <div key={p}>
                        <a href={`tel:${String(p).replace(/[^+\d]/g, "")}`} className="text-primary hover:underline">{p}</a>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
            {org.email && (
              <div className="flex items-start gap-2.5">
                <Mail className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                <div>
                  <div className="text-xs text-muted-foreground">E-mail</div>
                  <a href={`mailto:${org.email}`} className="text-primary hover:underline break-all">{org.email}</a>
                </div>
              </div>
            )}
            {org.website && (
              <div className="flex items-start gap-2.5">
                <Globe className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                <div>
                  <div className="text-xs text-muted-foreground">Сайт</div>
                  <a href={org.website.startsWith("http") ? org.website : `https://${org.website}`}
                     target="_blank" rel="noreferrer" className="text-primary hover:underline break-all">
                    {org.website}
                  </a>
                </div>
              </div>
            )}
            {org.specialties && (
              <div className="flex items-start gap-2.5">
                <Stethoscope className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                <div>
                  <div className="text-xs text-muted-foreground">Специальности врачей</div>
                  <div>{org.specialties}</div>
                </div>
              </div>
            )}
            {org.services && (
              <div className="flex items-start gap-2.5">
                <Syringe className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                <div>
                  <div className="text-xs text-muted-foreground">Процедуры и услуги</div>
                  <div>{org.services}</div>
                </div>
              </div>
            )}
            {org.operator && (
              <div className="flex items-start gap-2.5">
                <Building2 className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                <div>
                  <div className="text-xs text-muted-foreground">Оператор / сеть</div>
                  <div>{org.operator}</div>
                </div>
              </div>
            )}
            {org.info && (
              <div className="flex items-start gap-2.5">
                <Info className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                <div>
                  <div className="text-xs text-muted-foreground">Дополнительно</div>
                  <div>{org.info}</div>
                </div>
              </div>
            )}
            {!org.address && !org.phone && !org.openingHours && !org.specialties && !org.services && !org.info && (
              <div className="text-xs text-muted-foreground">
                Дополнительные данные по этому учреждению пока не указаны в открытых источниках.
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default function MedOrgsSection() {
  const [category, setCategory] = useState<string>("");
  const [subtype, setSubtype] = useState<string>("");
  const [q, setQ] = useState("");
  const [qDeb, setQDeb] = useState("");
  const [limit, setLimit] = useState(50);

  useEffect(() => {
    const t = setTimeout(() => setQDeb(q.trim()), 400);
    return () => clearTimeout(t);
  }, [q]);

  useEffect(() => {
    setLimit(50);
  }, [category, subtype, qDeb]);

  useEffect(() => {
    setSubtype("");
  }, [category]);

  const { data: stats, isError: statsError, refetch: refetchStats } = trpc.medOrgs.stats.useQuery(undefined, {
    retry: 2,
    refetchInterval: (q) => (q.state.data?.seeding ? 4000 : false),
  });
  const { data: subtypes } = trpc.medOrgs.subtypes.useQuery(
    { category },
    { enabled: Boolean(category) }
  );
  const { data, isLoading, isFetching, isError: listError, refetch: refetchList } = trpc.medOrgs.list.useQuery(
    {
      category: category || undefined,
      subtype: subtype || undefined,
      q: qDeb || undefined,
      limit,
      offset: 0,
    },
    {
      retry: 2,
      refetchInterval: (q) => (q.state.data?.seeding ? 4000 : false),
    }
  );

  const seeding = Boolean(stats?.seeding || data?.seeding);
  const cats = useMemo(() => stats?.byCategory ?? [], [stats]);
  const total = data?.total ?? 0;

  return (
    <div className="space-y-4">
      <div className="relative">
        <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
        <Input
          className="pl-9"
          placeholder="Поиск по названию, адресу, оператору…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
      </div>

      <div className="flex gap-1.5 overflow-x-auto pb-1 -mx-1 px-1" style={{ scrollbarWidth: "none" }}>
        <button
          onClick={() => setCategory("")}
          className={`shrink-0 rounded-full px-3 py-1.5 text-xs font-medium border transition-colors ${
            !category ? "bg-primary text-primary-foreground border-primary" : "bg-background text-muted-foreground"
          }`}
        >
          Все · {stats?.total.toLocaleString("ru-RU") ?? "…"}
        </button>
        {cats.map((c) => (
          <button
            key={c.category}
            onClick={() => setCategory(category === c.category ? "" : c.category)}
            className={`shrink-0 rounded-full px-3 py-1.5 text-xs font-medium border transition-colors ${
              category === c.category ? "bg-primary text-primary-foreground border-primary" : "bg-background text-muted-foreground"
            }`}
          >
            {c.category} · {c.count.toLocaleString("ru-RU")}
          </button>
        ))}
      </div>

      {/* Специализации внутри выбранного направления */}
      {category && (subtypes?.length ?? 0) > 1 && (
        <div className="flex gap-1.5 overflow-x-auto pb-1 -mx-1 px-1" style={{ scrollbarWidth: "none" }}>
          <button
            onClick={() => setSubtype("")}
            className={`shrink-0 rounded-full px-3 py-1 text-[11px] font-medium border transition-colors ${
              !subtype ? "bg-teal-600 text-white border-teal-600" : "bg-background text-muted-foreground"
            }`}
          >
            Все специализации
          </button>
          {subtypes!.map((s) => (
            <button
              key={s.subtype}
              onClick={() => setSubtype(subtype === s.subtype ? "" : s.subtype)}
              className={`shrink-0 rounded-full px-3 py-1 text-[11px] font-medium border transition-colors ${
                subtype === s.subtype ? "bg-teal-600 text-white border-teal-600" : "bg-background text-muted-foreground"
              }`}
            >
              {s.subtype} · {s.count.toLocaleString("ru-RU")}
            </button>
          ))}
        </div>
      )}

      <div className="text-xs text-muted-foreground">
        {isLoading ? "Загрузка…" : `Найдено: ${total.toLocaleString("ru-RU")} · показано ${Math.min(limit, total)}`}
        {isFetching && !isLoading ? " · обновляю…" : ""}
      </div>

      {seeding ? (
        <div className="text-center py-12 space-y-2">
          <div className="text-sm font-medium">Загружаем базу медучреждений…</div>
          <div className="text-xs text-muted-foreground">50 949 учреждений по всей России — это займёт меньше минуты, страницу можно не закрывать</div>
          <div className="flex justify-center gap-1.5 pt-2">
            {[0, 1, 2].map((i) => <Skeleton key={i} className="h-20 w-full max-w-[110px]" />)}
          </div>
        </div>
      ) : statsError || listError ? (
        <div className="text-center py-12 space-y-3">
          <div className="text-sm text-muted-foreground">Не удалось загрузить список учреждений</div>
          <Button variant="outline" size="sm" onClick={() => { void refetchStats(); void refetchList(); }}>
            Повторить
          </Button>
        </div>
      ) : isLoading ? (
        <div className="space-y-2.5">
          {[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-20" />)}
        </div>
      ) : (
        <div className="space-y-2.5">
          {(data?.items ?? []).map((raw) => (
            <OrgCard key={Number(raw.id)} org={raw as unknown as MedOrg} />
          ))}
          {total === 0 && (
            <div className="text-center text-muted-foreground py-12 text-sm">
              По запросу ничего не найдено
            </div>
          )}
        </div>
      )}

      {total > limit && (
        <Button variant="outline" className="w-full" disabled={isFetching} onClick={() => setLimit((v) => v + 50)}>
          {isFetching ? "Загружаю…" : `Показать ещё (${(total - limit).toLocaleString("ru-RU")})`}
        </Button>
      )}
    </div>
  );
}
