import { initTRPC, TRPCError } from "@trpc/server";
import superjson from "superjson";
import type { TrpcContext } from "./context";
import { getSessionUser } from "./session";
import { ensureUserScope, claimLegacyData } from "./userScope";

const t = initTRPC.context<TrpcContext>().create({
  transformer: superjson,
});

export const createRouter = t.router;
export const publicQuery = t.procedure;

// Процедура, требующая авторизации: кладёт ctx.user (id — всегда number)
export const userProcedure = t.procedure.use(async ({ ctx, next }) => {
  const user = await getSessionUser(ctx.req);
  if (!user) {
    throw new TRPCError({ code: "UNAUTHORIZED", message: "Требуется вход в аккаунт" });
  }
  const userId = Number(user.id);
  // Самолечащаяся миграция: колонки user_id + наследование старых данных
  await ensureUserScope();
  void claimLegacyData(userId);
  return next({ ctx: { ...ctx, user: { ...user, id: userId } } });
});
