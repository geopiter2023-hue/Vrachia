import { getDb } from "../api/queries/connection";
import {
  documents,
  biomarkers,
  measurements,
  vitals,
  clinics,
  notifications,
  auditLog,
} from "./schema";

async function seed() {
  const db = getDb();
  console.log("Seeding database...");

  // ── Справочник биомаркеров ─────────────────────────────────────────────
  const bmData = [
    { code: "HGB", name: "Гемоглобин", unit: "г/л", refLow: 130, refHigh: 160, category: "Общий анализ крови" },
    { code: "RBC", name: "Эритроциты", unit: "×10¹²/л", refLow: 4.0, refHigh: 5.1, category: "Общий анализ крови" },
    { code: "WBC", name: "Лейкоциты", unit: "×10⁹/л", refLow: 4.0, refHigh: 9.0, category: "Общий анализ крови" },
    { code: "PLT", name: "Тромбоциты", unit: "×10⁹/л", refLow: 150, refHigh: 400, category: "Общий анализ крови" },
    { code: "ESR", name: "СОЭ", unit: "мм/ч", refLow: 2, refHigh: 15, category: "Общий анализ крови" },
    { code: "GLU", name: "Глюкоза", unit: "ммоль/л", refLow: 3.9, refHigh: 6.1, category: "Биохимия" },
    { code: "HBA1C", name: "Гликированный гемоглобин (HbA1c)", unit: "%", refLow: 4.0, refHigh: 6.0, category: "Биохимия" },
    { code: "CHOL", name: "Холестерин общий", unit: "ммоль/л", refLow: 3.0, refHigh: 5.2, category: "Липидный профиль" },
    { code: "LDL", name: "ЛПНП", unit: "ммоль/л", refLow: 0, refHigh: 3.0, category: "Липидный профиль" },
    { code: "HDL", name: "ЛПВП", unit: "ммоль/л", refLow: 1.0, refHigh: 2.2, category: "Липидный профиль" },
    { code: "TG", name: "Триглицериды", unit: "ммоль/л", refLow: 0.45, refHigh: 1.7, category: "Липидный профиль" },
    { code: "ALT", name: "АЛТ", unit: "Ед/л", refLow: 0, refHigh: 41, category: "Печёночные пробы" },
    { code: "AST", name: "АСТ", unit: "Ед/л", refLow: 0, refHigh: 40, category: "Печёночные пробы" },
    { code: "CREAT", name: "Креатинин", unit: "мкмоль/л", refLow: 62, refHigh: 106, category: "Биохимия" },
    { code: "URIC", name: "Мочевая кислота", unit: "мкмоль/л", refLow: 200, refHigh: 420, category: "Биохимия" },
    { code: "TSH", name: "ТТГ", unit: "мМЕ/л", refLow: 0.4, refHigh: 4.0, category: "Гормоны" },
    { code: "VITD", name: "Витамин D (25-OH)", unit: "нг/мл", refLow: 30, refHigh: 100, category: "Витамины" },
    { code: "FERR", name: "Ферритин", unit: "мкг/л", refLow: 30, refHigh: 400, category: "Биохимия" },
  ];
  await db.insert(biomarkers).values(bmData);
  const bmRows = await db.select().from(biomarkers);
  const bm = Object.fromEntries(bmRows.map((b) => [b.code, Number(b.id)]));

  // ── Документы ─────────────────────────────────────────────────────────
  const docData = [
    {
      title: "Общий и биохимический анализ крови",
      docType: "analysis" as const,
      docDate: "2024-11-12",
      source: "Лаборатория «Инвитро»",
      fileName: "blood_2024-11-12.pdf",
      content:
        "Гемоглобин 142 г/л. Эритроциты 4.6. Лейкоциты 5.8. Тромбоциты 240. СОЭ 8. Глюкоза 5.4 ммоль/л. Холестерин общий 5.4 ммоль/л. ЛПНП 3.2. ЛПВП 1.3. Триглицериды 1.5. АЛТ 28. АСТ 26. Креатинин 88. Мочевая кислота 395.",
    },
    {
      title: "Консультация терапевта",
      docType: "conclusion" as const,
      docDate: "2024-11-20",
      source: "Клиника «Семейный доктор»",
      content:
        "Жалобы: периодическая утомляемость. Рекомендовано: контроль липидного профиля через 6 месяцев, ограничение насыщенных жиров, физическая активность 150 мин/нед, исследование витамина D и ТТГ.",
    },
    {
      title: "Анализ крови + гормоны",
      docType: "analysis" as const,
      docDate: "2025-03-04",
      source: "Лаборатория «Гемотест»",
      fileName: "blood_hormones_2025-03-04.pdf",
      content:
        "Гемоглобин 139. Лейкоциты 6.1. Глюкоза 5.8 ммоль/л. Холестерин общий 5.9. ЛПНП 3.6. ЛПВП 1.2. Триглицериды 1.9. АЛТ 34. АСТ 31. Мочевая кислота 432. ТТГ 3.8 мМЕ/л. Витамин D (25-OH) 21 нг/мл. Ферритин 64.",
    },
    {
      title: "УЗИ органов брюшной полости",
      docType: "instrumental" as const,
      docDate: "2025-03-10",
      source: "Медцентр «Диагностика+»",
      fileName: "uzi_2025-03-10.pdf",
      content:
        "Печень: не увеличена, эхогенность повышена — признаки жирового гепатоза лёгкой степени. Желчный пузырь без конкрементов. Поджелудочная железа без особенностей. Заключение: стеатоз печени, рекомендована коррекция диеты.",
    },
    {
      title: "Биохимия + HbA1c",
      docType: "analysis" as const,
      docDate: "2025-09-16",
      source: "Лаборатория «Инвитро»",
      fileName: "biochem_2025-09-16.pdf",
      content:
        "Глюкоза 6.2 ммоль/л. Гликированный гемоглобин (HbA1c) 5.9%. Холестерин общий 6.4. ЛПНП 4.1. ЛПВП 1.1. Триглицериды 2.3. АЛТ 45. АСТ 38. Мочевая кислота 468. Креатинин 91. Витамин D (25-OH) 27.",
    },
    {
      title: "Консультация эндокринолога",
      docType: "conclusion" as const,
      docDate: "2025-09-25",
      source: "Клиника «Семейный доктор»",
      content:
        "Преддиабет (нарушение толерантности к глюкозе не подтверждено, HbA1c на верхней границе). Дислипидемия. Рекомендации: диета с ограничением простых углеводов и пуринов, снижение веса, контроль через 6 месяцев, обсуждение статинотерапии при отсутствии динамики.",
    },
    {
      title: "Контрольный анализ крови",
      docType: "analysis" as const,
      docDate: "2026-03-11",
      source: "Лаборатория «Гемотест»",
      fileName: "blood_2026-03-11.pdf",
      content:
        "Гемоглобин 144. Лейкоциты 5.5. Тромбоциты 255. Глюкоза 6.5 ммоль/л. Гликированный гемоглобин (HbA1c) 6.2%. Холестерин общий 6.8. ЛПНП 4.4. ЛПВП 1.15. Триглицериды 2.5. АЛТ 52. АСТ 44. Мочевая кислота 489. ТТГ 4.3. Витамин D (25-OH) 33. Ферритин 71.",
    },
    {
      title: "Последний скрининг",
      docType: "analysis" as const,
      docDate: "2026-07-08",
      source: "Лаборатория «Инвитро»",
      fileName: "screen_2026-07-08.pdf",
      content:
        "Гемоглобин 143. Эритроциты 4.7. Лейкоциты 5.9. Тромбоциты 248. СОЭ 9. Глюкоза 6.7 ммоль/л. Гликированный гемоглобин (HbA1c) 6.4%. Холестерин общий 7.1. ЛПНП 4.7. ЛПВП 1.1. Триглицериды 2.7. АЛТ 58. АСТ 49. Креатинин 93. Мочевая кислота 512. ТТГ 4.6. Витамин D (25-OH) 35.",
    },
  ];
  const docIds: Record<string, number> = {};
  for (const d of docData) {
    const r = await db.insert(documents).values(d);
    docIds[d.docDate] = Number(r[0].insertId);
  }

  // ── Измерения (вручную по документам) ─────────────────────────────────
  type M = [string, number, string]; // code, value, date
  const mData: M[] = [
    ["HGB", 142, "2024-11-12"], ["HGB", 139, "2025-03-04"], ["HGB", 144, "2026-03-11"], ["HGB", 143, "2026-07-08"],
    ["RBC", 4.6, "2024-11-12"], ["RBC", 4.7, "2026-07-08"],
    ["WBC", 5.8, "2024-11-12"], ["WBC", 6.1, "2025-03-04"], ["WBC", 5.5, "2026-03-11"], ["WBC", 5.9, "2026-07-08"],
    ["PLT", 240, "2024-11-12"], ["PLT", 255, "2026-03-11"], ["PLT", 248, "2026-07-08"],
    ["ESR", 8, "2024-11-12"], ["ESR", 9, "2026-07-08"],
    ["GLU", 5.4, "2024-11-12"], ["GLU", 5.8, "2025-03-04"], ["GLU", 6.2, "2025-09-16"], ["GLU", 6.5, "2026-03-11"], ["GLU", 6.7, "2026-07-08"],
    ["HBA1C", 5.9, "2025-09-16"], ["HBA1C", 6.2, "2026-03-11"], ["HBA1C", 6.4, "2026-07-08"],
    ["CHOL", 5.4, "2024-11-12"], ["CHOL", 5.9, "2025-03-04"], ["CHOL", 6.4, "2025-09-16"], ["CHOL", 6.8, "2026-03-11"], ["CHOL", 7.1, "2026-07-08"],
    ["LDL", 3.2, "2024-11-12"], ["LDL", 3.6, "2025-03-04"], ["LDL", 4.1, "2025-09-16"], ["LDL", 4.4, "2026-03-11"], ["LDL", 4.7, "2026-07-08"],
    ["HDL", 1.3, "2024-11-12"], ["HDL", 1.2, "2025-03-04"], ["HDL", 1.1, "2025-09-16"], ["HDL", 1.15, "2026-03-11"], ["HDL", 1.1, "2026-07-08"],
    ["TG", 1.5, "2024-11-12"], ["TG", 1.9, "2025-03-04"], ["TG", 2.3, "2025-09-16"], ["TG", 2.5, "2026-03-11"], ["TG", 2.7, "2026-07-08"],
    ["ALT", 28, "2024-11-12"], ["ALT", 34, "2025-03-04"], ["ALT", 45, "2025-09-16"], ["ALT", 52, "2026-03-11"], ["ALT", 58, "2026-07-08"],
    ["AST", 26, "2024-11-12"], ["AST", 31, "2025-03-04"], ["AST", 38, "2025-09-16"], ["AST", 44, "2026-03-11"], ["AST", 49, "2026-07-08"],
    ["CREAT", 88, "2024-11-12"], ["CREAT", 91, "2025-09-16"], ["CREAT", 93, "2026-07-08"],
    ["URIC", 395, "2024-11-12"], ["URIC", 432, "2025-03-04"], ["URIC", 468, "2025-09-16"], ["URIC", 489, "2026-03-11"], ["URIC", 512, "2026-07-08"],
    ["TSH", 3.8, "2025-03-04"], ["TSH", 4.3, "2026-03-11"], ["TSH", 4.6, "2026-07-08"],
    ["VITD", 21, "2025-03-04"], ["VITD", 27, "2025-09-16"], ["VITD", 33, "2026-03-11"], ["VITD", 35, "2026-07-08"],
    ["FERR", 64, "2025-03-04"], ["FERR", 71, "2026-03-11"],
  ];
  for (const [code, value, date] of mData) {
    await db.insert(measurements).values({
      biomarkerId: bm[code],
      documentId: docIds[date] ?? null,
      value,
      measuredAt: date,
    });
  }

  // ── Физиологические показатели ────────────────────────────────────────
  const vitalsData: [string, number, string][] = [];
  const start = new Date("2026-05-01T08:00:00");
  let sys = 128, dia = 82, pulse = 72, weight = 84.5;
  for (let i = 0; i < 30; i++) {
    const d = new Date(start.getTime() + i * 3 * 864e5);
    sys += Math.round(Math.sin(i / 4) * 4 + (i > 20 ? 2 : 0));
    dia += Math.round(Math.sin(i / 5) * 2 + (i > 20 ? 1 : 0));
    pulse += Math.round(Math.sin(i / 3) * 3);
    weight = Math.round((weight - 0.12) * 10) / 10;
    vitalsData.push(["pressure_sys", sys, d.toISOString()]);
    vitalsData.push(["pressure_dia", dia, d.toISOString()]);
    vitalsData.push(["pulse", pulse, d.toISOString()]);
    if (i % 6 === 0) vitalsData.push(["weight", weight, d.toISOString()]);
  }
  for (const [t, v, dt] of vitalsData) {
    await db.insert(vitals).values({ vitalType: t as any, value: v, measuredAt: new Date(dt), source: "tracker" });
  }

  // ── Клиники ───────────────────────────────────────────────────────────
  await db.insert(clinics).values([
    { name: "Клиника «Семейный доктор»", city: "Москва", district: "ЦАО", address: "ул. Большая Полянка, 30", specialization: "Терапевт", priceFrom: 2800, rating: 4.7, reviewsCount: 1243, phone: "+7 495 123-45-67", equipment: "Лаборатория, УЗИ", source: "DocDoc" },
    { name: "Медцентр «Здоровье+»", city: "Москва", district: "ЮАО", address: "Варшавское ш., 75", specialization: "Терапевт", priceFrom: 1900, rating: 4.3, reviewsCount: 512, phone: "+7 495 234-56-78", equipment: "Лаборатория", source: "НаПоправку" },
    { name: "СМ-Клиника", city: "Москва", district: "САО", address: "ул. Клары Цеткин, 33/28", specialization: "Кардиолог", priceFrom: 3200, rating: 4.6, reviewsCount: 2105, phone: "+7 495 777-00-11", equipment: "ЭКГ, Холтер, УЗИ сердца", source: "DocDoc" },
    { name: "Кардиоцентр «Ритм»", city: "Москва", district: "ЗАО", address: "Мичуринский пр-т, 12", specialization: "Кардиолог", priceFrom: 4500, rating: 4.9, reviewsCount: 876, phone: "+7 495 555-12-34", equipment: "ЭКГ, СМАД, ЭхоКГ", source: "Yandex Health" },
    { name: "Поликлиника № 4 (ГБУЗ)", city: "Москва", district: "ВАО", address: "ул. Первомайская, 42", specialization: "Кардиолог", priceFrom: 0, rating: 3.8, reviewsCount: 3304, phone: "+7 495 111-22-33", equipment: "ЭКГ", source: "НаПоправку", hasLicense: true },
    { name: "Эндокринологический центр", city: "Москва", district: "ЦАО", address: "ул. Мясницкая, 13", specialization: "Эндокринолог", priceFrom: 3900, rating: 4.8, reviewsCount: 1544, phone: "+7 495 628-00-00", equipment: "Лаборатория, УЗИ щитовидной железы", source: "DocDoc" },
    { name: "Клиника «ДиаЛайф»", city: "Москва", district: "ЮЗАО", address: "пр-т Вернадского, 88", specialization: "Эндокринолог", priceFrom: 2400, rating: 4.4, reviewsCount: 698, phone: "+7 495 999-88-77", equipment: "Лаборатория", source: "НаПоправку" },
    { name: "Гепатологический центр «Печень+»", city: "Москва", district: "СЗАО", address: "ул. Алабяна, 7", specialization: "Гепатолог", priceFrom: 4200, rating: 4.7, reviewsCount: 432, phone: "+7 495 333-44-55", equipment: "УЗИ, Фиброскан", source: "DocDoc" },
    { name: "МЕДСИ", city: "Москва", district: "ЦАО", address: "Грохольский пер., 31", specialization: "Гастроэнтеролог", priceFrom: 3600, rating: 4.5, reviewsCount: 2890, phone: "+7 495 152-47-37", equipment: "Гастроскопия, УЗИ, лаборатория", source: "Yandex Health" },
    { name: "Клиника «ГастроПлюс»", city: "Москва", district: "ЮВАО", address: "ул. Нижегородская, 29", specialization: "Гастроэнтеролог", priceFrom: 2100, rating: 4.2, reviewsCount: 345, phone: "+7 495 444-55-66", equipment: "УЗИ", source: "НаПоправку" },
    { name: "Неврология «Церебро»", city: "Москва", district: "СВАО", address: "пр-т Мира, 184", specialization: "Невролог", priceFrom: 2900, rating: 4.6, reviewsCount: 567, phone: "+7 495 666-77-88", equipment: "ЭЭГ, МРТ (партнёр)", source: "DocDoc" },
    { name: "Клиника здоровья", city: "Санкт-Петербург", district: "Центральный", address: "Невский пр., 90", specialization: "Терапевт", priceFrom: 2500, rating: 4.5, reviewsCount: 987, phone: "+7 812 222-33-44", equipment: "Лаборатория, УЗИ", source: "НаПоправку" },
    { name: "СПб Кардиоцентр", city: "Санкт-Петербург", district: "Василеостровский", address: "8-я линия В.О., 45", specialization: "Кардиолог", priceFrom: 3400, rating: 4.7, reviewsCount: 1120, phone: "+7 812 333-44-55", equipment: "ЭКГ, Холтер, ЭхоКГ", source: "DocDoc" },
    { name: "Эндокринология СПб", city: "Санкт-Петербург", district: "Петроградский", address: "Каменноостровский пр., 16", specialization: "Эндокринолог", priceFrom: 2700, rating: 4.4, reviewsCount: 456, phone: "+7 812 444-55-66", equipment: "УЗИ, лаборатория", source: "Yandex Health" },
  ]);

  // ── Уведомления ───────────────────────────────────────────────────────
  await db.insert(notifications).values([
    {
      title: "Контроль липидного профиля",
      body: "По рекомендации эндокринолога от 25.09.2025 — пересдать липидный профиль и HbA1c. Последняя сдача: 08.07.2026.",
      severity: "info",
    },
    {
      title: "Мочевая кислота выше нормы",
      body: "512 мкмоль/л при норме до 420 (08.07.2026). Значение растёт четвёртое измерение подряд.",
      severity: "warning",
    },
    {
      title: "АЛТ выше нормы",
      body: "58 Ед/л при норме до 41 (08.07.2026). На фоне данных УЗИ (стеатоз) рекомендована консультация гепатолога.",
      severity: "warning",
    },
    {
      title: "HbA1c в зоне преддиабета",
      body: "6.4% при норме до 6.0%. Показатель растёт с сентября 2025. Обсудите с эндокринологом.",
      severity: "critical",
    },
  ]);

  await db.insert(auditLog).values([
    { action: "init", detail: "Система инициализирована, загружены демонстрационные данные пациента" },
    { action: "upload", detail: "Загружено документов: 8 (анализы, заключения, УЗИ)" },
    { action: "sync", detail: "Синхронизация физиологических данных с трекера: 30 дней" },
  ]);

  console.log("Done.");
  process.exit(0);
}

seed();
