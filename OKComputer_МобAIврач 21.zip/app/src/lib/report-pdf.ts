// Фирменный PDF «Динамический отчёт о состоянии здоровья» с QR-кодом
import pdfMake from "pdfmake/build/pdfmake";
import { ensureFonts } from "./medcard-pdf";
import { brandFooter, brandHeader, makeQr, MUTED, qrBlock, TEAL_DARK } from "./bp-pdf";

const STATUS: Record<string, { label: string; color: string }> = {
  normal: { label: "Норма", color: "#059669" },
  high: { label: "Повышен", color: "#ea580c" },
  low: { label: "Понижен", color: "#0284c7" },
  critical: { label: "Критично", color: "#e11d48" },
  no_data: { label: "Нет данных", color: "#94a3b8" },
};

const TREND: Record<string, string> = {
  up: "↑ растёт",
  down: "↓ снижается",
  stable: "→ стабильно",
  insufficient: "—",
};

export type ReportData = {
  docs: any[];
  biomarkers: {
    biomarker: { code: string; name: string; unit: string; refLow: number | null; refHigh: number | null; category: string };
    points: { date: string; value: number }[];
    status: string;
    trend: string;
    trendPct: number | null;
  }[];
  interpretations: string[];
  risks: string[];
  correlations: string[];
};

function fmt(d: string): string {
  return new Date(d).toLocaleDateString("ru-RU", { day: "2-digit", month: "2-digit", year: "numeric" });
}

export async function exportReportPdf(data: ReportData, from: string, to: string): Promise<void> {
  await ensureFonts();
  const qr = await makeQr();

  const abnormal = data.biomarkers.filter((b) => b.status !== "normal" && b.points.length);
  const content: any[] = [
    brandHeader(
      "ДИНАМИЧЕСКИЙ ОТЧЁТ О СОСТОЯНИИ ЗДОРОВЬЯ",
      `Период: ${fmt(from)} — ${fmt(to)} · Документов: ${data.docs.length} · Показателей: ${data.biomarkers.length}`
    ),

    // Сводка
    {
      margin: [40, 18, 40, 0],
      columns: [
        statBox("Показателей", String(data.biomarkers.length), "с измерениями"),
        statBox("Отклонений", String(abnormal.length), abnormal.length ? "требуют внимания" : "всё в норме"),
        statBox("Документов", String(data.docs.length), "за период"),
      ],
    },
  ];

  // AI-интерпретация
  if (data.interpretations.length) {
    content.push(
      { text: "AI-интерпретация отклонений", style: "h2" },
      ...data.interpretations.map((t) => ({
        margin: [40, 0, 40, 6],
        table: {
          widths: ["*"],
          body: [[{ text: t.replace(/\*\*/g, ""), fontSize: 9, lineHeight: 1.35, fillColor: "#f8fafc", border: [false, false, false, false], margin: [10, 8, 10, 8] }]],
        },
        layout: "noBorders",
      }))
    );
  }

  if (data.correlations.length) {
    content.push(
      { text: "Выявленные взаимосвязи", style: "h2" },
      {
        margin: [40, 0, 40, 6],
        ul: data.correlations.map((c) => ({ text: c, fontSize: 9, lineHeight: 1.3, margin: [0, 0, 0, 3] })),
      }
    );
  }

  // Таблица показателей
  if (data.biomarkers.length) {
    const body: any[] = [
      [
        { text: "Показатель", style: "th" },
        { text: "Измерения", style: "th" },
        { text: "Норма", style: "th" },
        { text: "Статус", style: "th" },
        { text: "Динамика", style: "th" },
      ],
      ...data.biomarkers.map((b) => {
        const st = STATUS[b.status] ?? STATUS.no_data;
        const last = b.points[b.points.length - 1];
        return [
          {
            stack: [
              { text: b.biomarker.name, fontSize: 9.5, bold: true },
              { text: b.biomarker.category, fontSize: 7.5, color: MUTED },
            ],
          },
          {
            stack: b.points.slice(-3).map((p) => ({
              text: `${p.value} ${b.biomarker.unit} · ${fmt(p.date)}`,
              fontSize: 8.5,
              color: p === last ? "#1e293b" : MUTED,
              bold: p === last,
            })),
          },
          {
            text: b.biomarker.refLow != null && b.biomarker.refHigh != null
              ? `${b.biomarker.refLow}–${b.biomarker.refHigh} ${b.biomarker.unit}`
              : "—",
            fontSize: 8.5,
            color: MUTED,
          },
          { text: st.label, fontSize: 9, bold: true, color: st.color },
          { text: TREND[b.trend] ?? "—", fontSize: 8.5, color: MUTED },
        ];
      }),
    ];
    content.push(
      { text: "Показатели за период", style: "h2" },
      {
        margin: [40, 0, 40, 0],
        table: { headerRows: 1, widths: ["auto", "*", "auto", "auto", "auto"], body },
        layout: {
          fillColor: (row: number) => (row === 0 ? "#f0fdfa" : row % 2 === 0 ? "#f8fafc" : null),
          hLineColor: () => "#e2e8f0",
          vLineColor: () => "#e2e8f0",
          hLineWidth: () => 0.5,
          vLineWidth: () => 0.5,
          paddingTop: () => 5,
          paddingBottom: () => 5,
        },
      }
    );
  }

  // Документы
  if (data.docs.length) {
    content.push(
      { text: "Документы за период", style: "h2" },
      {
        margin: [40, 0, 40, 0],
        table: {
          widths: ["*", "auto", "auto"],
          body: [
            [
              { text: "Документ", style: "th" },
              { text: "Источник", style: "th" },
              { text: "Дата", style: "th" },
            ],
            ...data.docs.map((d) => [
              { text: d.title, fontSize: 9 },
              { text: d.source ?? "—", fontSize: 8.5, color: MUTED },
              { text: fmt(String(d.docDate)), fontSize: 8.5, color: MUTED },
            ]),
          ],
        },
        layout: {
          fillColor: (row: number) => (row === 0 ? "#f0fdfa" : row % 2 === 0 ? "#f8fafc" : null),
          hLineColor: () => "#e2e8f0",
          vLineColor: () => "#e2e8f0",
          hLineWidth: () => 0.5,
          vLineWidth: () => 0.5,
          paddingTop: () => 5,
          paddingBottom: () => 5,
        },
      }
    );
  }

  content.push(qrBlock(qr));

  const doc: any = {
    pageSize: "A4",
    pageMargins: [0, 0, 0, 60],
    defaultStyle: { font: "Roboto", fontSize: 10, color: "#1e293b" },
    footer: brandFooter,
    content,
    styles: {
      h2: { fontSize: 13, bold: true, color: TEAL_DARK, margin: [40, 18, 40, 8] },
      th: { bold: true, fontSize: 9, color: TEAL_DARK },
    },
  };

  (pdfMake as any).createPdf(doc).download(`отчёт-здоровья-${from}_${to}.pdf`);

  function statBox(label: string, value: string, sub: string) {
    return {
      margin: [0, 0, 8, 0],
      table: {
        widths: ["*"],
        body: [
          [
            {
              border: [true, true, true, true],
              borderColor: ["#ccfbf1", "#ccfbf1", "#ccfbf1", "#ccfbf1"],
              fillColor: "#f0fdfa",
              margin: [10, 8, 10, 8],
              stack: [
                { text: value, fontSize: 15, bold: true, color: TEAL_DARK },
                { text: label, fontSize: 8, color: MUTED, margin: [0, 2, 0, 0] },
                { text: sub, fontSize: 7.5, color: "#94a3b8", margin: [0, 1, 0, 0] },
              ],
            },
          ],
        ],
      },
      layout: "noBorders",
    };
  }
}
