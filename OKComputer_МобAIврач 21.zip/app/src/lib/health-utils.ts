export type Status = "normal" | "low" | "high" | "critical" | "no_data";
export type Trend = "up" | "down" | "stable" | "insufficient";

export const STATUS_LABEL: Record<Status, string> = {
  normal: "В норме",
  low: "Ниже нормы",
  high: "Выше нормы",
  critical: "Критично",
  no_data: "Нет данных",
};

export const STATUS_CLASS: Record<Status, string> = {
  normal: "bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300",
  low: "bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300",
  high: "bg-orange-100 text-orange-800 dark:bg-orange-950 dark:text-orange-300",
  critical: "bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300",
  no_data: "bg-muted text-muted-foreground",
};

export const STATUS_DOT: Record<Status, string> = {
  normal: "#10b981",
  low: "#f59e0b",
  high: "#f97316",
  critical: "#ef4444",
  no_data: "#94a3b8",
};

export const TREND_LABEL: Record<Trend, string> = {
  up: "Растёт",
  down: "Снижается",
  stable: "Стабилен",
  insufficient: "—",
};

export const DOC_TYPE_LABEL: Record<string, string> = {
  analysis: "Анализ",
  conclusion: "Заключение врача",
  discharge: "Выписка",
  instrumental: "Инструментальное исследование",
  complaint: "Жалобы",
  anamnesis: "Анамнез",
  other: "Прочее",
};

export const VITAL_LABEL: Record<string, { name: string; unit: string }> = {
  pressure_sys: { name: "Давление систолическое", unit: "мм рт. ст." },
  pressure_dia: { name: "Давление диастолическое", unit: "мм рт. ст." },
  pulse: { name: "Пульс", unit: "уд/мин" },
  temperature: { name: "Температура", unit: "°C" },
  weight: { name: "Вес", unit: "кг" },
  spo2: { name: "SpO₂", unit: "%" },
};

export function fmtDate(d: string | Date): string {
  return new Date(d).toLocaleDateString("ru-RU", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

export function fmtDateTime(d: string | Date): string {
  return new Date(d).toLocaleString("ru-RU", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}
