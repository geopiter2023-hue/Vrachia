// Фирменный PDF «Динамика здоровья по месяцам и годам» с QR-кодом
import pdfMake from "pdfmake/build/pdfmake";
import { ensureFonts } from "./medcard-pdf";
import { brandFooter, brandHeader, makeQr, MUTED, qrBlock, TEAL, TEAL_DARK } from "./bp-pdf";

const MONTHS = [
  "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
  "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь",
];

const CAT: Record<string, { label: string; color: string }> = {
  document: { label: "Документ", color: "#0284c7" },
  measurement: { label: "Анализы", color: "#0f766e" },
  vaccine: { label: "Прививка", color: "#7c3aed" },
  vital: { label: "Физиология", color: "#e11d48" },
};

type TlItem = { date: string; category: string; title: string; detail: string };
type Month = { month: number; items: TlItem[] };
type Year = { year: number; months: Month[] };

export async function exportHistoryPdf(years: Year[]): Promise<void> {
  await ensureFonts();
  const qr = await makeQr();

  const totalEvents = years.reduce((a, y) => a + y.months.reduce((b, m) => b + m.items.length, 0), 0);
  const catCounts: Record<string, number> = {};
  for (const y of years)
    for (const m of y.months)
      for (const it of m.items) catCounts[it.category] = (catCounts[it.category] ?? 0) + 1;

  const yearStats = years.map((y) => ({
    year: y.year,
    events: y.months.reduce((a, m) => a + m.items.length, 0),
  }));
  const maxEvents = Math.max(1, ...yearStats.map((s) => s.events));

  const content: any[] = [
    brandHeader(
      "ДИНАМИКА ЗДОРОВЬЯ ПО МЕСЯЦАМ И ГОДАМ",
      `Всего событий: ${totalEvents} · лет наблюдений: ${years.length} · сформировано ${new Date().toLocaleDateString("ru-RU")}`
    ),

    // Сводка по категориям
    {
      margin: [40, 18, 40, 0],
      columns: Object.entries(CAT).map(([key, c]) => ({
        margin: [0, 0, 8, 0],
        table: {
          widths: ["*"],
          body: [
            [
              {
                border: [false, false, false, false],
                fillColor: `${c.color}12`,
                margin: [10, 7, 10, 7],
                stack: [
                  { text: String(catCounts[key] ?? 0), fontSize: 14, bold: true, color: c.color },
                  { text: c.label, fontSize: 8, color: MUTED, margin: [0, 2, 0, 0] },
                ],
              },
            ],
          ],
        },
        layout: "noBorders",
      })),
    },

    // Гистограмма активности по годам
    {
      margin: [40, 16, 40, 0],
      stack: [
        { text: "Активность наблюдений по годам", fontSize: 11, bold: true, color: TEAL_DARK, margin: [0, 0, 0, 8] },
        {
          columns: yearStats.map((s) => ({
            width: "*",
            stack: [
              {
                table: {
                  widths: ["*"],
                  heights: [70],
                  body: [
                    [
                      {
                        border: [false, false, false, false],
                        fillColor: null,
                        verticalAlignment: "bottom",
                        stack: [
                          {
                            table: {
                              widths: ["*"],
                              heights: [Math.max(4, Math.round((s.events / maxEvents) * 60))],
                              body: [[{ border: [false, false, false, false], fillColor: TEAL, text: "" }]],
                            },
                            layout: "noBorders",
                          },
                        ],
                      },
                    ],
                  ],
                },
                layout: "noBorders",
                margin: [0, 0, 6, 0],
              },
              { text: `${s.events}`, fontSize: 9, bold: true, color: TEAL_DARK, alignment: "center", margin: [0, 3, 0, 0] },
              { text: String(s.year), fontSize: 8.5, color: MUTED, alignment: "center", margin: [0, 1, 0, 0] },
            ],
          })),
        },
      ],
    },
  ];

  // Детализация: годы → месяцы → события
  for (const y of years) {
    const yearTotal = y.months.reduce((a, m) => a + m.items.length, 0);
    content.push({
      text: `${y.year} год · ${yearTotal} событий`,
      style: "h2",
      pageBreak: content.length > 3 ? undefined : undefined,
    });
    for (const m of y.months) {
      const rows: any[] = m.items.map((it) => {
        const c = CAT[it.category] ?? CAT.document;
        return [
          { text: it.date.split("-").reverse().join("."), fontSize: 8.5, color: MUTED, width: 52 },
          {
            stack: [
              { text: it.title, fontSize: 9.5, bold: true },
              it.detail
                ? { text: it.detail.replace(/⚠/g, "[!]"), fontSize: 8, color: MUTED, lineHeight: 1.25, margin: [0, 1, 0, 0] }
                : { text: "", fontSize: 1 },
            ],
          },
          { text: c.label, fontSize: 8.5, bold: true, color: c.color, width: 60 },
        ];
      });
      content.push({
        margin: [40, 6, 40, 0],
        stack: [
          {
            text: `${MONTHS[m.month - 1]} · ${m.items.length}`,
            fontSize: 10.5,
            bold: true,
            color: "#334155",
            margin: [0, 0, 0, 4],
          },
          {
            table: { widths: ["auto", "*", "auto"], body: rows },
            layout: {
              fillColor: (row: number) => (row % 2 ? "#f8fafc" : null),
              hLineColor: () => "#e2e8f0",
              vLineColor: () => "#e2e8f0",
              hLineWidth: () => 0.5,
              vLineWidth: () => 0.5,
              paddingTop: () => 4,
              paddingBottom: () => 4,
            },
          },
        ],
      });
    }
  }

  content.push(qrBlock(qr));

  const doc: any = {
    pageSize: "A4",
    pageMargins: [0, 0, 0, 60],
    defaultStyle: { font: "Roboto", fontSize: 10, color: "#1e293b" },
    footer: brandFooter,
    content,
    styles: {
      h2: { fontSize: 13, bold: true, color: TEAL_DARK, margin: [40, 18, 40, 4] },
      th: { bold: true, fontSize: 9, color: TEAL_DARK },
    },
  };

  (pdfMake as any).createPdf(doc).download(`динамика-здоровья-${new Date().toISOString().slice(0, 10)}.pdf`);
}
