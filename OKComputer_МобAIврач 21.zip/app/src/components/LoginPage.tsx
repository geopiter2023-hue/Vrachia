import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trpc } from "@/providers/trpc";
import { Mail, MessageSquare, Send, Loader2, ShieldCheck, ArrowLeft } from "lucide-react";
import { toast } from "sonner";

type Step = "enter" | "code";

export default function LoginPage({ onLoggedIn }: { onLoggedIn: () => void }) {
  const utils = trpc.useUtils();
  // email / phone
  const [step, setStep] = useState<Step>("enter");
  const [channel, setChannel] = useState<"email" | "phone">("email");
  const [identifier, setIdentifier] = useState("");
  const [code, setCode] = useState("");
  // telegram
  const [tgCode, setTgCode] = useState<string | null>(null);
  const [tgWaiting, setTgWaiting] = useState(false);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const requestMut = trpc.auth.requestCode.useMutation();
  const verifyMut = trpc.auth.verifyCode.useMutation();
  const tgStartMut = trpc.auth.telegramStart.useMutation();
  const tgCheckMut = trpc.auth.telegramCheck.useMutation();

  useEffect(() => () => { if (pollRef.current) clearInterval(pollRef.current); }, []);

  const finish = async () => {
    await utils.auth.me.invalidate();
    onLoggedIn();
  };

  const sendCode = async () => {
    const r = await requestMut.mutateAsync({ channel, identifier });
    if (!r.sent) {
      toast.error(r.error ?? "Не удалось отправить код");
      return;
    }
    toast.success(channel === "email" ? "Код отправлен на почту" : "Код отправлен по SMS");
    setStep("code");
  };

  const verify = async () => {
    const r = await verifyMut.mutateAsync({ channel, identifier, code });
    if (!r.ok) {
      toast.error(r.error ?? "Неверный код");
      return;
    }
    toast.success("Вход выполнен!");
    await finish();
  };

  const startTelegram = async () => {
    const r = await tgStartMut.mutateAsync();
    setTgCode(r.code);
    setTgWaiting(true);
    if (pollRef.current) clearInterval(pollRef.current);
    pollRef.current = setInterval(async () => {
      try {
        const chk = await tgCheckMut.mutateAsync({ code: r.code });
        if (chk.ok) {
          if (pollRef.current) clearInterval(pollRef.current);
          toast.success("Вход через Telegram выполнен!");
          await finish();
        }
      } catch { /* повторим */ }
    }, 3000);
  };

  const tabReset = () => {
    setStep("enter");
    setCode("");
    if (pollRef.current) { clearInterval(pollRef.current); pollRef.current = null; }
    setTgWaiting(false);
  };

  const busy = requestMut.isPending || verifyMut.isPending || tgStartMut.isPending;

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-6">
        <div className="text-center space-y-3">
          <img src="/icons/logo-96.png" alt="AI Врач" className="h-16 w-16 rounded-2xl shadow-md mx-auto" />
          <div>
            <h1 className="text-2xl font-bold">Вход в AI Врач</h1>
            <p className="text-sm text-muted-foreground mt-1">
              Ваши данные о здоровье будут привязаны к аккаунту и защищены
            </p>
          </div>
        </div>

        <div className="rounded-2xl border bg-card p-5 shadow-sm">
          <Tabs defaultValue="telegram" onValueChange={tabReset}>
            <TabsList className="grid grid-cols-3 w-full">
              <TabsTrigger value="telegram" className="gap-1.5"><Send className="h-3.5 w-3.5" />Telegram</TabsTrigger>
              <TabsTrigger value="email" className="gap-1.5"><Mail className="h-3.5 w-3.5" />Почта</TabsTrigger>
              <TabsTrigger value="phone" className="gap-1.5"><MessageSquare className="h-3.5 w-3.5" />SMS</TabsTrigger>
            </TabsList>

            {/* ── Telegram ── */}
            <TabsContent value="telegram" className="space-y-4 pt-4">
              {!tgCode ? (
                <>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    Самый быстрый способ: бот пришлёт подтверждение, а браузер войдёт автоматически.
                  </p>
                  <Button className="w-full h-11" onClick={startTelegram} disabled={busy}>
                    {tgStartMut.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                    Получить код для бота
                  </Button>
                </>
              ) : (
                <div className="space-y-4 text-center">
                  <p className="text-sm text-muted-foreground">Отправьте этот код нашему Telegram-боту:</p>
                  <div className="text-4xl font-mono font-bold tracking-[0.3em] py-3 rounded-xl bg-teal-50 dark:bg-teal-950/50 border border-teal-200 dark:border-teal-900 text-teal-700 dark:text-teal-300">
                    {tgCode}
                  </div>
                  <Button asChild className="w-full h-11" variant="outline">
                    <a href="https://t.me/aivrach_bot" target="_blank" rel="noreferrer">
                      <Send className="h-4 w-4" /> Открыть бота @aivrach_bot
                    </a>
                  </Button>
                  <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    {tgWaiting ? "Ждём подтверждения в боте…" : ""}
                  </div>
                  <p className="text-xs text-muted-foreground">Код действует 10 минут. Вход произойдёт автоматически.</p>
                </div>
              )}
            </TabsContent>

            {/* ── Email ── */}
            <TabsContent value="email" className="space-y-4 pt-4">
              <CodeFlow
                active={channel === "email"}
                setActive={() => setChannel("email")}
                step={step} setStep={setStep}
                placeholder="you@example.com" inputType="email"
                identifier={identifier} setIdentifier={setIdentifier}
                code={code} setCode={setCode}
                onSend={sendCode} onVerify={verify} busy={busy}
                hint="Пришлём 6-значный код на почту"
              />
            </TabsContent>

            {/* ── SMS ── */}
            <TabsContent value="phone" className="space-y-4 pt-4">
              <CodeFlow
                active={channel === "phone"}
                setActive={() => setChannel("phone")}
                step={step} setStep={setStep}
                placeholder="+7 900 123-45-67" inputType="tel"
                identifier={identifier} setIdentifier={setIdentifier}
                code={code} setCode={setCode}
                onSend={sendCode} onVerify={verify} busy={busy}
                hint="Пришлём 6-значный код по SMS"
              />
            </TabsContent>
          </Tabs>
        </div>

        <div className="flex items-start gap-2 text-xs text-muted-foreground justify-center max-w-sm mx-auto">
          <ShieldCheck className="h-4 w-4 shrink-0 text-primary mt-0.5" />
          <span>
            Продолжая, вы принимаете{" "}
            <a href="/legal/terms" className="text-primary hover:underline">пользовательское соглашение</a> и{" "}
            <a href="/legal/privacy" className="text-primary hover:underline">политику конфиденциальности</a>.
          </span>
        </div>
      </div>
    </div>
  );
}

function CodeFlow(props: {
  active: boolean; setActive: () => void;
  step: Step; setStep: (s: Step) => void;
  placeholder: string; inputType: string;
  identifier: string; setIdentifier: (v: string) => void;
  code: string; setCode: (v: string) => void;
  onSend: () => void; onVerify: () => void; busy: boolean; hint: string;
}) {
  const { step, setStep, placeholder, inputType, identifier, setIdentifier, code, setCode, onSend, onVerify, busy, hint, setActive } = props;
  if (step === "enter") {
    return (
      <>
        <p className="text-sm text-muted-foreground">{hint}</p>
        <Input
          type={inputType}
          placeholder={placeholder}
          value={identifier}
          onChange={(e) => { setActive(); setIdentifier(e.target.value); }}
          className="h-11"
        />
        <Button className="w-full h-11" onClick={onSend} disabled={busy || identifier.trim().length < 3}>
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
          Получить код
        </Button>
      </>
    );
  }
  return (
    <>
      <p className="text-sm text-muted-foreground">
        Введите код, отправленный на <b>{identifier}</b>
      </p>
      <Input
        inputMode="numeric"
        maxLength={6}
        placeholder="••••••"
        value={code}
        onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
        className="h-12 text-center text-2xl font-mono tracking-[0.4em]"
        autoFocus
      />
      <Button className="w-full h-11" onClick={onVerify} disabled={busy || code.length !== 6}>
        {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
        Войти
      </Button>
      <Button variant="ghost" className="w-full" onClick={() => setStep("enter")}>
        <ArrowLeft className="h-4 w-4" /> Изменить {inputType === "email" ? "почту" : "номер"}
      </Button>
    </>
  );
}
