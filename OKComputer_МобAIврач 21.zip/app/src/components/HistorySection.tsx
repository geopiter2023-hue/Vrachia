import { useMemo, useState } from "react";
import { trpc } from "@/providers/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { ChevronDown, FileText, FlaskConical, HeartPulse, Syringe, CalendarDays, FileDown } from "lucide-react";
import { toast } from "sonner";
import { exportHistoryPdf } from "@/lib/history-pdf";

const MONTHS = [
  "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
  "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь",
];

const CAT: Record<string, { label: string; icon: any; color: string }> = {
  document: { label: "Документ", icon: FileText, color: "#0284c7" },
  measurement: { label: "Анализы", icon: FlaskConical, color: "#0f766e" },
  vaccine: { label: "Прививка", icon: Syringe, color: "#7c3aed" },
  vital: { label: "Физиология", icon: HeartPulse, color: "#e11d48" },
};

type TlItem = { date: string; category: string; title: string; detail: string };
type Month = { month: number; items: TlItem[] };
type Year = { year: number; months: Month[] };

export default function HistorySection() {
  const { data, isLoading } = trpc.health.timeline.useQuery(undefined, { retry: 1 });
  const [openYear, setOpenYear] = useState<number | null>(null);
  const [openMonths, setOpenMonths] = useState<Set<string>>(new Set());
  const [pdfBusy, setPdfBusy] = useState(false);

  const years = useMemo(() => (data?.years ?? []) as Year[], [data]);

  // статистика по годам для мини-графика
  const yearStats = useMemo(
    () =>
      years.map((y) => ({
        year: y.year,
        events: y.months.reduce((a, m) => a + m.items.length, 0),
      })),
    [years]
  );
  const maxEvents = Math.max(1, ...yearStats.map((s) => s.events));

  const toggleMonth = (key: string) => {
    setOpenMonths((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  };

  const exportPdf = async () => {
    setPdfBusy(true);
    try {
      await exportHistoryPdf(years);
      toast.success("Дашборд по месяцам и годам выгружен (PDF)");
    } catch {
      toast.error("Не удалось сформировать PDF");
    } finally {
      setPdfBusy(false);
    }
  };

  return (
    <Card>
      <CardHeader className="pb-3 flex flex-row items-center justify-between">
        <CardTitle className="text-base flex items-center gap-2">
          <CalendarDays className="h-4 w-4 text-primary" />
          Динамика по месяцам и годам
        </CardTitle>
        <button
          onClick={exportPdf}
          disabled={pdfBusy || years.length === 0}
          className="flex items-center gap-1.5 text-xs font-medium text-primary hover:underline disabled:opacity-50 disabled:no-underline"
        >
          <FileDown className="h-3.5 w-3.5" />
          {pdfBusy ? "Формирую…" : "Бланк PDF"}
        </button>
      </CardHeader>
      <CardContent className="space-y-3">
        {isLoading ? (
          <Skeleton className="h-32" />
        ) : years.length === 0 ? (
          <p className="text-sm text-muted-foreground">Пока нет событий — загрузите первый документ.</p>
        ) : (
          <>
            {/* Мини-график активности по годам */}
            <div className="flex items-end gap-2 h-16 px-1">
              {yearStats.map((s) => (
                <div key={s.year} className="flex-1 flex flex-col items-center gap-1">
                  <div
                    className="w-full rounded-t-md bg-primary/70"
                    style={{ height: `${Math.max(8, (s.events / maxEvents) * 44)}px` }}
                    title={`${s.events} событий`}
                  />
                  <span className="text-[10px] text-muted-foreground">{s.year}</span>
                </div>
              ))}
            </div>

            {/* Годы → месяцы → события */}
            <div className="space-y-2">
              {years.map((y) => {
                const isOpen = openYear === y.year;
                const total = y.months.reduce((a, m) => a + m.items.length, 0);
                return (
                  <div key={y.year} className="rounded-xl border overflow-hidden">
                    <button
                      className="w-full flex items-center justify-between px-3.5 py-2.5 bg-muted/50 hover:bg-muted transition-colors"
                      onClick={() => setOpenYear(isOpen ? null : y.year)}
                    >
                      <span className="font-semibold text-sm">{y.year} год</span>
                      <span className="flex items-center gap-2 text-xs text-muted-foreground">
                        {total} событ.
                        <ChevronDown className={`h-4 w-4 transition-transform ${isOpen ? "rotate-180" : ""}`} />
                      </span>
                    </button>
                    {isOpen && (
                      <div className="divide-y">
                        {y.months.map((m) => {
                          const key = `${y.year}-${m.month}`;
                          const mOpen = openMonths.has(key);
                          return (
                            <div key={key}>
                              <button
                                className="w-full flex items-center justify-between px-4 py-2 hover:bg-accent/50 transition-colors"
                                onClick={() => toggleMonth(key)}
                              >
                                <span className="text-sm">{MONTHS[m.month - 1]}</span>
                                <span className="flex items-center gap-2 text-xs text-muted-foreground">
                                  {m.items.length}
                                  <ChevronDown className={`h-3.5 w-3.5 transition-transform ${mOpen ? "rotate-180" : ""}`} />
                                </span>
                              </button>
                              {mOpen && (
                                <div className="px-4 pb-3 space-y-1.5">
                                  {m.items.map((it, i) => {
                                    const c = CAT[it.category] ?? CAT.document;
                                    const Icon = c.icon;
                                    return (
                                      <div key={i} className="flex items-start gap-2.5 text-sm">
                                        <span
                                          className="mt-0.5 h-5 w-5 rounded-md flex items-center justify-center shrink-0"
                                          style={{ background: `${c.color}18`, color: c.color }}
                                        >
                                          <Icon className="h-3 w-3" />
                                        </span>
                                        <div className="min-w-0">
                                          <div className="font-medium leading-snug">{it.title}</div>
                                          {it.detail && (
                                            <div className="text-xs text-muted-foreground mt-0.5 leading-relaxed">
                                              {it.detail.replace(/⚠/g, "⚠️")}
                                            </div>
                                          )}
                                        </div>
                                      </div>
                                    );
                                  })}
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
