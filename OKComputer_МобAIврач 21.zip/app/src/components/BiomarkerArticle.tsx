import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { BookOpen, Activity, AlertTriangle, ArrowDown, ArrowUp, Beaker, Lightbulb } from "lucide-react";
import { getBiomarkerArticle } from "@/lib/biomarker-guide";

type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  code: string;
  name: string;
  unit?: string | null;
  refLow?: number | null;
  refHigh?: number | null;
  latestValue?: number | null;
  status?: string;
};

export function BiomarkerArticle({ open, onOpenChange, code, name, unit, refLow, refHigh, latestValue, status }: Props) {
  const art = getBiomarkerArticle(code, name);
  const norm = refLow != null && refHigh != null ? `${refLow}–${refHigh} ${unit ?? ""}`.trim() : null;

  const Section = ({ icon: Icon, title, text, tint }: { icon: any; title: string; text: string; tint: string }) => (
    <div className="space-y-1.5">
      <div className="flex items-center gap-2">
        <div className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-lg ${tint}`}>
          <Icon className="h-4 w-4" />
        </div>
        <h3 className="font-semibold">{title}</h3>
      </div>
      <p className="text-sm leading-relaxed text-muted-foreground">{text}</p>
    </div>
  );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 pr-6 text-lg leading-snug">
            <BookOpen className="h-5 w-5 shrink-0 text-teal-600" />
            {name}
          </DialogTitle>
          {norm && (
            <div className="flex flex-wrap items-center gap-2 pt-1">
              <Badge variant="secondary" className="font-normal">Норма: {norm}</Badge>
              {latestValue != null && (
                <Badge variant={status === "normal" ? "outline" : "destructive"} className="font-normal">
                  Ваш результат: {latestValue} {unit ?? ""}
                </Badge>
              )}
            </div>
          )}
        </DialogHeader>
        <div className="space-y-5 pt-2">
          <Section icon={Activity} title="Что это такое?" text={art.what} tint="bg-teal-100 text-teal-700 dark:bg-teal-950 dark:text-teal-300" />
          <Section icon={AlertTriangle} title="Зачем за этим следить?" text={art.why} tint="bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300" />
          <Section icon={Beaker} title="Как измеряется?" text={art.howMeasured} tint="bg-sky-100 text-sky-700 dark:bg-sky-950 dark:text-sky-300" />
          <Section icon={ArrowUp} title="Если повышен" text={art.high} tint="bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300" />
          <Section icon={ArrowDown} title="Если понижен" text={art.low} tint="bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300" />
          <div className="rounded-xl border bg-muted/40 p-3">
            <div className="flex items-start gap-2">
              <Lightbulb className="mt-0.5 h-4 w-4 shrink-0 text-teal-600" />
              <div className="space-y-1">
                <p className="text-xs text-muted-foreground">Источник: {art.source}</p>
                <p className="text-xs text-muted-foreground">
                  Материал носит информационный характер и не заменяет консультацию врача. Интерпретацию результатов всегда обсуждайте со специалистом.
                </p>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
