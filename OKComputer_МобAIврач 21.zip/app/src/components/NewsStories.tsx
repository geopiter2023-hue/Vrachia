import { trpc } from "@/providers/trpc";
import { useEffect, useMemo, useState } from "react";
import { Landmark, X, ChevronLeft, ChevronRight, ExternalLink } from "lucide-react";
import { Link } from "react-router";
import { fmtDateTime } from "@/lib/health-utils";

// Цветные градиенты для «колец» сторис
const RINGS = [
  "linear-gradient(135deg,#0d9488,#34d399)",
  "linear-gradient(135deg,#0369a1,#38bdf8)",
  "linear-gradient(135deg,#7c3aed,#c084fc)",
  "linear-gradient(135deg,#be185d,#fb7185)",
  "linear-gradient(135deg,#b45309,#fbbf24)",
];

export default function NewsStories() {
  const { data } = trpc.news.list.useQuery(undefined, {
    refetchInterval: 30 * 60 * 1000,
  });
  const items = useMemo(() => (data?.items ?? []).slice(0, 10), [data]);
  const [openIdx, setOpenIdx] = useState<number | null>(null);
  const [progress, setProgress] = useState(0);

  // Автопролистывание сторис (6 секунд)
  useEffect(() => {
    if (openIdx === null) return;
    setProgress(0);
    const step = 100 / (6000 / 100);
    const t = setInterval(() => {
      setProgress((p) => {
        if (p + step >= 100) {
          if (openIdx < items.length - 1) {
            setOpenIdx(openIdx + 1);
            return 0;
          }
          setOpenIdx(null);
          return 0;
        }
        return p + step;
      });
    }, 100);
    return () => clearInterval(t);
  }, [openIdx, items.length]);

  // Блокировка прокрутки фона при открытом просмотре
  useEffect(() => {
    document.body.style.overflow = openIdx !== null ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [openIdx]);

  if (!items.length) return null;

  const current = openIdx !== null ? items[openIdx] : null;

  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <h2 className="font-semibold text-sm flex items-center gap-1.5">
          <Landmark className="h-4 w-4 text-primary" /> Новости здравоохранения
        </h2>
        <Link to="/news" className="text-xs text-primary hover:underline">
          Все новости →
        </Link>
      </div>

      {/* Лента сторис */}
      <div
        style={{
          display: "flex",
          gap: 12,
          overflowX: "auto",
          paddingBottom: 4,
          WebkitOverflowScrolling: "touch",
        }}
      >
        {items.map((n, i) => (
          <button
            key={n.id ?? i}
            onClick={() => setOpenIdx(i)}
            style={{
              flexShrink: 0,
              width: 68,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              gap: 6,
              background: "none",
              border: "none",
              cursor: "pointer",
              padding: 0,
            }}
          >
            <span
              style={{
                width: 60,
                height: 60,
                borderRadius: "50%",
                padding: 3,
                background: RINGS[i % RINGS.length],
                display: "block",
              }}
            >
              <span
                style={{
                  width: "100%",
                  height: "100%",
                  borderRadius: "50%",
                  background: "#fff",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  border: "2px solid #fff",
                }}
              >
                <Landmark style={{ width: 22, height: 22, color: "#0d9488" }} />
              </span>
            </span>
            <span
              style={{
                fontSize: 10,
                lineHeight: "12px",
                color: "#52525b",
                textAlign: "center",
                display: "-webkit-box",
                WebkitLineClamp: 2,
                WebkitBoxOrient: "vertical",
                overflow: "hidden",
                maxWidth: 68,
              }}
            >
              {n.title}
            </span>
          </button>
        ))}
      </div>

      {/* Просмотрщик сторис */}
      {current && openIdx !== null && (
        <div
          onClick={() => setOpenIdx(null)}
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 100,
            background: "rgba(0,0,0,0.92)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              position: "relative",
              width: "100%",
              maxWidth: 420,
              height: "100%",
              maxHeight: 780,
              background: "linear-gradient(180deg,#134e4a,#0f172a)",
              borderRadius: 16,
              overflow: "hidden",
              display: "flex",
              flexDirection: "column",
              margin: 12,
            }}
          >
            {/* Прогресс-бары */}
            <div style={{ display: "flex", gap: 4, padding: "12px 12px 0" }}>
              {items.map((_, i) => (
                <div
                  key={i}
                  style={{
                    flex: 1,
                    height: 3,
                    borderRadius: 2,
                    background: "rgba(255,255,255,0.25)",
                    overflow: "hidden",
                  }}
                >
                  <div
                    style={{
                      height: "100%",
                      background: "#fff",
                      width: i < openIdx ? "100%" : i === openIdx ? `${progress}%` : "0%",
                      transition: i === openIdx ? "none" : "width 0.2s",
                    }}
                  />
                </div>
              ))}
            </div>

            {/* Шапка */}
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                padding: "10px 14px",
                color: "#fff",
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12 }}>
                <Landmark style={{ width: 16, height: 16 }} />
                <b>{data?.source ?? "Новости"}</b>
                {current.publishedAt && (
                  <span style={{ opacity: 0.7 }}>· {fmtDateTime(current.publishedAt)}</span>
                )}
              </div>
              <button
                onClick={() => setOpenIdx(null)}
                style={{ background: "none", border: "none", color: "#fff", cursor: "pointer" }}
              >
                <X style={{ width: 22, height: 22 }} />
              </button>
            </div>

            {/* Контент */}
            <div
              style={{
                flex: 1,
                overflowY: "auto",
                padding: "16px 18px",
                color: "#fff",
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                gap: 14,
              }}
            >
              <h3 style={{ fontSize: 20, fontWeight: 700, lineHeight: 1.3, margin: 0 }}>
                {current.title}
              </h3>
              {current.summary && (
                <p style={{ fontSize: 14, lineHeight: 1.6, opacity: 0.85, margin: 0 }}>
                  {current.summary}
                </p>
              )}
            </div>

            {/* Навигация и ссылка */}
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                padding: 14,
                gap: 8,
              }}
            >
              <button
                disabled={openIdx === 0}
                onClick={() => setOpenIdx(openIdx - 1)}
                style={{
                  background: "rgba(255,255,255,0.12)",
                  border: "none",
                  borderRadius: 10,
                  color: "#fff",
                  padding: "8px 12px",
                  cursor: openIdx === 0 ? "default" : "pointer",
                  opacity: openIdx === 0 ? 0.3 : 1,
                }}
              >
                <ChevronLeft style={{ width: 20, height: 20 }} />
              </button>
              <a
                href={current.link}
                target="_blank"
                rel="noreferrer"
                style={{
                  flex: 1,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 6,
                  background: "#0d9488",
                  color: "#fff",
                  borderRadius: 10,
                  padding: "10px 12px",
                  fontSize: 13,
                  fontWeight: 600,
                  textDecoration: "none",
                }}
              >
                Читать полностью <ExternalLink style={{ width: 15, height: 15 }} />
              </a>
              <button
                disabled={openIdx === items.length - 1}
                onClick={() => setOpenIdx(openIdx + 1)}
                style={{
                  background: "rgba(255,255,255,0.12)",
                  border: "none",
                  borderRadius: 10,
                  color: "#fff",
                  padding: "8px 12px",
                  cursor: openIdx === items.length - 1 ? "default" : "pointer",
                  opacity: openIdx === items.length - 1 ? 0.3 : 1,
                }}
              >
                <ChevronRight style={{ width: 20, height: 20 }} />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
