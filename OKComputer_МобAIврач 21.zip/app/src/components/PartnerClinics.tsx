import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Building2, MapPin, Phone, CalendarCheck } from "lucide-react";
import { toast } from "sonner";

// Клиники-партнёры агрегатора: продвигаемые показываются первыми с пометкой «Реклама»
export default function PartnerClinics() {
  const utils = trpc.useUtils();
  const { data } = trpc.clinic.directory.useQuery({});
  const { data: myBookings } = trpc.clinic.myBookings.useQuery();
  const bookMut = trpc.clinic.book.useMutation();
  const [bookingFor, setBookingFor] = useState<{ id: number; name: string } | null>(null);
  const [phone, setPhone] = useState("");
  const [date, setDate] = useState("");
  const [specialty, setSpecialty] = useState("");
  const [comment, setComment] = useState("");

  if (!data?.items.length) return null;

  const submit = async () => {
    if (!bookingFor || phone.trim().length < 5) return toast.error("Укажите телефон для связи");
    try {
      const r = await bookMut.mutateAsync({
        profileId: bookingFor.id,
        contactPhone: phone.trim(),
        preferredDate: date || undefined,
        specialty: specialty || undefined,
        comment: comment || undefined,
      });
      toast.success(`Заявка отправлена в «${r.clinicName}». Клиника свяжется с вами для подтверждения.`);
      setBookingFor(null);
      setComment(""); setSpecialty(""); setDate("");
      utils.clinic.myBookings.invalidate();
    } catch (e: any) {
      toast.error(e?.message ?? "Не удалось отправить заявку");
    }
  };

  return (
    <div className="space-y-3">
      <h2 className="text-lg font-semibold flex items-center gap-2">
        <Building2 className="h-5 w-5 text-teal-600" /> Клиники-партнёры
      </h2>
      {data.items.map((c) => (
        <Card key={c.id} className={c.promoted ? "border-teal-500/60" : undefined}>
          <CardContent className="pt-4 space-y-2">
            <div className="flex items-start justify-between gap-2">
              <div>
                <p className="font-semibold">{c.name}</p>
                <p className="text-sm text-muted-foreground flex items-center gap-1">
                  <MapPin className="h-3.5 w-3.5" />{c.city}{c.address ? `, ${c.address}` : ""}
                </p>
              </div>
              {c.promoted && <Badge variant="outline" className="text-xs border-amber-500 text-amber-600 shrink-0">Реклама</Badge>}
            </div>
            {c.specialties && <p className="text-sm text-muted-foreground">{c.specialties}</p>}
            <div className="flex items-center justify-between text-sm">
              {c.priceFrom ? <span>Приём от {c.priceFrom.toLocaleString("ru-RU")} ₽</span> : <span />}
              {c.phone && <span className="flex items-center gap-1 text-muted-foreground"><Phone className="h-3.5 w-3.5" />{c.phone}</span>}
            </div>
            <Button size="sm" className="w-full" onClick={() => setBookingFor({ id: c.id, name: c.name })}>
              <CalendarCheck className="mr-1 h-4 w-4" /> Записаться
            </Button>
          </CardContent>
        </Card>
      ))}

      {myBookings?.items.length ? (
        <Card>
          <CardContent className="pt-4 space-y-2">
            <p className="text-sm font-semibold">Мои заявки на запись</p>
            {myBookings.items.map((b) => (
              <div key={b.id} className="flex items-center justify-between rounded-lg border p-2 text-sm">
                <span>{b.clinicName}{b.specialty ? ` · ${b.specialty}` : ""}{b.preferredDate ? ` · ${b.preferredDate}` : ""}</span>
                <Badge variant={b.status === "new" ? "default" : "secondary"}>
                  {b.status === "new" ? "Ожидает" : b.status === "confirmed" ? "Подтверждена" : b.status === "done" ? "Завершена" : "Отменена"}
                </Badge>
              </div>
            ))}
          </CardContent>
        </Card>
      ) : null}

      <Dialog open={Boolean(bookingFor)} onOpenChange={(o) => !o && setBookingFor(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Запись в «{bookingFor?.name}»</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <Input placeholder="Ваш телефон для связи *" value={phone} onChange={(e) => setPhone(e.target.value)} />
            <Input placeholder="Желаемая дата (например, 12.08 после 15:00)" value={date} onChange={(e) => setDate(e.target.value)} />
            <Input placeholder="Специалист (терапевт, кардиолог…)" value={specialty} onChange={(e) => setSpecialty(e.target.value)} />
            <Textarea placeholder="Комментарий (необязательно)" value={comment} onChange={(e) => setComment(e.target.value)} />
            <Button className="w-full" disabled={bookMut.isPending} onClick={submit}>Отправить заявку</Button>
            <p className="text-xs text-muted-foreground">
              Нажимая «Отправить заявку», вы соглашаетесь на передачу номера телефона выбранной клинике для связи по записи.
            </p>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
