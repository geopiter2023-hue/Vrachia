import { trpc } from "@/providers/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Sparkles, Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export default function YearWrapped() {
  const year = new Date().getFullYear();
  const { data, isLoading } = trpc.coach.yearWrapped.useQuery({ year });

  if (isLoading || !data) return <Skeleton className="h-40 w-full rounded-xl" />;
  if (!data.measurements && !data.documents && !data.checkins && !data.bpEntries) return null;

  const stats = [
    { value: data.documents, label: "документов загружено", emoji: "📄" },
    { value: data.measurements, label: "показателей распознано", emoji: "🧪" },
    { value: data.bpEntries, label: "измерений давления", emoji: "❤️" },
    { value: data.checkins, label: "чек-инов самочувствия", emoji: "🙂" },
    { value: data.activeMonths, label: "активных месяцев", emoji: "📅" },
  ].filter((s) => s.value > 0);

  const shareText = `Мой ${data.year} год здоровья в AI Врач: ${stats.map((s) => `${s.value} ${s.label}`).join(", ")}. Индекс заботы о себе растёт! 💪`;

  return (
    <Card className="border-0 overflow-hidden bg-gradient-to-br from-violet-600 via-purple-600 to-fuchsia-600 text-white">
      <CardHeader className="pb-2 flex flex-row items-center justify-between">
        <CardTitle className="text-base flex items-center gap-2 text-white">
          <Sparkles className="h-4.5 w-4.5" size={18} /> Мой {data.year} год здоровья
        </CardTitle>
        <Button
          size="sm"
          variant="secondary"
          className="bg-white/20 hover:bg-white/30 text-white border-0"
          onClick={() => {
            navigator.clipboard.writeText(shareText);
            toast.success("Сводка скопирована — делитесь!");
          }}
        >
          <Share2 className="h-4 w-4 mr-1.5" /> Поделиться
        </Button>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
          {stats.map((s, i) => (
            <div key={i} className="rounded-xl bg-white/15 backdrop-blur px-3 py-2.5">
              <div className="text-lg">{s.emoji}</div>
              <div className="text-2xl font-bold leading-tight">{s.value}</div>
              <div className="text-[11px] text-white/80 leading-tight">{s.label}</div>
            </div>
          ))}
          {data.biomarkersTotal > 0 && (
            <div className="rounded-xl bg-white/15 backdrop-blur px-3 py-2.5">
              <div className="text-lg">🎯</div>
              <div className="text-2xl font-bold leading-tight">
                {Math.round((data.biomarkersInNorm / data.biomarkersTotal) * 100)}%
              </div>
              <div className="text-[11px] text-white/80 leading-tight">показателей в норме</div>
            </div>
          )}
        </div>
        {data.topImprovement.length > 0 && (
          <div className="mt-3 text-sm text-white/90">
            📈 Улучшились за год: <b>{data.topImprovement.join(", ")}</b>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
