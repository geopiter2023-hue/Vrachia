import { trpc } from "@/providers/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { BotMessageSquare, AlertTriangle, TrendingUp, Lightbulb, ThumbsUp, BookOpenText, BookOpen } from "lucide-react";
import { useState } from "react";
import { BiomarkerArticle } from "@/components/BiomarkerArticle";

const KIND_STYLE = {
  alert: { icon: AlertTriangle, cls: "border-red-200 dark:border-red-900 bg-red-50 dark:bg-red-950/40", iconCls: "text-red-500" },
  trend: { icon: TrendingUp, cls: "border-orange-200 dark:border-orange-900 bg-orange-50 dark:bg-orange-950/40", iconCls: "text-orange-500" },
  action: { icon: Lightbulb, cls: "border-sky-200 dark:border-sky-900 bg-sky-50 dark:bg-sky-950/40", iconCls: "text-sky-500" },
  praise: { icon: ThumbsUp, cls: "border-emerald-200 dark:border-emerald-900 bg-emerald-50 dark:bg-emerald-950/40", iconCls: "text-emerald-500" },
} as const;

export default function CoachInsights() {
  const { data, isLoading } = trpc.coach.insights.useQuery();
  const [article, setArticle] = useState<{ code: string; name: string } | null>(null);

  if (isLoading) return <Skeleton className="h-40 w-full rounded-xl" />;
  if (!data?.length) return null;

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <BotMessageSquare className="h-4.5 w-4.5 text-violet-500" size={18} />
          ИИ-коуч: что важно сейчас
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {data.map((ins, i) => {
          const st = KIND_STYLE[ins.kind];
          const Icon = st.icon;
          return (
            <div key={i} className={`rounded-lg border px-3 py-2.5 ${st.cls}`}>
              <div className="flex items-start gap-2.5">
                <Icon className={`h-4 w-4 mt-0.5 shrink-0 ${st.iconCls}`} />
                <div className="min-w-0">
                  <div className="text-sm font-medium">{ins.title}</div>
                  <div className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{ins.body}</div>
                  {ins.code && ins.biomarkerName && (
                    <button
                      className="mt-1.5 inline-flex items-center gap-1 text-xs font-medium text-teal-700 hover:underline dark:text-teal-400"
                      onClick={() => setArticle({ code: ins.code!, name: ins.biomarkerName! })}
                    >
                      <BookOpen className="h-3.5 w-3.5" /> Что значит этот показатель?
                    </button>
                  )}
                  {ins.source && (
                    <div className="text-[10px] text-muted-foreground/80 mt-1 flex items-center gap-1">
                      <BookOpenText className="h-3 w-3 shrink-0" />
                      Источник: {ins.source}
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </CardContent>
      {article && (
        <BiomarkerArticle
          open={article != null}
          onOpenChange={(v) => !v && setArticle(null)}
          code={article.code}
          name={article.name}
        />
      )}
    </Card>
  );
}
