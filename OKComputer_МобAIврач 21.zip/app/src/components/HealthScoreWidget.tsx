import { trpc } from "@/providers/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Flame, Sparkles } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const MOODS = [
  { key: "great", emoji: "😄", label: "Отлично" },
  { key: "good", emoji: "🙂", label: "Хорошо" },
  { key: "ok", emoji: "😐", label: "Нормально" },
  { key: "bad", emoji: "😞", label: "Плохо" },
] as const;

const MOOD_SCORE: Record<string, number> = { great: 4, good: 3, ok: 2, bad: 1 };

function scoreColor(s: number) {
  if (s >= 80) return { ring: "stroke-emerald-500", text: "text-emerald-600", bg: "from-emerald-50 to-teal-50 dark:from-emerald-950/40 dark:to-teal-950/40", label: "Отличная форма" };
  if (s >= 60) return { ring: "stroke-teal-500", text: "text-teal-600", bg: "from-teal-50 to-sky-50 dark:from-teal-950/40 dark:to-sky-950/40", label: "Хорошее состояние" };
  if (s >= 40) return { ring: "stroke-amber-500", text: "text-amber-600", bg: "from-amber-50 to-orange-50 dark:from-amber-950/40 dark:to-orange-950/40", label: "Есть над чем работать" };
  return { ring: "stroke-orange-500", text: "text-orange-600", bg: "from-orange-50 to-rose-50 dark:from-orange-950/40 dark:to-rose-950/40", label: "Требуется внимание" };
}

export default function HealthScoreWidget() {
  const utils = trpc.useUtils();
  const score = trpc.wellness.healthScore.useQuery();
  const today = trpc.wellness.today.useQuery();
  const [sleep, setSleep] = useState<number | null>(null);
  const [energy, setEnergy] = useState<number | null>(null);

  const checkin = trpc.wellness.checkin.useMutation({
    onSuccess: (r) => {
      utils.wellness.today.invalidate();
      utils.wellness.healthScore.invalidate();
      utils.wellness.achievements.invalidate();
      if (r.newAchievements.length) {
        for (const a of r.newAchievements) toast.success(`${a.icon} Достижение: ${a.title}`, { description: a.text });
      } else {
        toast.success(`Самочувствие отмечено · серия ${r.streak.current} дн. 🔥`);
      }
    },
    onError: () => toast.error("Не удалось сохранить чек-ин"),
  });

  if (score.isLoading || today.isLoading || !score.data || !today.data) {
    return <Skeleton className="h-56 w-full rounded-xl" />;
  }

  const { score: s, parts } = score.data;
  const c = scoreColor(s);
  const R = 52;
  const CIRC = 2 * Math.PI * R;
  const t = today.data;

  return (
    <Card className={`overflow-hidden border-0 bg-gradient-to-br ${c.bg}`}>
      <CardContent className="p-4 md:p-5">
        <div className="flex items-center gap-4 md:gap-6">
          {/* Кольцо индекса */}
          <div className="relative shrink-0">
            <svg width="120" height="120" viewBox="0 0 120 120" className="-rotate-90">
              <circle cx="60" cy="60" r={R} fill="none" strokeWidth="10" className="stroke-black/10 dark:stroke-white/10" />
              <circle
                cx="60" cy="60" r={R} fill="none" strokeWidth="10" strokeLinecap="round"
                className={c.ring}
                strokeDasharray={CIRC}
                strokeDashoffset={CIRC * (1 - s / 100)}
                style={{ transition: "stroke-dashoffset 1s ease" }}
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className={`text-3xl font-bold leading-none ${c.text}`}>{s}</span>
              <span className="text-[10px] text-muted-foreground mt-0.5">из 100</span>
            </div>
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="font-bold text-base md:text-lg">Индекс здоровья</h2>
              <span className={`text-xs font-medium ${c.text}`}>{c.label}</span>
            </div>
            {/* Состав индекса */}
            <div className="mt-2 space-y-1">
              {parts.map((p) => (
                <div key={p.key} className="flex items-center gap-2" title={p.hint}>
                  <span className="text-[11px] text-muted-foreground w-28 truncate">{p.label}</span>
                  <div className="flex-1 h-1.5 rounded-full bg-black/10 dark:bg-white/10 overflow-hidden">
                    <div
                      className={`h-full rounded-full ${c.ring.replace("stroke-", "bg-")}`}
                      style={{ width: `${(p.value / p.max) * 100}%`, transition: "width 1s ease" }}
                    />
                  </div>
                  <span className="text-[11px] tabular-nums text-muted-foreground w-10 text-right">{p.value}/{p.max}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Серия */}
          <div className="hidden sm:flex flex-col items-center gap-1 shrink-0 rounded-xl bg-white/60 dark:bg-black/20 px-4 py-3">
            <Flame className={`h-6 w-6 ${t.streak.current > 0 ? "text-orange-500" : "text-muted-foreground/40"}`} />
            <span className="text-xl font-bold leading-none">{t.streak.current}</span>
            <span className="text-[10px] text-muted-foreground text-center leading-tight">
              {t.streak.current === 0 ? "начните серию" : `дн. подряд · рекорд ${t.streak.best}`}
            </span>
          </div>
        </div>

        {/* Чек-ин */}
        <div className="mt-4 rounded-xl bg-white/70 dark:bg-black/20 p-3">
          {t.todayCheck ? (
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-sm">
                <span className="text-xl">{MOODS.find((m) => m.key === t.todayCheck?.mood)?.emoji}</span>
                <span className="text-muted-foreground">
                  Сегодня: <b className="text-foreground">{MOODS.find((m) => m.key === t.todayCheck?.mood)?.label}</b>
                </span>
              </div>
              <div className="flex items-center gap-1.5 sm:hidden">
                <Flame className="h-4 w-4 text-orange-500" />
                <span className="text-sm font-bold">{t.streak.current} дн.</span>
              </div>
            </div>
          ) : (
            <>
              <div className="flex items-center justify-between gap-2">
                <span className="text-sm font-medium flex items-center gap-1.5">
                  <Sparkles className="h-4 w-4 text-primary" /> Как самочувствие сегодня?
                </span>
                <span className="sm:hidden flex items-center gap-1 text-xs text-muted-foreground">
                  <Flame className="h-3.5 w-3.5 text-orange-500" />{t.streak.current}
                </span>
              </div>
              <div className="mt-2 flex items-center gap-2">
                {MOODS.map((m) => (
                  <button
                    key={m.key}
                    disabled={checkin.isPending}
                    onClick={() => checkin.mutate({ mood: m.key, sleep: sleep ?? undefined, energy: energy ?? undefined })}
                    className="flex-1 flex flex-col items-center gap-0.5 rounded-lg border bg-background px-1 py-2 hover:border-primary hover:bg-primary/5 active:scale-95 transition disabled:opacity-50"
                  >
                    <span className="text-xl">{m.emoji}</span>
                    <span className="text-[10px] text-muted-foreground">{m.label}</span>
                  </button>
                ))}
              </div>
              <div className="mt-2 flex items-center gap-3 text-[11px] text-muted-foreground">
                <span>Сон:</span>
                {[1, 2, 3, 4, 5].map((v) => (
                  <button key={v} onClick={() => setSleep(v)} className={`h-5 w-5 rounded-full border text-[10px] ${sleep === v ? "bg-primary text-primary-foreground border-primary" : ""}`}>{v}</button>
                ))}
                <span className="ml-2">Энергия:</span>
                {[1, 2, 3, 4, 5].map((v) => (
                  <button key={v} onClick={() => setEnergy(v)} className={`h-5 w-5 rounded-full border text-[10px] ${energy === v ? "bg-primary text-primary-foreground border-primary" : ""}`}>{v}</button>
                ))}
              </div>
            </>
          )}
        </div>

        {/* Мини-график настроения 14 дней */}
        {t.recent.length > 1 && (
          <div className="mt-3 flex items-end gap-1 h-8 px-1">
            {t.recent.map((r) => (
              <div
                key={r.date}
                title={`${r.date}`}
                className="flex-1 rounded-sm bg-primary/70"
                style={{ height: `${(MOOD_SCORE[r.mood] / 4) * 100}%`, opacity: 0.4 + (MOOD_SCORE[r.mood] / 4) * 0.6 }}
              />
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
