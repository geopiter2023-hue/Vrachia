import { trpc } from "@/providers/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { HeartHandshake, AlertTriangle, Clock, CheckCircle2 } from "lucide-react";

const RELATIONS: Record<string, string> = {
  mother: "Мама", father: "Папа", spouse: "Супруг(а)", son: "Сын", daughter: "Дочь",
  grandmother: "Бабушка", grandfather: "Дедушка", sibling: "Брат/сестра", other: "Родственник",
};

const ATT = {
  critical: { icon: AlertTriangle, cls: "border-red-300 dark:border-red-900 bg-red-50 dark:bg-red-950/40", iconCls: "text-red-500", label: "Требует внимания" },
  warning: { icon: Clock, cls: "border-amber-300 dark:border-amber-900 bg-amber-50 dark:bg-amber-950/40", iconCls: "text-amber-500", label: "Стоит проверить" },
  ok: { icon: CheckCircle2, cls: "border-emerald-200 dark:border-emerald-900", iconCls: "text-emerald-500", label: "Всё спокойно" },
} as const;

export default function FamilyOverview({ onSelect }: { onSelect: (id: number) => void }) {
  const { data } = trpc.family.overview.useQuery();
  if (!data?.length) return null;

  const needAttention = data.filter((m) => m.attention !== "ok");

  return (
    <Card className={needAttention.length ? "border-amber-300 dark:border-amber-900" : ""}>
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <HeartHandshake className="h-4.5 w-4.5 text-rose-500" size={18} />
          Попечительский контроль
          {needAttention.length > 0 && (
            <span className="text-xs font-normal text-amber-700 bg-amber-100 dark:bg-amber-950 dark:text-amber-400 rounded-full px-2 py-0.5">
              {needAttention.length} требуют внимания
            </span>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {data.map((m) => {
          const st = ATT[m.attention as keyof typeof ATT];
          const Icon = st.icon;
          return (
            <button key={m.id} onClick={() => onSelect(m.id)} className="w-full text-left">
              <div className={`rounded-lg border px-3 py-2.5 transition hover:shadow-sm ${st.cls}`}>
                <div className="flex items-center gap-2.5">
                  <Icon className={`h-4.5 w-4.5 shrink-0 ${st.iconCls}`} size={18} />
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium">
                      {m.name} <span className="text-xs font-normal text-muted-foreground">· {RELATIONS[m.relation] ?? m.relation}</span>
                    </div>
                    <div className="text-xs text-muted-foreground mt-0.5">
                      {m.criticalCount > 0 && <span className="text-red-600 dark:text-red-400 font-medium">{m.criticalCount} критич. отклонение · </span>}
                      {m.abnormalCount > 0 && m.criticalCount === 0 && <span>{m.abnormalCount} отклонений · </span>}
                      {m.daysSinceMeasurement != null
                        ? `данные ${m.daysSinceMeasurement === 0 ? "сегодня" : `${m.daysSinceMeasurement} дн. назад`}`
                        : "измерений пока нет"}
                    </div>
                    {m.topAbnormal.length > 0 && (
                      <div className="text-xs mt-1 flex flex-wrap gap-x-2">
                        {m.topAbnormal.map((t, i) => (
                          <span key={i} className={t.status === "critical" ? "text-red-600 dark:text-red-400" : "text-orange-600 dark:text-orange-400"}>
                            {t.name}: {t.value} {t.unit}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                  <span className="text-[10px] text-muted-foreground shrink-0">{st.label}</span>
                </div>
              </div>
            </button>
          );
        })}
      </CardContent>
    </Card>
  );
}
