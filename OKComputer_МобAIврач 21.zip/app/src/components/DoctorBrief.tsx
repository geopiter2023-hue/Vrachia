import { trpc } from "@/providers/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Stethoscope, Printer, HelpCircle } from "lucide-react";
import { fmtDate } from "@/lib/health-utils";

export default function DoctorBrief() {
  const { data, isLoading } = trpc.coach.doctorBrief.useQuery();

  if (isLoading || !data) return <Skeleton className="h-48 w-full rounded-xl" />;

  return (
    <Card className="border-teal-200 dark:border-teal-900" id="doctor-brief">
      <CardHeader className="pb-3 flex flex-row items-center justify-between">
        <CardTitle className="text-base flex items-center gap-2">
          <Stethoscope className="h-4.5 w-4.5 text-teal-600" size={18} />
          Отчёт для врача — одна страница перед приёмом
        </CardTitle>
        <Button size="sm" variant="outline" onClick={() => window.print()}>
          <Printer className="h-4 w-4 mr-1.5" /> Печать
        </Button>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-3 flex-wrap">
          <div className="rounded-lg bg-teal-50 dark:bg-teal-950/40 px-3 py-2">
            <span className="text-xs text-muted-foreground">Индекс здоровья</span>
            <div className="text-xl font-bold text-teal-700 dark:text-teal-400">{data.healthScore}/100</div>
          </div>
          {data.bpSummary && (
            <div className="rounded-lg bg-muted px-3 py-2">
              <span className="text-xs text-muted-foreground">Среднее АД за 30 дн. ({data.bpSummary.count} изм.)</span>
              <div className="text-xl font-bold">{data.bpSummary.avgSys}/{data.bpSummary.avgDia}</div>
            </div>
          )}
          <div className="rounded-lg bg-muted px-3 py-2">
            <span className="text-xs text-muted-foreground">Показателей в норме</span>
            <div className="text-xl font-bold">{data.normalCount}</div>
          </div>
        </div>

        {data.abnormal.length > 0 && (
          <div>
            <div className="text-sm font-semibold mb-1.5">Отклонения от нормы ({data.abnormal.length})</div>
            <div className="space-y-1">
              {data.abnormal.map((a, i) => (
                <div key={i} className="flex items-center gap-2 text-sm rounded-md border px-2.5 py-1.5">
                  <span className="flex-1 truncate">{a.name}</span>
                  <span className="font-semibold tabular-nums">{a.value} {a.unit}</span>
                  <span className="text-xs text-muted-foreground hidden sm:inline">норма {a.refLow}–{a.refHigh}</span>
                  <Badge variant="secondary" className={a.status === "critical" ? "bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-400" : "bg-orange-100 text-orange-700 dark:bg-orange-950 dark:text-orange-400"}>
                    {a.status === "critical" ? "критично" : a.status === "low" ? "ниже" : "выше"}
                  </Badge>
                  <span className="text-xs text-muted-foreground">{fmtDate(a.date)}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {data.questions.length > 0 && (
          <div className="rounded-lg bg-sky-50 dark:bg-sky-950/40 p-3">
            <div className="text-sm font-semibold flex items-center gap-1.5 mb-1.5">
              <HelpCircle className="h-4 w-4 text-sky-600" /> Вопросы врачу
            </div>
            <ul className="text-sm space-y-1 list-disc list-inside text-muted-foreground">
              {data.questions.map((q, i) => <li key={i}>{q}</li>)}
            </ul>
          </div>
        )}

        {data.recentDocs.length > 0 && (
          <div className="text-xs text-muted-foreground">
            Последние документы: {data.recentDocs.map((d) => `${d.title} (${fmtDate(String(d.date))})`).join(" · ")}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
