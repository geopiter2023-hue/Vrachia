import { NavLink, Outlet, Link } from "react-router";
import Onboarding from "@/components/Onboarding";
import ConsentScreen from "@/components/ConsentScreen";
import LoginPage from "@/components/LoginPage";
import {
  LayoutDashboard,
  Activity,
  HeartPulse,
  FileText,
  BotMessageSquare,
  Hospital,
  FileBarChart,
  Bell,
  ScrollText,
  ShieldCheck,
  Menu,
  PawPrint,
  Landmark,
  FileScan,
  Users,
  CalendarClock,
  Sparkles,
  BookOpenText,
  Trophy,
  Pill,
  UserRound,
  LogOut,
  Footprints,
} from "lucide-react";
import { trpc } from "@/providers/trpc";
import { Badge } from "@/components/ui/badge";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useState } from "react";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Дашборд", icon: LayoutDashboard, short: "Главная" },
  { to: "/biomarkers", label: "Показатели", icon: Activity, short: "Показатели" },
  { to: "/vitals", label: "Физиология", icon: HeartPulse, short: "Физиология" },
  { to: "/steps", label: "Шагомер", icon: Footprints, short: "Шаги" },
  { to: "/pressure", label: "Дневник давления", icon: HeartPulse, short: "Давление" },
  { to: "/achievements", label: "Достижения", icon: Trophy, short: "Награды" },
  { to: "/meds", label: "Лекарства и бот", icon: Pill, short: "Лекарства" },
  { to: "/documents", label: "Документы", icon: FileText, short: "Документы" },
  { to: "/assistant", label: "ИИ-доктор", icon: BotMessageSquare, short: "ИИ" },
  { to: "/imaging", label: "AI-анализ снимков", icon: FileScan, short: "Снимки" },
  { to: "/family", label: "Семья", icon: Users, short: "Семья" },
  { to: "/pets", label: "Питомцы", icon: PawPrint, short: "Питомцы" },
  { to: "/clinics", label: "Клиники и врачи", icon: Hospital, short: "Клиники" },
  { to: "/news", label: "Новости Минздрава", icon: Landmark, short: "Новости" },
  { to: "/medcard", label: "Медкарта", icon: CalendarClock, short: "Медкарта" },
  { to: "/recommendations", label: "Рекомендации", icon: Sparkles, short: "Советы" },
  { to: "/catalog", label: "Справочник анализов", icon: BookOpenText, short: "Справочник" },
  { to: "/reports", label: "Отчёты и экспорт", icon: FileBarChart, short: "Отчёты" },
  { to: "/notifications", label: "Уведомления", icon: Bell, short: "Уведомления" },
  { to: "/audit", label: "Журнал действий", icon: ScrollText, short: "Журнал" },
];

// Нижняя панель мобильной навигации — 4 основных раздела + меню
const TAB_BAR = [NAV[0], NAV[1], NAV[5], NAV[8]];

function Logo() {
  return (
    <div className="flex items-center gap-2.5">
      <img
        src="/icons/logo-96.png"
        alt="AI Врач"
        className="h-9 w-9 rounded-xl shrink-0 shadow-sm"
      />
      <div>
        <div className="font-bold leading-tight">AI Врач</div>
        <div className="text-xs text-muted-foreground">Цифровой двойник здоровья</div>
      </div>
    </div>
  );
}

function AccountBlock() {
  const utils = trpc.useUtils();
  const { data: me } = trpc.auth.me.useQuery();
  const logoutMut = trpc.auth.logout.useMutation({
    onSuccess: async () => {
      await utils.auth.me.invalidate();
      window.location.reload();
    },
  });
  if (!me?.user) return null;
  const label = me.user.email ?? (me.user.phone ? `+${me.user.phone}` : "Telegram-аккаунт");
  return (
    <div className="flex items-center gap-2 rounded-lg border p-2.5">
      <div className="h-8 w-8 rounded-full bg-teal-100 dark:bg-teal-950 flex items-center justify-center shrink-0">
        <UserRound className="h-4 w-4 text-teal-600" />
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-xs font-medium truncate">{label}</div>
        <button
          className="text-[11px] text-muted-foreground hover:text-destructive inline-flex items-center gap-1"
          onClick={() => logoutMut.mutate()}
        >
          <LogOut className="h-3 w-3" /> Выйти
        </button>
      </div>
    </div>
  );
}

function PrivacyNote() {
  return (
    <div className="space-y-2">
      <div className="flex items-start gap-2 text-xs text-muted-foreground">
        <ShieldCheck className="h-4 w-4 shrink-0 mt-0.5 text-primary" />
        <span>Информационный сервис. Не является медицинской услугой и не заменяет консультацию врача.</span>
      </div>
      <div className="flex gap-3 text-[11px]">
        <Link to="/legal/privacy" className="text-muted-foreground hover:text-primary">Конфиденциальность</Link>
        <Link to="/legal/terms" className="text-muted-foreground hover:text-primary">Соглашение</Link>
      </div>
    </div>
  );
}

export default function Layout() {
  const { data: me, isLoading: meLoading, refetch: refetchMe } = trpc.auth.me.useQuery();
  const { data: notifs } = trpc.health.notifications.list.useQuery(undefined, {
    enabled: Boolean(me?.user),
  });
  const unread = notifs?.filter((n) => !n.isRead).length ?? 0;
  const [menuOpen, setMenuOpen] = useState(false);

  if (meLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <img src="/icons/logo-96.png" alt="AI Врач" className="h-14 w-14 rounded-2xl shadow-md animate-pulse" />
          <div className="text-sm text-muted-foreground">Загрузка…</div>
        </div>
      </div>
    );
  }

  if (!me?.user) {
    return <LoginPage onLoggedIn={() => refetchMe()} />;
  }

  const navItem = (
    item: (typeof NAV)[number],
    onClick?: () => void
  ) => (
    <NavLink
      key={item.to}
      to={item.to}
      end={item.to === "/"}
      onClick={onClick}
      className={({ isActive }) =>
        cn(
          "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
          isActive
            ? "bg-primary text-primary-foreground"
            : "text-muted-foreground hover:bg-accent hover:text-foreground"
        )
      }
    >
      <item.icon className="shrink-0" size={18} />
      <span className="flex-1">{item.label}</span>
      {item.to === "/notifications" && unread > 0 && (
        <Badge variant="destructive" className="h-5 px-1.5 text-xs">
          {unread}
        </Badge>
      )}
    </NavLink>
  );

  return (
    <div className="min-h-screen bg-background">
      <ConsentScreen />
      <Onboarding />
      {/* ── Десктопный сайдбар ── */}
      <aside className="hidden md:flex w-64 shrink-0 border-r bg-card flex-col fixed inset-y-0 z-30">
        <div className="px-5 py-5 border-b">
          <Logo />
        </div>
        <nav className="flex-1 p-3 space-y-0.5 overflow-y-auto">{NAV.map((n) => navItem(n))}</nav>
        <div className="p-4 border-t space-y-3">
          <AccountBlock />
          <PrivacyNote />
        </div>
      </aside>

      {/* ── Мобильная шапка ── */}
      <header className="md:hidden sticky top-0 z-50 border-b bg-card px-4 py-3">
        <Logo />
      </header>

      {/* ── Контент ── */}
      <main className="md:ml-64 min-w-0 pb-24 md:pb-0">
        <div className="mx-auto max-w-6xl px-4 md:px-6 py-4 md:py-6">
          <Outlet />
        </div>
      </main>

      {/* ── Мобильная нижняя панель с кнопками (инлайн-стили — гарантированный рендер) ── */}
      <nav
        className="md:hidden"
        style={{
          position: "fixed",
          bottom: 0,
          left: 0,
          right: 0,
          zIndex: 50,
          padding: "4px 12px 12px",
        }}
      >
        <div
          style={{
            display: "flex",
            flexDirection: "row",
            margin: "0 auto",
            maxWidth: 430,
            background: "#ffffff",
            border: "1px solid #e4e4e7",
            borderRadius: 20,
            boxShadow: "0 4px 24px rgba(0,0,0,0.14)",
            padding: 6,
            gap: 4,
          }}
        >
          {TAB_BAR.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === "/"}
              style={({ isActive }) => ({
                flex: 1,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                gap: 2,
                height: 56,
                borderRadius: 14,
                fontSize: 10,
                fontWeight: 500,
                textDecoration: "none",
                background: isActive ? "#0f766e" : "transparent",
                color: isActive ? "#ffffff" : "#71717a",
              })}
            >
              <item.icon size={20} />
              {item.short}
            </NavLink>
          ))}
          <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
            <SheetTrigger asChild>
              <button
                style={{
                  flex: 1,
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 2,
                  height: 56,
                  borderRadius: 14,
                  fontSize: 10,
                  fontWeight: 500,
                  background: "transparent",
                  color: "#71717a",
                  border: "none",
                  cursor: "pointer",
                  position: "relative",
                }}
              >
                <Menu size={20} />
                Меню
                {unread > 0 && (
                  <span
                    style={{
                      position: "absolute",
                      top: 4,
                      right: "18%",
                      height: 16,
                      minWidth: 16,
                      padding: "0 4px",
                      borderRadius: 999,
                      background: "#dc2626",
                      color: "#fff",
                      fontSize: 9,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    {unread}
                  </span>
                )}
              </button>
            </SheetTrigger>
            <SheetContent side="left" className="w-72 p-0 flex flex-col">
              <div className="px-5 py-5 border-b">
                <Logo />
              </div>
              <nav className="flex-1 p-3 space-y-0.5 overflow-y-auto">
                {NAV.map((n) => navItem(n, () => setMenuOpen(false)))}
              </nav>
              <div className="p-4 border-t space-y-3">
                <AccountBlock />
                <PrivacyNote />
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </nav>
    </div>
  );
}
