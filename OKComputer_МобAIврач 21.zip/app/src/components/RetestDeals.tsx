import { trpc } from "@/providers/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { FlaskConical, MapPin, Star } from "lucide-react";

export default function RetestDeals() {
  const { data } = trpc.coach.retestDeals.useQuery();
  if (!data || (!data.due.length && !data.offers.length)) return null;

  return (
    <Card className="border-violet-200 dark:border-violet-900">
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <FlaskConical className="h-4.5 w-4.5 text-violet-500" size={18} />
          Витрина выгоды: что пересдать
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {data.due.length > 0 && (
          <div className="space-y-1.5">
            {data.due.map((d, i) => (
              <div key={i} className="flex items-center gap-2 text-sm rounded-lg bg-violet-50 dark:bg-violet-950/40 px-3 py-2">
                <span className="flex-1 font-medium truncate">{d.name}</span>
                <span className="text-xs text-muted-foreground tabular-nums">{d.value} {d.unit}</span>
                <Badge variant="secondary" className="bg-violet-100 text-violet-700 dark:bg-violet-900 dark:text-violet-300 shrink-0">
                  {Math.floor(d.daysAgo / 30)} мес. назад
                </Badge>
              </div>
            ))}
            <p className="text-xs text-muted-foreground px-1">{data.due[0].reason}</p>
          </div>
        )}
        <p className="text-[11px] text-muted-foreground/80 px-1">
          Имеются противопоказания. Необходима консультация специалиста. Сведения об учреждениях носят
          справочный характер и не являются рекламой — наличие лицензии уточняйте в учреждении.
        </p>
        {data.offers.length > 0 && (
          <div>
            <div className="text-xs font-medium text-muted-foreground mb-1.5">Где сдать — по данным агрегаторов:</div>
            <div className="space-y-1">
              {data.offers.map((o, i) => (
                <div key={i} className="flex items-center gap-2 text-sm px-3 py-1.5">
                  <span className="flex-1 truncate">{o.name}</span>
                  <span className="text-xs text-muted-foreground flex items-center gap-0.5">
                    <MapPin className="h-3 w-3" />{o.city}
                  </span>
                  {o.rating != null && (
                    <span className="text-xs flex items-center gap-0.5 text-amber-600">
                      <Star className="h-3 w-3 fill-amber-400 text-amber-400" />{o.rating}
                    </span>
                  )}
                  {o.priceFrom != null && (
                    <span className="text-sm font-semibold text-emerald-600 shrink-0">от {Math.round(o.priceFrom)} ₽</span>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
