import { useEffect, useState } from "react";
import { hasConsent } from "@/components/ConsentScreen";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import {
  BotMessageSquare,
  FileText,
  Activity,
  Building2,
  QrCode,
  ChevronRight,
} from "lucide-react";

const KEY = "ai-vrach-onboarded-v1";

const SLIDES = [
  {
    icon: Activity,
    title: "Всё здоровье — на одном дашборде",
    text: "Биомаркеры с динамикой, отклонения от нормы, риски и взаимосвязи показателей — в разрезе месяцев и лет.",
    accent: "from-teal-500 to-emerald-600",
  },
  {
    icon: BotMessageSquare,
    title: "ИИ-доктор всегда на связи",
    text: "Опишите симптомы — получите уточняющие вопросы, вероятные причины, план действий и красные флаги с учётом ваших анализов.",
    accent: "from-violet-500 to-purple-600",
  },
  {
    icon: FileText,
    title: "Документы сами превращаются в данные",
    text: "Загрузите PDF с анализами — система распознает показатели, разложит по категориям и покажет динамику.",
    accent: "from-sky-500 to-blue-600",
  },
  {
    icon: Building2,
    title: "51 000+ медучреждений России",
    text: "Больницы, поликлиники, стоматологии и кабинеты врачей — с поиском, фильтрами по категориям и картой.",
    accent: "from-amber-500 to-orange-600",
  },
  {
    icon: QrCode,
    title: "Фирменные бланки с QR-кодом",
    text: "Выгружайте дневник давления, отчёты и динамику здоровья в PDF на фирменном бланке — с QR-кодом обратно в систему.",
    accent: "from-rose-500 to-pink-600",
  },
];

export default function Onboarding() {
  const [open, setOpen] = useState(false);
  const [idx, setIdx] = useState(0);

  useEffect(() => {
    // Онбординг показываем только после принятия согласий (и проверяем периодически)
    const t = setInterval(() => {
      try {
        if (hasConsent() && !localStorage.getItem(KEY)) {
          setOpen(true);
          clearInterval(t);
        }
      } catch { /* ignore */ }
    }, 500);
    return () => clearInterval(t);
  }, []);

  const close = () => {
    try {
      localStorage.setItem(KEY, "1");
    } catch {
      /* ignore */
    }
    setOpen(false);
  };

  const slide = SLIDES[idx];
  const last = idx === SLIDES.length - 1;

  return (
    <Dialog open={open} onOpenChange={(v) => !v && close()}>
      <DialogContent className="sm:max-w-md p-0 overflow-hidden gap-0" showCloseButton={false}>
        <div className={`bg-gradient-to-br ${slide.accent} p-8 text-white flex flex-col items-center text-center transition-all`}>
          <div className="h-24 w-24 rounded-3xl bg-white/15 backdrop-blur flex items-center justify-center shadow-lg">
            <slide.icon className="h-12 w-12" />
          </div>
          <h2 className="text-xl font-bold mt-5 leading-snug">{slide.title}</h2>
          <p className="text-sm text-white/85 mt-2 leading-relaxed min-h-[3.5rem]">{slide.text}</p>
        </div>
        <div className="p-5 space-y-4">
          <div className="flex justify-center gap-1.5">
            {SLIDES.map((_, i) => (
              <span
                key={i}
                className={`h-1.5 rounded-full transition-all ${i === idx ? "w-6 bg-primary" : "w-1.5 bg-muted-foreground/30"}`}
              />
            ))}
          </div>
          <Button
            className="w-full h-11 text-base"
            onClick={() => (last ? close() : setIdx((i) => i + 1))}
          >
            {last ? "Начать работу" : "Дальше"} <ChevronRight className="h-4 w-4 ml-1" />
          </Button>
          {!last && (
            <button onClick={close} className="w-full text-center text-xs text-muted-foreground hover:text-foreground">
              Пропустить
            </button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
