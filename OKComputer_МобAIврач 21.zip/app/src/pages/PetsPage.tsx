import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { fmtDate } from "@/lib/health-utils";
import { Dog, Cat, Bird, Squirrel, PawPrint, Plus, Trash2, Syringe, Stethoscope, FlaskConical, Scissors, StickyNote } from "lucide-react";
import { toast } from "sonner";

const SPECIES_ICON: Record<string, any> = { dog: Dog, cat: Cat, bird: Bird, rodent: Squirrel, other: PawPrint };
const SPECIES_LABEL: Record<string, string> = { dog: "Собака", cat: "Кошка", bird: "Птица", rodent: "Грызун", other: "Другое" };
const EVENT_LABEL: Record<string, string> = { visit: "Визит", vaccine: "Прививка", analysis: "Анализ", procedure: "Процедура", note: "Заметка" };
const EVENT_ICON: Record<string, any> = { visit: Stethoscope, vaccine: Syringe, analysis: FlaskConical, procedure: Scissors, note: StickyNote };

function age(birth?: string | null) {
  if (!birth) return null;
  const years = (Date.now() - new Date(birth).getTime()) / (365.25 * 864e5);
  if (years < 1) return `${Math.max(1, Math.round(years * 12))} мес.`;
  return `${Math.floor(years)} г. ${Math.round((years % 1) * 12)} мес.`;
}

export default function PetsPage() {
  const utils = trpc.useUtils();
  const { data, isLoading } = trpc.pets.list.useQuery();
  const [open, setOpen] = useState(false);
  const [eventPet, setEventPet] = useState<number | null>(null);
  const [form, setForm] = useState({ name: "", species: "dog", breed: "", sex: "male", birthDate: "", weightKg: "", notes: "" });
  const [evForm, setEvForm] = useState({ eventType: "visit", title: "", eventDate: new Date().toISOString().slice(0, 10), detail: "" });

  const invalidate = () => utils.pets.list.invalidate();

  const createMut = trpc.pets.create.useMutation({
    onSuccess: () => {
      toast.success("Питомец добавлен");
      invalidate();
      setOpen(false);
      setForm({ name: "", species: "dog", breed: "", sex: "male", birthDate: "", weightKg: "", notes: "" });
    },
  });
  const delMut = trpc.pets.remove.useMutation({ onSuccess: () => { toast.success("Питомец удалён"); invalidate(); } });
  const evMut = trpc.pets.addEvent.useMutation({
    onSuccess: () => {
      toast.success("Событие добавлено");
      invalidate();
      setEventPet(null);
      setEvForm({ eventType: "visit", title: "", eventDate: new Date().toISOString().slice(0, 10), detail: "" });
    },
  });
  const delEvMut = trpc.pets.removeEvent.useMutation({ onSuccess: invalidate });

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-xl md:text-2xl font-bold">Питомцы</h1>
          <p className="text-muted-foreground text-sm mt-1">Здоровье домашних животных: прививки, анализы, визиты к ветеринару</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button><Plus className="h-4 w-4 mr-1.5" /> Добавить питомца</Button>
          </DialogTrigger>
          <DialogContent className="max-h-[90vh] overflow-y-auto">
            <DialogHeader><DialogTitle>Новый питомец</DialogTitle></DialogHeader>
            <div className="space-y-4 pt-2">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label>Кличка</Label>
                  <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
                </div>
                <div className="space-y-1.5">
                  <Label>Вид</Label>
                  <Select value={form.species} onValueChange={(v) => setForm({ ...form, species: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {Object.entries(SPECIES_LABEL).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label>Порода</Label>
                  <Input value={form.breed} onChange={(e) => setForm({ ...form, breed: e.target.value })} />
                </div>
                <div className="space-y-1.5">
                  <Label>Пол</Label>
                  <Select value={form.sex} onValueChange={(v) => setForm({ ...form, sex: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Самец</SelectItem>
                      <SelectItem value="female">Самка</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label>Дата рождения</Label>
                  <Input type="date" value={form.birthDate} onChange={(e) => setForm({ ...form, birthDate: e.target.value })} />
                </div>
                <div className="space-y-1.5">
                  <Label>Вес, кг</Label>
                  <Input type="number" step="any" value={form.weightKg} onChange={(e) => setForm({ ...form, weightKg: e.target.value })} />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label>Заметки (особенности здоровья, диета)</Label>
                <Textarea rows={3} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
              </div>
              <Button
                className="w-full"
                disabled={!form.name || createMut.isPending}
                onClick={() =>
                  createMut.mutate({
                    name: form.name,
                    species: form.species as any,
                    breed: form.breed || undefined,
                    sex: form.sex as any,
                    birthDate: form.birthDate || undefined,
                    weightKg: form.weightKg ? Number(form.weightKg) : undefined,
                    notes: form.notes || undefined,
                  })
                }
              >
                Сохранить
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">{[0, 1].map((i) => <Skeleton key={i} className="h-72" />)}</div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {(data ?? []).map((p) => {
            const Icon = SPECIES_ICON[p.species] ?? PawPrint;
            return (
              <Card key={Number(p.id)}>
                <CardHeader className="pb-3">
                  <div className="flex items-center gap-3">
                    <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                      <Icon className="h-6 w-6 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <CardTitle className="text-lg flex items-center gap-2">
                        {p.name}
                        <Badge variant="secondary">{SPECIES_LABEL[p.species]}</Badge>
                      </CardTitle>
                      <div className="text-xs text-muted-foreground mt-0.5">
                        {[p.breed, p.sex === "male" ? "самец" : "самка", age(p.birthDate), p.weightKg ? `${p.weightKg} кг` : null]
                          .filter(Boolean).join(" · ")}
                      </div>
                    </div>
                    <Button
                      variant="ghost" size="icon"
                      className="text-muted-foreground hover:text-destructive shrink-0"
                      onClick={() => confirm(`Удалить питомца «${p.name}» вместе с историей?`) && delMut.mutate({ id: Number(p.id) })}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                  {p.notes && <p className="text-sm text-muted-foreground mt-2">{p.notes}</p>}
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">История здоровья</span>
                    <Button variant="outline" size="sm" onClick={() => setEventPet(Number(p.id))}>
                      <Plus className="h-3.5 w-3.5 mr-1" /> Событие
                    </Button>
                  </div>
                  {p.events.length === 0 && <div className="text-sm text-muted-foreground py-2">Событий пока нет</div>}
                  {p.events.map((e) => {
                    const EIcon = EVENT_ICON[e.eventType];
                    return (
                      <div key={Number(e.id)} className="flex items-start gap-3 rounded-lg border px-3 py-2.5">
                        <EIcon className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-sm font-medium">{e.title}</span>
                            <Badge variant="outline" className="text-xs">{EVENT_LABEL[e.eventType]}</Badge>
                          </div>
                          {e.detail && <div className="text-xs text-muted-foreground mt-0.5">{e.detail}</div>}
                          <div className="text-xs text-muted-foreground mt-0.5">{fmtDate(String(e.eventDate))}</div>
                        </div>
                        <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-destructive shrink-0"
                          onClick={() => delEvMut.mutate({ id: Number(e.id) })}>
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    );
                  })}
                </CardContent>
              </Card>
            );
          })}
          {(data ?? []).length === 0 && (
            <div className="lg:col-span-2 text-center text-muted-foreground py-16">
              Питомцев пока нет — добавьте первого
            </div>
          )}
        </div>
      )}

      {/* Диалог события */}
      <Dialog open={eventPet !== null} onOpenChange={(o) => !o && setEventPet(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Новое событие</DialogTitle></DialogHeader>
          <div className="space-y-4 pt-2">
            <div className="space-y-1.5">
              <Label>Тип</Label>
              <Select value={evForm.eventType} onValueChange={(v) => setEvForm({ ...evForm, eventType: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(EVENT_LABEL).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Название</Label>
              <Input placeholder="Например: Вакцинация от бешенства" value={evForm.title} onChange={(e) => setEvForm({ ...evForm, title: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <Label>Дата</Label>
              <Input type="date" value={evForm.eventDate} onChange={(e) => setEvForm({ ...evForm, eventDate: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <Label>Подробности</Label>
              <Textarea rows={3} value={evForm.detail} onChange={(e) => setEvForm({ ...evForm, detail: e.target.value })} />
            </div>
            <Button
              className="w-full"
              disabled={!evForm.title || evMut.isPending}
              onClick={() => eventPet && evMut.mutate({ petId: eventPet, eventType: evForm.eventType as any, title: evForm.title, eventDate: evForm.eventDate, detail: evForm.detail || undefined })}
            >
              Сохранить
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
