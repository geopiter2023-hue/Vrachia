import { useMemo, useState } from "react";
import { trpc } from "@/providers/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Building2, Megaphone, CalendarCheck, ShoppingCart, BarChart3, LogOut, Package } from "lucide-react";
import { toast } from "sonner";

// ─── Вход / регистрация клиники ──────────────────────────────────────────
function ClinicAuth({ onLoggedIn }: { onLoggedIn: () => void }) {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [orgName, setOrgName] = useState("");
  const [license, setLicense] = useState("");
  const [phone, setPhone] = useState("");
  const loginMut = trpc.clinic.login.useMutation();
  const regMut = trpc.clinic.register.useMutation();
  const busy = loginMut.isPending || regMut.isPending;

  const submit = async () => {
    try {
      if (mode === "login") {
        const r = await loginMut.mutateAsync({ email, password });
        if (!r.ok) return toast.error(r.error ?? "Ошибка входа");
      } else {
        const r = await regMut.mutateAsync({ email, password, orgName, licenseNumber: license || undefined, phone: phone || undefined });
        if (!r.ok) return toast.error(r.error ?? "Ошибка регистрации");
      }
      toast.success(mode === "login" ? "Добро пожаловать!" : "Клиника зарегистрирована!");
      onLoggedIn();
    } catch (e: any) {
      toast.error(e?.message ?? "Ошибка");
    }
  };

  return (
    <div className="mx-auto max-w-md space-y-4 py-8">
      <div className="text-center space-y-1">
        <Building2 className="mx-auto h-10 w-10 text-teal-600" />
        <h1 className="text-xl font-bold">Кабинет клиники</h1>
        <p className="text-sm text-muted-foreground">Агрегатор «AI Врач»: пациенты, продвижение, закупки</p>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <Button variant={mode === "login" ? "default" : "outline"} onClick={() => setMode("login")}>Вход</Button>
        <Button variant={mode === "register" ? "default" : "outline"} onClick={() => setMode("register")}>Регистрация</Button>
      </div>
      <Card>
        <CardContent className="space-y-3 pt-4">
          {mode === "register" && (
            <>
              <Input placeholder="Название организации" value={orgName} onChange={(e) => setOrgName(e.target.value)} />
              <Input placeholder="Номер мед. лицензии (обязателен для публикации)" value={license} onChange={(e) => setLicense(e.target.value)} />
              <Input placeholder="Телефон" value={phone} onChange={(e) => setPhone(e.target.value)} />
            </>
          )}
          <Input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
          <Input type="password" placeholder={mode === "register" ? "Пароль (минимум 8 символов)" : "Пароль"} value={password} onChange={(e) => setPassword(e.target.value)} />
          <Button className="w-full" disabled={busy || !email || !password || (mode === "register" && !orgName)} onClick={submit}>
            {mode === "login" ? "Войти" : "Зарегистрироваться"}
          </Button>
        </CardContent>
      </Card>
      <p className="text-xs text-muted-foreground text-center">
        Продвижение размещается с пометкой «Реклама» в соответствии с ФЗ «О рекламе».
      </p>
    </div>
  );
}

// ─── Профиль ─────────────────────────────────────────────────────────────
function ProfileTab() {
  const utils = trpc.useUtils();
  const { data } = trpc.clinic.getProfile.useQuery();
  const saveMut = trpc.clinic.saveProfile.useMutation();
  const publishMut = trpc.clinic.publish.useMutation();
  const p = data?.profile;
  const [form, setForm] = useState<Record<string, string>>({});
  const v = (k: string) => (k in form ? form[k] : String((p as any)?.[k] ?? ""));
  const set = (k: string, val: string) => setForm((f) => ({ ...f, [k]: val }));

  const save = async () => {
    try {
      await saveMut.mutateAsync({
        name: v("name"), city: v("city"),
        address: v("address") || undefined, phone: v("phone") || undefined,
        website: v("website") || undefined, specialties: v("specialties") || undefined,
        services: v("services") || undefined,
        priceFrom: v("priceFrom") ? Number(v("priceFrom")) : undefined,
        description: v("description") || undefined,
      });
      toast.success("Профиль сохранён");
      utils.clinic.getProfile.invalidate();
    } catch (e: any) { toast.error(e?.message ?? "Ошибка"); }
  };

  const togglePublish = async () => {
    const r = await publishMut.mutateAsync({ published: !p?.isPublished });
    if (!r.ok) toast.error(r.error ?? "Ошибка");
    else toast.success(!p?.isPublished ? "Клиника опубликована в каталоге" : "Клиника скрыта из каталога");
    utils.clinic.getProfile.invalidate();
  };

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between">
        <CardTitle className="text-base">Профиль в агрегаторе</CardTitle>
        {p && (
          <Button variant={p.isPublished ? "outline" : "default"} size="sm" onClick={togglePublish}>
            {p.isPublished ? "Снять с публикации" : "Опубликовать"}
          </Button>
        )}
      </CardHeader>
      <CardContent className="space-y-3">
        {p?.isPublished && <Badge className="bg-teal-600">Опубликовано в каталоге</Badge>}
        <Input placeholder="Название клиники *" value={v("name")} onChange={(e) => set("name", e.target.value)} />
        <Input placeholder="Город *" value={v("city")} onChange={(e) => set("city", e.target.value)} />
        <Input placeholder="Адрес" value={v("address")} onChange={(e) => set("address", e.target.value)} />
        <Input placeholder="Телефон" value={v("phone")} onChange={(e) => set("phone", e.target.value)} />
        <Input placeholder="Сайт" value={v("website")} onChange={(e) => set("website", e.target.value)} />
        <Input placeholder="Специализации (через запятую)" value={v("specialties")} onChange={(e) => set("specialties", e.target.value)} />
        <Input placeholder="Приём от, ₽" type="number" value={v("priceFrom")} onChange={(e) => set("priceFrom", e.target.value)} />
        <Textarea placeholder="Услуги" value={v("services")} onChange={(e) => set("services", e.target.value)} />
        <Textarea placeholder="Описание клиники" value={v("description")} onChange={(e) => set("description", e.target.value)} />
        <Button className="w-full" onClick={save} disabled={saveMut.isPending || !v("name") || !v("city")}>Сохранить</Button>
      </CardContent>
    </Card>
  );
}

// ─── Продвижение ─────────────────────────────────────────────────────────
function PromoTab() {
  const utils = trpc.useUtils();
  const { data: tariffs } = trpc.clinic.tariffs.useQuery();
  const { data: promos } = trpc.clinic.myPromotions.useQuery();
  const startMut = trpc.clinic.startPromotion.useMutation();
  const stopMut = trpc.clinic.stopPromotion.useMutation();

  const start = async (tariff: "priority" | "banner") => {
    const r = await startMut.mutateAsync({ tariff });
    if (!r.ok) toast.error(r.error ?? "Ошибка");
    else toast.success(r.note ?? "Кампания создана");
    utils.clinic.myPromotions.invalidate();
  };

  return (
    <div className="space-y-4">
      <div className="grid gap-3 md:grid-cols-2">
        {tariffs?.items.map((t) => (
          <Card key={t.code}>
            <CardHeader><CardTitle className="text-base flex items-center gap-2"><Megaphone className="h-4 w-4 text-teal-600" />{t.name}</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <p className="text-sm text-muted-foreground">{t.description}</p>
              <p className="text-xl font-bold">{t.priceMonth.toLocaleString("ru-RU")} ₽/мес</p>
              <Button className="w-full" variant="outline" disabled={startMut.isPending} onClick={() => start(t.code as "priority" | "banner")}>
                Подключить
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
      {promos?.items.length ? (
        <Card>
          <CardHeader><CardTitle className="text-base">Мои кампании</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {promos.items.map((pr) => (
              <div key={pr.id} className="flex items-center justify-between rounded-lg border p-3 text-sm">
                <div>
                  <span className="font-medium">{pr.tariff === "banner" ? "Бренд-размещение" : "Приоритет в выдаче"}</span>
                  <span className="text-muted-foreground"> · {pr.city} · {pr.priceMonth.toLocaleString("ru-RU")} ₽/мес</span>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={pr.status === "active" ? "default" : "secondary"}>
                    {pr.status === "active" ? "Активна" : pr.status === "paused" ? "Пауза" : "Остановлена"}
                  </Badge>
                  {pr.status === "active" && (
                    <Button size="sm" variant="ghost" onClick={async () => { await stopMut.mutateAsync({ id: pr.id }); utils.clinic.myPromotions.invalidate(); }}>
                      Остановить
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      ) : null}
      <p className="text-xs text-muted-foreground">Все размещения помечаются «Реклама». Оплата — по счёту после подтверждения менеджером.</p>
    </div>
  );
}

// ─── Записи пациентов ────────────────────────────────────────────────────
const BOOKING_STATUS: Record<string, string> = { new: "Новая", confirmed: "Подтверждена", done: "Завершена", cancelled: "Отменена" };

function BookingsTab() {
  const utils = trpc.useUtils();
  const { data } = trpc.clinic.bookings.useQuery();
  const statusMut = trpc.clinic.setBookingStatus.useMutation();
  const set = async (id: number, status: "confirmed" | "done" | "cancelled") => {
    await statusMut.mutateAsync({ id, status });
    utils.clinic.bookings.invalidate();
  };
  return (
    <Card>
      <CardHeader><CardTitle className="text-base flex items-center gap-2"><CalendarCheck className="h-4 w-4 text-teal-600" />Записи пациентов</CardTitle></CardHeader>
      <CardContent className="space-y-2">
        {!data?.items.length && <p className="text-sm text-muted-foreground">Записей пока нет. Они появятся, когда пациенты начнут записываться через каталог.</p>}
        {data?.items.map((b) => (
          <div key={b.id} className="rounded-lg border p-3 text-sm space-y-1">
            <div className="flex items-center justify-between">
              <span className="font-medium">{b.specialty ?? "Приём"} {b.preferredDate ? `· ${b.preferredDate}` : ""}</span>
              <Badge variant={b.status === "new" ? "default" : "secondary"}>{BOOKING_STATUS[b.status] ?? b.status}</Badge>
            </div>
            <p className="text-muted-foreground">Телефон: {b.contactPhone}</p>
            {b.reason && <p className="text-muted-foreground">Повод: {b.reason}</p>}
            {b.comment && <p className="text-muted-foreground">Комментарий: {b.comment}</p>}
            {b.status === "new" && (
              <div className="flex gap-2 pt-1">
                <Button size="sm" onClick={() => set(b.id, "confirmed")}>Подтвердить</Button>
                <Button size="sm" variant="outline" onClick={() => set(b.id, "cancelled")}>Отклонить</Button>
              </div>
            )}
            {b.status === "confirmed" && <Button size="sm" variant="outline" onClick={() => set(b.id, "done")}>Завершить</Button>}
          </div>
        ))}
      </CardContent>
    </Card>
  );
}

// ─── Маркетплейс ─────────────────────────────────────────────────────────
function MarketTab({ accountId }: { accountId: number }) {
  const utils = trpc.useUtils();
  const { data } = trpc.market.catalog.useQuery({});
  const { data: orders } = trpc.market.ordersFor.useQuery({ clinicAccountId: accountId });
  const orderMut = trpc.market.createOrder.useMutation();
  const [category, setCategory] = useState<string | null>(null);
  const [cart, setCart] = useState<Map<number, number>>(new Map());
  const [cartOpen, setCartOpen] = useState(false);

  const items = useMemo(() => (data?.items ?? []).filter((i) => !category || i.category === category), [data, category]);
  const cartTotal = useMemo(() => {
    let sum = 0;
    for (const [id, qty] of cart) {
      const p = data?.items.find((i) => i.id === id);
      if (p) sum += p.price * qty;
    }
    return sum;
  }, [cart, data]);

  const add = (id: number) => setCart((c) => new Map(c).set(id, (c.get(id) ?? 0) + 1));
  const checkout = async () => {
    try {
      const r = await orderMut.mutateAsync({
        clinicAccountId: accountId,
        items: [...cart.entries()].map(([productId, qty]) => ({ productId, qty })),
      });
      if (!r.ok) return toast.error(r.error ?? "Ошибка");
      toast.success(`Заказ №${r.orderId} на ${r.total.toLocaleString("ru-RU")} ₽ оформлен`);
      setCart(new Map());
      setCartOpen(false);
      utils.market.ordersFor.invalidate();
      utils.market.catalog.invalidate();
    } catch (e: any) { toast.error(e?.message ?? "Ошибка"); }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex flex-wrap gap-1">
          <Button size="sm" variant={!category ? "default" : "outline"} onClick={() => setCategory(null)}>Все</Button>
          {data?.categories.map((c) => (
            <Button key={c} size="sm" variant={category === c ? "default" : "outline"} onClick={() => setCategory(c)}>{c}</Button>
          ))}
        </div>
        <Button size="sm" onClick={() => setCartOpen(true)} disabled={!cart.size}>
          <ShoppingCart className="mr-1 h-4 w-4" />{cartTotal.toLocaleString("ru-RU")} ₽
        </Button>
      </div>
      <div className="grid gap-2">
        {items.map((i) => (
          <div key={i.id} className="flex items-center justify-between rounded-lg border p-3 text-sm">
            <div>
              <p className="font-medium">{i.name} {i.requiresLicense && <Badge variant="outline" className="ml-1 text-xs">рег. удостоверение</Badge>}</p>
              <p className="text-muted-foreground">{i.unit} · {i.supplier} · в наличии: {i.stock}</p>
            </div>
            <div className="flex items-center gap-2">
              <span className="font-bold whitespace-nowrap">{i.price.toLocaleString("ru-RU")} ₽</span>
              <Button size="sm" variant="outline" onClick={() => add(i.id)} disabled={i.stock <= 0}>+ В заказ</Button>
            </div>
          </div>
        ))}
      </div>

      <Dialog open={cartOpen} onOpenChange={setCartOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Заказ закупки</DialogTitle></DialogHeader>
          <div className="space-y-2 text-sm max-h-72 overflow-auto">
            {[...cart.entries()].map(([id, qty]) => {
              const p = data?.items.find((i) => i.id === id);
              if (!p) return null;
              return (
                <div key={id} className="flex items-center justify-between">
                  <span>{p.name} × {qty}</span>
                  <span className="font-medium">{(p.price * qty).toLocaleString("ru-RU")} ₽</span>
                </div>
              );
            })}
          </div>
          <p className="font-bold">Итого: {cartTotal.toLocaleString("ru-RU")} ₽</p>
          <Button className="w-full" disabled={orderMut.isPending} onClick={checkout}>Оформить заказ</Button>
        </DialogContent>
      </Dialog>

      {orders?.items.length ? (
        <Card>
          <CardHeader><CardTitle className="text-base flex items-center gap-2"><Package className="h-4 w-4" />Мои заказы</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {orders.items.map((o) => (
              <div key={o.id} className="rounded-lg border p-3 text-sm">
                <div className="flex items-center justify-between">
                  <span className="font-medium">Заказ №{o.id} · {o.total.toLocaleString("ru-RU")} ₽</span>
                  <Badge variant="secondary">{o.status === "new" ? "Новый" : o.status}</Badge>
                </div>
                <p className="text-muted-foreground">{o.lines.map((l) => `${l.name} × ${l.qty}`).join(", ")}</p>
              </div>
            ))}
          </CardContent>
        </Card>
      ) : null}
    </div>
  );
}

// ─── Статистика ──────────────────────────────────────────────────────────
function StatsTab() {
  const { data } = trpc.clinic.stats.useQuery();
  if (!data) return null;
  const cells = [
    { label: "Всего записей", value: data.bookingsTotal },
    { label: "Новых записей", value: data.bookingsNew },
    { label: "Завершено приёмов", value: data.bookingsDone },
    { label: "Активных кампаний", value: data.activePromotions },
  ];
  return (
    <div className="grid grid-cols-2 gap-3">
      {cells.map((c) => (
        <Card key={c.label}>
          <CardContent className="pt-4 text-center">
            <p className="text-3xl font-bold text-teal-600">{c.value}</p>
            <p className="text-sm text-muted-foreground">{c.label}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

// ─── Страница ────────────────────────────────────────────────────────────
export default function ClinicCabinetPage() {
  const { data: me, isLoading, refetch } = trpc.clinic.me.useQuery();
  const logoutMut = trpc.clinic.logout.useMutation();
  const [tab, setTab] = useState<"profile" | "promo" | "bookings" | "market" | "stats">("profile");

  if (isLoading) {
    return <div className="flex min-h-screen items-center justify-center"><div className="h-8 w-8 animate-spin rounded-full border-2 border-teal-600 border-t-transparent" /></div>;
  }
  if (!me?.clinic) {
    return <div className="min-h-screen bg-background p-4"><ClinicAuth onLoggedIn={() => refetch()} /></div>;
  }

  const TABS = [
    { key: "profile", label: "Профиль", icon: Building2 },
    { key: "promo", label: "Продвижение", icon: Megaphone },
    { key: "bookings", label: "Записи", icon: CalendarCheck },
    { key: "market", label: "Закупки", icon: ShoppingCart },
    { key: "stats", label: "Статистика", icon: BarChart3 },
  ] as const;

  return (
    <div className="min-h-screen bg-background">
      <div className="mx-auto max-w-3xl p-4 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-lg font-bold">{me.clinic.orgName}</h1>
            <p className="text-xs text-muted-foreground">Кабинет клиники · {me.clinic.email}</p>
          </div>
          <Button variant="ghost" size="sm" onClick={async () => { await logoutMut.mutateAsync(); refetch(); }}>
            <LogOut className="h-4 w-4" />
          </Button>
        </div>
        <div className="flex gap-1 overflow-x-auto">
          {TABS.map((t) => (
            <Button key={t.key} size="sm" variant={tab === t.key ? "default" : "outline"} onClick={() => setTab(t.key)}>
              <t.icon className="mr-1 h-4 w-4" />{t.label}
            </Button>
          ))}
        </div>
        {tab === "profile" && <ProfileTab />}
        {tab === "promo" && <PromoTab />}
        {tab === "bookings" && <BookingsTab />}
        {tab === "market" && <MarketTab accountId={me.clinic.id} />}
        {tab === "stats" && <StatsTab />}
      </div>
    </div>
  );
}
