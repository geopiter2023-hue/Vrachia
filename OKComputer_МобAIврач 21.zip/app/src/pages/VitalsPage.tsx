import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { VITAL_LABEL, fmtDateTime } from "@/lib/health-utils";
import { Plus, Watch } from "lucide-react";
import { toast } from "sonner";

type VitalType = "pressure_sys" | "pressure_dia" | "pulse" | "temperature" | "weight" | "spo2";

export default function VitalsPage() {
  const utils = trpc.useUtils();
  const [tab, setTab] = useState<VitalType>("pressure_sys");
  const { data, isLoading } = trpc.health.vitals.list.useQuery({ days: 120 });

  const addMut = trpc.health.vitals.add.useMutation({
    onSuccess: () => {
      toast.success("Показание сохранено");
      utils.health.vitals.list.invalidate();
      utils.health.notifications.list.invalidate();
    },
  });

  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ type: "pulse" as VitalType, value: "", dt: new Date().toISOString().slice(0, 16) });

  const rows = (data ?? []).filter((v) => v.vitalType === tab);
  const chartData = rows.map((v) => ({
    date: new Date(v.measuredAt).toLocaleDateString("ru-RU", { day: "numeric", month: "short" }),
    value: v.value,
  }));
  const latest = rows.length ? rows[rows.length - 1] : null;

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-xl md:text-2xl font-bold">Физиологические показатели</h1>
          <p className="text-muted-foreground text-sm mt-1 flex items-center gap-1.5">
            <Watch className="h-4 w-4" /> Ручной ввод и синхронизация с трекером
          </p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-1.5" /> Добавить показание
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Новое показание</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-2">
              <div className="space-y-1.5">
                <Label>Тип</Label>
                <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v as VitalType })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(VITAL_LABEL).map(([k, v]) => (
                      <SelectItem key={k} value={k}>
                        {v.name} ({v.unit})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label>Значение</Label>
                  <Input type="number" step="any" value={form.value} onChange={(e) => setForm({ ...form, value: e.target.value })} />
                </div>
                <div className="space-y-1.5">
                  <Label>Дата и время</Label>
                  <Input type="datetime-local" value={form.dt} onChange={(e) => setForm({ ...form, dt: e.target.value })} />
                </div>
              </div>
              <Button
                className="w-full"
                disabled={!form.value || addMut.isPending}
                onClick={() =>
                  addMut.mutate(
                    { vitalType: form.type, value: Number(form.value), measuredAt: new Date(form.dt).toISOString() },
                    { onSuccess: () => setOpen(false) }
                  )
                }
              >
                Сохранить
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs value={tab} onValueChange={(v) => setTab(v as VitalType)}>
        <TabsList className="flex-wrap h-auto">
          {Object.entries(VITAL_LABEL).map(([k, v]) => (
            <TabsTrigger key={k} value={k}>
              {v.name.split(" ")[0] === "Давление" ? v.name.replace("Давление ", "АД ") : v.name}
            </TabsTrigger>
          ))}
        </TabsList>
      </Tabs>

      <Card>
        <CardHeader className="pb-2 flex flex-row items-center justify-between">
          <CardTitle className="text-base">
            {VITAL_LABEL[tab].name}, {VITAL_LABEL[tab].unit}
          </CardTitle>
          {latest && (
            <span className="text-sm text-muted-foreground">
              Последнее: <b className="text-foreground">{latest.value}</b> · {fmtDateTime(latest.measuredAt)}
            </span>
          )}
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <Skeleton className="h-64" />
          ) : chartData.length ? (
            <div className="h-56 md:h-72">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData} margin={{ top: 8, right: 16, bottom: 0, left: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                  <XAxis dataKey="date" fontSize={11} />
                  <YAxis domain={["auto", "auto"]} fontSize={11} width={44} />
                  <Tooltip formatter={(v: any) => [`${v} ${VITAL_LABEL[tab].unit}`, VITAL_LABEL[tab].name]} />
                  <Line type="monotone" dataKey="value" stroke="#0d9488" strokeWidth={2.5} dot={{ r: 3 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="h-40 flex items-center justify-center text-muted-foreground text-sm">
              Нет данных за выбранный период
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
