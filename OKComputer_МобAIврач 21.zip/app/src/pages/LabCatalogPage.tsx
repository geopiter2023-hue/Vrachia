import { useMemo, useState } from "react";
import { LAB_CATALOG } from "@/lib/lab-catalog";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  BookOpenText,
  Search,
  ChevronDown,
  ChevronRight,
  FlaskConical,
  Info,
  BookOpen,
} from "lucide-react";
import { findGuideCodeByName } from "@/lib/biomarker-guide";
import { BiomarkerArticle } from "@/components/BiomarkerArticle";

const TOTAL = LAB_CATALOG.reduce((a, c) => a + c.tests.length, 0);

export default function LabCatalogPage() {
  const [query, setQuery] = useState("");
  const [openCats, setOpenCats] = useState<Set<string>>(new Set([LAB_CATALOG[0].category]));
  const [article, setArticle] = useState<{ code: string; name: string } | null>(null);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return LAB_CATALOG;
    return LAB_CATALOG.map((c) => ({
      ...c,
      tests: c.tests.filter(
        (t) =>
          t.name.toLowerCase().includes(q) ||
          t.desc.toLowerCase().includes(q)
      ),
    })).filter((c) => c.tests.length);
  }, [query]);

  const foundCount = filtered.reduce((a, c) => a + c.tests.length, 0);
  const searching = query.trim().length > 0;

  const toggleCat = (c: string) =>
    setOpenCats((s) => {
      const n = new Set(s);
      n.has(c) ? n.delete(c) : n.add(c);
      return n;
    });

  const isCatOpen = (c: string) => (searching ? true : openCats.has(c));

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl md:text-2xl font-bold flex items-center gap-2">
          <BookOpenText className="h-6 w-6 text-primary" /> Справочник анализов
        </h1>
        <p className="text-muted-foreground text-sm mt-1">
          {TOTAL} лабораторных исследований по {LAB_CATALOG.length} категориям — описание и подготовка к сдаче
        </p>
      </div>

      {/* Поиск */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Найти анализ — например: глюкоза, ТТГ, витамин D…"
          className="pl-9"
        />
      </div>
      {searching && (
        <p className="text-xs text-muted-foreground -mt-3">
          Найдено: {foundCount}
        </p>
      )}

      {/* Категории */}
      <div className="space-y-3">
        {filtered.map((c) => {
          const open = isCatOpen(c.category);
          return (
            <Card key={c.category}>
              <button
                onClick={() => toggleCat(c.category)}
                className="w-full flex items-center gap-3 px-4 py-3.5 text-left"
              >
                {open ? (
                  <ChevronDown className="h-4.5 w-4.5 text-primary shrink-0" size={18} />
                ) : (
                  <ChevronRight className="h-4.5 w-4.5 text-muted-foreground shrink-0" size={18} />
                )}
                <FlaskConical className="h-4 w-4 text-primary shrink-0" />
                <span className="font-semibold text-sm flex-1">{c.category}</span>
                <Badge variant="secondary">{c.tests.length}</Badge>
              </button>
              {open && (
                <CardContent className="pt-0 pb-3 space-y-2">
                  {c.tests.map((t) => {
                    const guideCode = findGuideCodeByName(t.name);
                    return (
                    <div
                      key={t.num}
                      className="rounded-xl bg-muted/50 border border-transparent hover:border-primary/20 transition-colors px-3.5 py-3 space-y-1.5"
                    >
                      <div className="flex items-start gap-2">
                        <span className="shrink-0 h-5 w-5 rounded-md bg-primary/10 text-primary text-[10px] font-bold flex items-center justify-center mt-0.5">
                          {t.num}
                        </span>
                        <span className="text-sm font-medium leading-snug flex-1">{t.name}</span>
                        {guideCode && (
                          <button
                            className="shrink-0 inline-flex items-center gap-1 rounded-full bg-teal-50 px-2 py-1 text-[11px] font-medium text-teal-700 hover:bg-teal-100 dark:bg-teal-950 dark:text-teal-300 dark:hover:bg-teal-900"
                            onClick={() => setArticle({ code: guideCode, name: t.name })}
                          >
                            <BookOpen className="h-3 w-3" /> Простыми словами
                          </button>
                        )}
                      </div>
                      {t.desc && (
                        <p className="text-xs text-muted-foreground leading-relaxed pl-7">
                          {t.desc}
                        </p>
                      )}
                      {t.prep && (
                        <p className="text-xs flex items-start gap-1.5 text-teal-700 dark:text-teal-400 pl-7">
                          <Info className="h-3 w-3 mt-0.5 shrink-0" />
                          {t.prep}
                        </p>
                      )}
                    </div>
                    );
                  })}
                </CardContent>
              )}
            </Card>
          );
        })}
        {filtered.length === 0 && (
          <Card>
            <CardContent className="py-14 text-center text-sm text-muted-foreground">
              По запросу «{query}» ничего не найдено
            </CardContent>
          </Card>
        )}
      </div>

      {article && (
        <BiomarkerArticle
          open={article != null}
          onOpenChange={(v) => !v && setArticle(null)}
          code={article.code}
          name={article.name}
        />
      )}
    </div>
  );
}
