import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import {
  ShieldCheck, Building2, Megaphone, ShoppingCart, Users, LayoutDashboard,
  LogOut, Package, CheckCircle2, XCircle, Ban, Plus, Pencil,
} from "lucide-react";
import { toast } from "sonner";

// ─── Вход администратора ─────────────────────────────────────────────────
function AdminAuth({ onLoggedIn }: { onLoggedIn: () => void }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const loginMut = trpc.admin.login.useMutation();
  const submit = async () => {
    const r = await loginMut.mutateAsync({ email, password });
    if (!r.ok) return toast.error(r.error ?? "Ошибка входа");
    onLoggedIn();
  };
  return (
    <div className="mx-auto max-w-sm space-y-4 py-12">
      <div className="text-center space-y-1">
        <ShieldCheck className="mx-auto h-10 w-10 text-teal-600" />
        <h1 className="text-xl font-bold">Администрирование</h1>
        <p className="text-sm text-muted-foreground">Платформа «AI Врач»</p>
      </div>
      <Card>
        <CardContent className="space-y-3 pt-4">
          <Input type="email" placeholder="Email администратора" value={email} onChange={(e) => setEmail(e.target.value)} />
          <Input type="password" placeholder="Пароль" value={password} onChange={(e) => setPassword(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && submit()} />
          <Button className="w-full" disabled={loginMut.isPending || !email || !password} onClick={submit}>Войти</Button>
        </CardContent>
      </Card>
    </div>
  );
}

// ─── Дашборд ─────────────────────────────────────────────────────────────
function DashboardTab() {
  const { data: d } = trpc.admin.dashboard.useQuery();
  if (!d) return null;
  const cells = [
    { label: "Пользователей всего", value: d.users.total, sub: `+${d.users.week} за неделю` },
    { label: "Новых за сутки", value: d.users.day, sub: "регистрации" },
    { label: "Клиник зарегистрировано", value: d.clinics.total, sub: `${d.clinics.published} опубликовано` },
    { label: "На модерации", value: d.clinics.pendingModeration, sub: "профили клиник", warn: d.clinics.pendingModeration > 0 },
    { label: "Заявок на запись", value: d.bookings.total, sub: `${d.bookings.new} новых` },
    { label: "Активных кампаний", value: d.promotions.active, sub: `${d.promotions.revenueMonth.toLocaleString("ru-RU")} ₽/мес` },
    { label: "Ждут оплаты", value: d.promotions.pendingPayment, sub: "кампании", warn: d.promotions.pendingPayment > 0 },
    { label: "Заказов маркетплейса", value: d.market.orders, sub: `${d.market.revenue.toLocaleString("ru-RU")} ₽ оборот` },
    { label: "Новых заказов", value: d.market.newOrders, sub: "требуют обработки", warn: d.market.newOrders > 0 },
  ];
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
      {cells.map((c) => (
        <Card key={c.label} className={c.warn ? "border-amber-500/60" : undefined}>
          <CardContent className="pt-4 text-center">
            <p className={`text-2xl font-bold ${c.warn ? "text-amber-600" : "text-teal-600"}`}>{c.value}</p>
            <p className="text-xs font-medium">{c.label}</p>
            <p className="text-xs text-muted-foreground">{c.sub}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

// ─── Клиники ─────────────────────────────────────────────────────────────
const MOD_LABEL: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
  pending: { label: "На модерации", variant: "outline" },
  approved: { label: "Одобрена", variant: "default" },
  rejected: { label: "Отклонена", variant: "destructive" },
};

function ClinicsTab() {
  const utils = trpc.useUtils();
  const { data } = trpc.admin.clinics.useQuery();
  const moderateMut = trpc.admin.moderateClinic.useMutation();
  const blockMut = trpc.admin.blockClinic.useMutation();

  const moderate = async (profileId: number, decision: "approved" | "rejected") => {
    await moderateMut.mutateAsync({ profileId, decision });
    toast.success(decision === "approved" ? "Клиника одобрена и опубликована" : "Публикация отклонена");
    utils.admin.clinics.invalidate();
    utils.admin.dashboard.invalidate();
  };
  const block = async (accountId: number, blocked: boolean) => {
    await blockMut.mutateAsync({ accountId, blocked });
    toast.success(blocked ? "Клиника заблокирована" : "Клиника разблокирована");
    utils.admin.clinics.invalidate();
  };

  return (
    <div className="space-y-2">
      {!data?.items.length && <p className="text-sm text-muted-foreground">Клиник пока нет.</p>}
      {data?.items.map((c) => (
        <Card key={c.accountId}>
          <CardContent className="pt-4 space-y-2 text-sm">
            <div className="flex items-start justify-between gap-2">
              <div>
                <p className="font-semibold">{c.orgName}</p>
                <p className="text-muted-foreground">{c.email}{c.phone ? ` · ${c.phone}` : ""}</p>
              </div>
              <div className="flex gap-1 shrink-0">
                {c.blocked && <Badge variant="destructive">Заблокирована</Badge>}
                {c.moderation && <Badge variant={MOD_LABEL[c.moderation]?.variant ?? "secondary"}>{MOD_LABEL[c.moderation]?.label ?? c.moderation}</Badge>}
                {c.isPublished && <Badge className="bg-teal-600">В каталоге</Badge>}
              </div>
            </div>
            <p className="text-muted-foreground">
              Лицензия: {c.licenseNumber ?? "—"}{c.city ? ` · ${c.city}` : ""}{c.profileName ? ` · профиль «${c.profileName}»` : " · профиль не заполнен"}
            </p>
            <div className="flex flex-wrap gap-2">
              {c.profileId && c.moderation === "pending" && (
                <>
                  <Button size="sm" onClick={() => moderate(c.profileId!, "approved")}><CheckCircle2 className="mr-1 h-4 w-4" />Одобрить</Button>
                  <Button size="sm" variant="outline" onClick={() => moderate(c.profileId!, "rejected")}><XCircle className="mr-1 h-4 w-4" />Отклонить</Button>
                </>
              )}
              <Button size="sm" variant={c.blocked ? "outline" : "destructive"} onClick={() => block(c.accountId, !c.blocked)}>
                <Ban className="mr-1 h-4 w-4" />{c.blocked ? "Разблокировать" : "Заблокировать"}
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

// ─── Рекламные кампании ──────────────────────────────────────────────────
const PROMO_STATUS: Record<string, string> = {
  pending_payment: "Ждёт оплаты", active: "Активна", paused: "Пауза", stopped: "Остановлена",
};

function PromosTab() {
  const utils = trpc.useUtils();
  const { data } = trpc.admin.promotions.useQuery();
  const payMut = trpc.admin.confirmPayment.useMutation();
  const stopMut = trpc.admin.stopPromotion.useMutation();
  return (
    <div className="space-y-2">
      {!data?.items.length && <p className="text-sm text-muted-foreground">Кампаний пока нет.</p>}
      {data?.items.map((p) => (
        <Card key={p.id}>
          <CardContent className="pt-4 flex items-center justify-between gap-2 text-sm">
            <div>
              <p className="font-semibold">{p.orgName}</p>
              <p className="text-muted-foreground">
                {p.tariff === "banner" ? "Бренд-размещение" : "Приоритет в выдаче"} · {p.city} · {p.priceMonth.toLocaleString("ru-RU")} ₽/мес
              </p>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <Badge variant={p.status === "active" ? "default" : p.status === "pending_payment" ? "outline" : "secondary"}>
                {PROMO_STATUS[p.status] ?? p.status}
              </Badge>
              {p.status === "pending_payment" && (
                <Button size="sm" onClick={async () => { await payMut.mutateAsync({ id: p.id }); utils.admin.promotions.invalidate(); toast.success("Оплата подтверждена, кампания активна"); }}>
                  Оплата получена
                </Button>
              )}
              {p.status === "active" && (
                <Button size="sm" variant="outline" onClick={async () => { await stopMut.mutateAsync({ id: p.id }); utils.admin.promotions.invalidate(); }}>
                  Остановить
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

// ─── Маркетплейс: товары ─────────────────────────────────────────────────
function ProductsTab() {
  const utils = trpc.useUtils();
  const { data } = trpc.admin.products.useQuery();
  const saveMut = trpc.admin.saveProduct.useMutation();
  const delMut = trpc.admin.deleteProduct.useMutation();
  const [edit, setEdit] = useState<any | null>(null);

  const save = async () => {
    try {
      await saveMut.mutateAsync({
        id: edit.id,
        category: edit.category, name: edit.name, unit: edit.unit || "упак.",
        price: Number(edit.price), stock: Number(edit.stock),
        supplier: edit.supplier || undefined,
        requiresLicense: Boolean(edit.requiresLicense),
        description: edit.description || undefined,
      });
      toast.success("Товар сохранён");
      setEdit(null);
      utils.admin.products.invalidate();
    } catch (e: any) { toast.error(e?.message ?? "Ошибка"); }
  };

  return (
    <div className="space-y-2">
      <Button size="sm" onClick={() => setEdit({ category: "", name: "", unit: "упак.", price: 0, stock: 0, requiresLicense: false })}>
        <Plus className="mr-1 h-4 w-4" />Добавить товар
      </Button>
      {data?.items.map((p) => (
        <Card key={p.id}>
          <CardContent className="pt-4 flex items-center justify-between gap-2 text-sm">
            <div>
              <p className="font-medium">{p.name} {p.requiresLicense && <Badge variant="outline" className="ml-1 text-xs">рег. уд.</Badge>}</p>
              <p className="text-muted-foreground">{p.category} · {p.unit} · {p.supplier ?? "—"} · склад: {p.stock}</p>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <span className="font-bold">{p.price.toLocaleString("ru-RU")} ₽</span>
              <Button size="sm" variant="ghost" onClick={() => setEdit({ ...p })}><Pencil className="h-4 w-4" /></Button>
              <Button size="sm" variant="ghost" onClick={async () => { await delMut.mutateAsync({ id: p.id }); utils.admin.products.invalidate(); }}>
                <XCircle className="h-4 w-4 text-destructive" />
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}

      <Dialog open={Boolean(edit)} onOpenChange={(o) => !o && setEdit(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>{edit?.id ? "Редактировать товар" : "Новый товар"}</DialogTitle></DialogHeader>
          {edit && (
            <div className="space-y-3">
              <Input placeholder="Категория *" value={edit.category} onChange={(e) => setEdit({ ...edit, category: e.target.value })} />
              <Input placeholder="Название *" value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} />
              <div className="grid grid-cols-2 gap-2">
                <Input placeholder="Единица" value={edit.unit} onChange={(e) => setEdit({ ...edit, unit: e.target.value })} />
                <Input placeholder="Поставщик" value={edit.supplier ?? ""} onChange={(e) => setEdit({ ...edit, supplier: e.target.value })} />
                <Input type="number" placeholder="Цена ₽ *" value={edit.price} onChange={(e) => setEdit({ ...edit, price: e.target.value })} />
                <Input type="number" placeholder="Остаток" value={edit.stock} onChange={(e) => setEdit({ ...edit, stock: e.target.value })} />
              </div>
              <label className="flex items-center gap-2 text-sm">
                <input type="checkbox" checked={Boolean(edit.requiresLicense)} onChange={(e) => setEdit({ ...edit, requiresLicense: e.target.checked })} />
                Требует регистрационного удостоверения
              </label>
              <Textarea placeholder="Описание" value={edit.description ?? ""} onChange={(e) => setEdit({ ...edit, description: e.target.value })} />
              <Button className="w-full" disabled={!edit.category || !edit.name || !Number(edit.price)} onClick={save}>Сохранить</Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ─── Маркетплейс: заказы ─────────────────────────────────────────────────
const ORDER_STATUS: Record<string, string> = { new: "Новый", paid: "Оплачен", shipped: "Отгружен", done: "Выполнен", cancelled: "Отменён" };

function OrdersTab() {
  const utils = trpc.useUtils();
  const { data } = trpc.admin.orders.useQuery();
  const statusMut = trpc.admin.setOrderStatus.useMutation();
  const set = async (id: number, status: "paid" | "shipped" | "done" | "cancelled") => {
    await statusMut.mutateAsync({ id, status });
    utils.admin.orders.invalidate();
    utils.admin.dashboard.invalidate();
  };
  return (
    <div className="space-y-2">
      {!data?.items.length && <p className="text-sm text-muted-foreground">Заказов пока нет.</p>}
      {data?.items.map((o) => (
        <Card key={o.id}>
          <CardContent className="pt-4 space-y-1 text-sm">
            <div className="flex items-center justify-between">
              <p className="font-semibold">Заказ №{o.id} · {o.total.toLocaleString("ru-RU")} ₽</p>
              <Badge variant={o.status === "new" ? "default" : "secondary"}>{ORDER_STATUS[o.status] ?? o.status}</Badge>
            </div>
            <p className="text-muted-foreground">{o.orgName} · {o.email}</p>
            <p className="text-muted-foreground">{o.lines.map((l) => `${l.name} × ${l.qty}`).join(", ")}</p>
            <div className="flex gap-2 pt-1">
              {o.status === "new" && <Button size="sm" onClick={() => set(o.id, "paid")}>Оплачен</Button>}
              {o.status === "paid" && <Button size="sm" onClick={() => set(o.id, "shipped")}>Отгружен</Button>}
              {o.status === "shipped" && <Button size="sm" onClick={() => set(o.id, "done")}>Выполнен</Button>}
              {["new", "paid"].includes(o.status) && <Button size="sm" variant="outline" onClick={() => set(o.id, "cancelled")}>Отменить</Button>}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

// ─── Пользователи ────────────────────────────────────────────────────────
function UsersTab() {
  const utils = trpc.useUtils();
  const [q, setQ] = useState("");
  const { data } = trpc.admin.users.useQuery({ q: q || undefined });
  const blockMut = trpc.admin.blockUser.useMutation();
  return (
    <div className="space-y-2">
      <Input placeholder="Поиск по email, телефону, Telegram…" value={q} onChange={(e) => setQ(e.target.value)} />
      <p className="text-xs text-muted-foreground">Медицинские данные пользователей администратору недоступны (ФЗ-152).</p>
      {data?.items.map((u) => (
        <Card key={u.id}>
          <CardContent className="pt-4 flex items-center justify-between gap-2 text-sm">
            <div>
              <p className="font-medium">#{u.id} {u.email ?? u.phone ?? (u.tgUsername ? `@${u.tgUsername}` : "Telegram")}</p>
              <p className="text-muted-foreground">
                {u.email && u.phone ? `${u.phone} · ` : ""}регистрация: {u.createdAt ? new Date(u.createdAt).toLocaleDateString("ru-RU") : "—"}
              </p>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              {u.blocked && <Badge variant="destructive">Заблокирован</Badge>}
              <Button size="sm" variant={u.blocked ? "outline" : "destructive"}
                onClick={async () => { await blockMut.mutateAsync({ id: u.id, blocked: !u.blocked }); utils.admin.users.invalidate(); toast.success(u.blocked ? "Разблокирован" : "Заблокирован, сессии сброшены"); }}>
                {u.blocked ? "Разблокировать" : "Заблокировать"}
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

// ─── Страница ────────────────────────────────────────────────────────────
export default function AdminPage() {
  const { data: me, isLoading, refetch } = trpc.admin.me.useQuery();
  const logoutMut = trpc.admin.logout.useMutation();
  const [tab, setTab] = useState<"dash" | "clinics" | "promos" | "products" | "orders" | "users">("dash");

  if (isLoading) {
    return <div className="flex min-h-screen items-center justify-center"><div className="h-8 w-8 animate-spin rounded-full border-2 border-teal-600 border-t-transparent" /></div>;
  }
  if (!me?.admin) {
    return (
      <div className="min-h-screen bg-background p-4">
        <AdminAuth onLoggedIn={() => refetch()} />
        {!me?.configured && (
          <p className="mx-auto max-w-sm text-center text-xs text-amber-600">
            Администраторы не настроены: задайте ADMIN_EMAILS и ADMIN_PASSWORD в переменных окружения сервера.
          </p>
        )}
      </div>
    );
  }

  const TABS = [
    { key: "dash", label: "Обзор", icon: LayoutDashboard },
    { key: "clinics", label: "Клиники", icon: Building2 },
    { key: "promos", label: "Реклама", icon: Megaphone },
    { key: "products", label: "Товары", icon: Package },
    { key: "orders", label: "Заказы", icon: ShoppingCart },
    { key: "users", label: "Пользователи", icon: Users },
  ] as const;

  return (
    <div className="min-h-screen bg-background">
      <div className="mx-auto max-w-3xl p-4 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-lg font-bold flex items-center gap-2"><ShieldCheck className="h-5 w-5 text-teal-600" />Администрирование</h1>
            <p className="text-xs text-muted-foreground">{me.admin.email}</p>
          </div>
          <Button variant="ghost" size="sm" onClick={async () => { await logoutMut.mutateAsync(); refetch(); }}>
            <LogOut className="h-4 w-4" />
          </Button>
        </div>
        <div className="flex gap-1 overflow-x-auto">
          {TABS.map((t) => (
            <Button key={t.key} size="sm" variant={tab === t.key ? "default" : "outline"} onClick={() => setTab(t.key)}>
              <t.icon className="mr-1 h-4 w-4" />{t.label}
            </Button>
          ))}
        </div>
        {tab === "dash" && <DashboardTab />}
        {tab === "clinics" && <ClinicsTab />}
        {tab === "promos" && <PromosTab />}
        {tab === "products" && <ProductsTab />}
        {tab === "orders" && <OrdersTab />}
        {tab === "users" && <UsersTab />}
      </div>
    </div>
  );
}
