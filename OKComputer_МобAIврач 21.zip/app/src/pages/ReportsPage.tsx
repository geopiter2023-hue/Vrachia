import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { STATUS_LABEL, STATUS_CLASS, fmtDate, type Status } from "@/lib/health-utils";
import { FileDown, FileJson, FileText, FileSpreadsheet } from "lucide-react";
import { toast } from "sonner";
import { exportReportPdf } from "@/lib/report-pdf";
import DoctorBrief from "@/components/DoctorBrief";
import YearWrapped from "@/components/YearWrapped";

function download(filename: string, content: string, mime: string) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export default function ReportsPage() {
  const [from, setFrom] = useState("2024-01-01");
  const [to, setTo] = useState(new Date().toISOString().slice(0, 10));
  const [pdfBusy, setPdfBusy] = useState(false);
  const { data, isLoading } = trpc.health.reports.data.useQuery({ from, to });

  const exportPdf = async () => {
    if (!data) return;
    setPdfBusy(true);
    try {
      await exportReportPdf(data as any, from, to);
      toast.success("Отчёт на фирменном бланке выгружен (PDF)");
    } catch {
      toast.error("Не удалось сформировать PDF");
    } finally {
      setPdfBusy(false);
    }
  };

  const fhir = trpc.health.reports.fhir.useQuery(undefined, { enabled: false });
  const csv = trpc.health.reports.csv.useQuery(undefined, { enabled: false });

  const exportFhir = async () => {
    const res = await fhir.refetch();
    if (res.data) {
      download(`fhir-bundle-${to}.json`, JSON.stringify(res.data, null, 2), "application/json");
      toast.success("FHIR R4 Bundle выгружен");
    }
  };
  const exportCsv = async () => {
    const res = await csv.refetch();
    if (res.data) {
      download(`biomarkers-${to}.csv`, "\uFEFF" + res.data.csv, "text/csv");
      toast.success("CSV выгружен");
    }
  };

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl md:text-2xl font-bold">Отчёты и экспорт</h1>
        <p className="text-muted-foreground text-sm mt-1">
          Полная история за период, динамический отчёт с AI-комментариями, экспорт FHIR / CSV
        </p>
      </div>

      {/* Отчёт для врача — одна страница перед приёмом */}
      <DoctorBrief />

      {/* Мой год здоровья */}
      <YearWrapped />

      <Card>
        <CardContent className="pt-5 flex flex-wrap items-end gap-3">
          <div className="space-y-1.5">
            <Label>Период с</Label>
            <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label>по</Label>
            <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} />
          </div>
          <div className="flex gap-2 md:ml-auto flex-wrap w-full md:w-auto">
            <Button variant="outline" onClick={exportPdf} disabled={pdfBusy || !data}>
              <FileText className="h-4 w-4 mr-1.5" /> {pdfBusy ? "Формирую…" : "Бланк PDF"}
            </Button>
            <Button variant="outline" onClick={exportFhir}>
              <FileJson className="h-4 w-4 mr-1.5" /> FHIR R4
            </Button>
            <Button variant="outline" onClick={exportCsv}>
              <FileSpreadsheet className="h-4 w-4 mr-1.5" /> CSV
            </Button>
          </div>
        </CardContent>
      </Card>

      {isLoading || !data ? (
        <Skeleton className="h-96" />
      ) : (
        <div className="space-y-5 print:space-y-4" id="report">
          {/* Заголовок отчёта */}
          <div className="rounded-xl border bg-card p-5">
            <div className="flex items-center gap-2 text-lg font-bold">
              <FileDown className="h-5 w-5 text-primary" />
              Динамический отчёт о состоянии здоровья
            </div>
            <div className="text-sm text-muted-foreground mt-1">
              Период: {fmtDate(from)} — {fmtDate(to)} · Документов: {data.docs.length} · Показателей: {data.biomarkers.length}
            </div>
          </div>

          {/* AI-комментарии */}
          {data.interpretations.length > 0 && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">AI-интерпретация отклонений</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {data.interpretations.map((t, i) => (
                  <div key={i} className="text-sm rounded-lg bg-muted px-3 py-2.5 whitespace-pre-line">
                    {t.replace(/\*\*/g, "")}
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {data.correlations.length > 0 && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Выявленные взаимосвязи</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {data.correlations.map((c, i) => (
                  <div key={i} className="text-sm rounded-lg bg-muted px-3 py-2.5">{c}</div>
                ))}
              </CardContent>
            </Card>
          )}

          {/* Таблица показателей */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Показатели за период</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b text-left text-muted-foreground">
                      <th className="py-2 pr-4 font-medium">Показатель</th>
                      <th className="py-2 pr-4 font-medium">Измерения</th>
                      <th className="py-2 pr-4 font-medium">Норма</th>
                      <th className="py-2 font-medium">Статус</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.biomarkers.map((b) => (
                      <tr key={b.biomarker.code} className="border-b last:border-0">
                        <td className="py-2.5 pr-4 font-medium">{b.biomarker.name}</td>
                        <td className="py-2.5 pr-4 text-muted-foreground">
                          {b.points.map((p) => `${p.value} (${fmtDate(p.date)})`).join(" → ")}
                        </td>
                        <td className="py-2.5 pr-4 text-muted-foreground whitespace-nowrap">
                          {b.biomarker.refLow}–{b.biomarker.refHigh} {b.biomarker.unit}
                        </td>
                        <td className="py-2.5">
                          <Badge className={STATUS_CLASS[b.status as Status]} variant="secondary">
                            {STATUS_LABEL[b.status as Status]}
                          </Badge>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>

          {/* Документы */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Документы за период</CardTitle>
            </CardHeader>
            <CardContent className="space-y-1.5">
              {data.docs.map((d) => (
                <div key={Number(d.id)} className="flex items-center justify-between rounded-lg border px-3 py-2 text-sm">
                  <span className="font-medium">{d.title}</span>
                  <span className="text-muted-foreground text-xs">
                    {d.source} · {fmtDate(String(d.docDate))}
                  </span>
                </div>
              ))}
            </CardContent>
          </Card>

          <p className="text-xs text-muted-foreground">
            Отчёт сформирован локальным аналитическим движком системы «AI Врач». Результат не является диагнозом — при отклонениях требуется консультация врача.
          </p>
        </div>
      )}
    </div>
  );
}
