import { useEffect, useRef, useState } from "react";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import {
  BotMessageSquare,
  Send,
  ShieldCheck,
  Sparkles,
  FileSearch,
  Siren,
  Stethoscope,
  ClipboardList,
  ChevronRight,
  Activity,
  AlertTriangle,
  User,
  RotateCcw,
  CheckCircle2,
} from "lucide-react";

type Msg = { role: "ai" | "user"; text: string; conclusion?: Conclusion };
type Conclusion = {
  specialist: string;
  urgent: boolean;
  diagnoses: { name: string; prob: number; note: string }[];
  redFlags: string[];
  plan: string[];
};

const CHIPS = [
  { icon: Sparkles, label: "Описать симптомы" },
  { icon: FileSearch, label: "Разбор анализов" },
  { icon: Siren, label: "Оценка срочности" },
  { icon: Stethoscope, label: "К кому обратиться" },
];

const STEPS = [
  { n: 1, title: "Опишите жалобу", text: "Напишите свободным текстом, что беспокоит — ИИ-доктор определит тему консультации" },
  { n: 2, title: "Ответьте на вопросы", text: "Короткий опрос поможет быстрее понять вашу ситуацию" },
  { n: 3, title: "Учитываются ваши данные", text: "Заключение строится с учётом ваших загруженных анализов и документов" },
  { n: 4, title: "Получите заключение", text: "Вероятные причины, план действий и красные флаги — понятным языком" },
];

const FAQ = [
  {
    q: "Как работает ИИ-доктор и что я получу в конце?",
    a: "ИИ-доктор уточнит симптомы и учтёт ваши анализы и документы из системы. В конце вы получите заключение с наиболее вероятными причинами жалоб, понятным планом действий, рекомендацией, к кому обратиться, и списком тревожных симптомов, за которыми важно следить.",
  },
  {
    q: "Используются ли мои анализы и документы?",
    a: "Да. Заключение персонализируется: система учитывает отклонения в ваших биомаркерах и историю загруженных документов. Все данные обрабатываются внутри системы и никуда не передаются.",
  },
  {
    q: "Какие симптомы лучше указать, чтобы ответ был точнее?",
    a: "За одну консультацию лучше разбирать одну основную проблему — так ответ будет точнее. Укажите, как давно началось, что усиливает и облегчает состояние, есть ли температура и другие сопутствующие жалобы.",
  },
  {
    q: "В каких случаях нужно сразу к врачу?",
    a: "ИИ-доктор не назначает лечение и не заменяет врача. Если состояние выглядит срочным или быстро ухудшается — не ждите ответа в чате и сразу обращайтесь за медицинской помощью (103/112).",
  },
];

const SUGGESTIONS = [
  "Устают глаза и мутнеет картинка после работы за компьютером",
  "Болит голова и кружится к вечеру",
  "Второй день першит горло и сухой кашель",
  "Скачет давление и иногда колет сердце",
];

function renderMd(text: string) {
  return text.split("\n").map((line, i) => {
    const parts = line.split(/(\*\*[^*]+\*\*)/g).map((p, j) =>
      p.startsWith("**") && p.endsWith("**") ? <b key={j}>{p.slice(2, -2)}</b> : <span key={j}>{p}</span>
    );
    return <p key={i} className={line.trim() === "" ? "h-2" : ""}>{parts}</p>;
  });
}

function ConclusionCard({ c }: { c: Conclusion }) {
  return (
    <Card className="border-primary/30 bg-gradient-to-b from-primary/5 to-transparent">
      <CardContent className="p-4 space-y-4">
        <div className="flex items-center gap-2 font-semibold">
          <ClipboardList className="h-5 w-5 text-primary" /> Заключение ИИ-доктора
          {c.urgent && (
            <span className="ml-auto text-xs bg-destructive/10 text-destructive px-2 py-1 rounded-full flex items-center gap-1">
              <AlertTriangle className="h-3 w-3" /> Требуется осмотр врача
            </span>
          )}
        </div>
        <div className="space-y-3">
          {c.diagnoses.map((d, i) => (
            <div key={i}>
              <div className="flex items-baseline justify-between gap-2 text-sm">
                <span className="font-medium">{d.name}</span>
                <span className="text-primary font-semibold shrink-0">{d.prob}%</span>
              </div>
              <div className="h-1.5 rounded-full bg-muted mt-1 overflow-hidden">
                <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${d.prob}%` }} />
              </div>
              <p className="text-xs text-muted-foreground mt-1">{d.note}</p>
            </div>
          ))}
        </div>
        <div className="text-sm">
          <div className="font-medium mb-1.5">План действий</div>
          <ol className="list-decimal list-inside space-y-1 text-muted-foreground">
            {c.plan.map((p, i) => <li key={i}>{p}</li>)}
          </ol>
        </div>
        <div className="rounded-lg bg-destructive/5 border border-destructive/20 p-3 text-sm">
          <div className="font-medium text-destructive mb-1 flex items-center gap-1.5">
            <AlertTriangle className="h-4 w-4" /> Красные флаги
          </div>
          <ul className="space-y-1 text-muted-foreground">
            {c.redFlags.map((f, i) => <li key={i}>• {f}</li>)}
          </ul>
        </div>
        <div className="text-sm flex items-center gap-2">
          <Stethoscope className="h-4 w-4 text-primary" />
          К кому обращаться: <b>{c.specialist}</b>
        </div>
      </CardContent>
    </Card>
  );
}

export default function AssistantPage() {
  const [screen, setScreen] = useState<"intro" | "chat">("intro");
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [done, setDone] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  const summary = trpc.aiDoctor.stateSummary.useQuery(undefined, { enabled: screen === "intro" });

  const startMut = trpc.aiDoctor.start.useMutation({
    onSuccess: (res) => {
      setSessionId(res.sessionId);
      setMessages((m) => [...m, ...res.messages.map((t) => ({ role: "ai" as const, text: t }))]);
    },
    onError: () => setMessages((m) => [...m, { role: "ai", text: "Не удалось начать консультацию. Попробуйте ещё раз." }]),
  });

  const replyMut = trpc.aiDoctor.reply.useMutation({
    onSuccess: (res) => {
      setMessages((m) => [
        ...m,
        ...res.messages.map((t, i) => ({
          role: "ai" as const,
          text: t,
          conclusion: i === 0 && res.conclusion ? (res.conclusion as Conclusion) : undefined,
        })),
      ]);
      if (res.done) {
        setDone(true);
        setSessionId(null);
      }
    },
    onError: () => setMessages((m) => [...m, { role: "ai", text: "Произошла ошибка. Попробуйте ещё раз." }]),
  });

  const busy = startMut.isPending || replyMut.isPending;

  const sendComplaint = (text: string) => {
    if (!text.trim() || busy) return;
    setScreen("chat");
    setMessages([{ role: "user", text }]);
    setInput("");
    startMut.mutate({ complaint: text });
  };

  const sendReply = () => {
    const text = input.trim();
    if (!text || busy || !sessionId) return;
    setMessages((m) => [...m, { role: "user", text }]);
    setInput("");
    replyMut.mutate({ sessionId, message: text });
  };

  const reset = () => {
    setMessages([]);
    setSessionId(null);
    setDone(false);
    setScreen("intro");
  };

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, busy]);

  if (screen === "intro") {
    const s = summary.data;
    return (
      <div className="space-y-6 pb-8">
        {/* Hero */}
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-primary via-teal-600 to-teal-800 text-primary-foreground p-6 md:p-8">
          <div className="absolute -right-8 -top-8 h-44 w-44 rounded-full bg-white/10" />
          <div className="absolute -right-2 top-16 h-24 w-24 rounded-full bg-white/10" />
          <div className="flex flex-wrap gap-2 mb-4">
            {CHIPS.map((c) => (
              <span key={c.label} className="inline-flex items-center gap-1.5 rounded-full bg-white/15 backdrop-blur px-3 py-1.5 text-xs font-medium">
                <c.icon className="h-3.5 w-3.5" /> {c.label}
              </span>
            ))}
          </div>
          <h1 className="text-2xl md:text-3xl font-bold leading-tight">
            Расскажите о симптомах<br />и получите <span className="text-amber-300">план действий</span>
          </h1>
          <p className="mt-3 text-sm md:text-base text-primary-foreground/85 max-w-xl">
            ИИ-доктор уточнит жалобы, оценит срочность, предположит наиболее вероятные причины и подскажет следующие шаги — с учётом ваших анализов и документов в системе.
          </p>
          <p className="mt-3 text-xs text-primary-foreground/70 max-w-xl border-t border-white/15 pt-3">
            Информационный сервис: не является медицинской услугой, не ставит диагнозы и не заменяет консультацию врача.
            При угрожающих жизни симптомах звоните 103/112.
          </p>
        </div>

        {/* Состояние по данным */}
        {s && s.totalBiomarkers > 0 && (
          <Card>
            <CardContent className="p-4 flex items-start gap-3">
              <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                <Activity className="h-5 w-5 text-primary" />
              </div>
              <div className="text-sm">
                <div className="font-medium">Ваше состояние по загруженным данным</div>
                <div className="text-muted-foreground mt-0.5">
                  Отслеживается {s.totalBiomarkers} показателей, отклонений — {s.abnormalCount}.
                  {s.abnormal.slice(0, 3).map((a) => ` ${a.name}: ${a.value} ${a.unit}.`).join("")}
                </div>
                <div className="text-xs text-muted-foreground mt-1">Эти данные ИИ-доктор учтёт в заключении.</div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Как это работает */}
        <div>
          <h2 className="text-lg font-bold mb-3">Как это работает</h2>
          <div className="grid gap-3 sm:grid-cols-2">
            {STEPS.map((st) => (
              <Card key={st.n}>
                <CardContent className="p-4 flex gap-3">
                  <div className="h-9 w-9 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold shrink-0">
                    {st.n}
                  </div>
                  <div>
                    <div className="font-medium text-sm">{st.title}</div>
                    <div className="text-xs text-muted-foreground mt-1">{st.text}</div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Начало консультации */}
        <Card className="border-primary/30">
          <CardContent className="p-4 space-y-3">
            <div className="font-semibold flex items-center gap-2">
              <BotMessageSquare className="h-5 w-5 text-primary" /> Начать консультацию
            </div>
            <div className="flex gap-2">
              <input
                className="flex-1 rounded-md border bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-primary/40"
                placeholder="Опишите, что беспокоит…"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && sendComplaint(input)}
              />
              <Button onClick={() => sendComplaint(input)} disabled={busy || !input.trim()}>
                Начать <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {SUGGESTIONS.map((sg) => (
                <button
                  key={sg}
                  onClick={() => sendComplaint(sg)}
                  className="text-xs rounded-full border px-2.5 py-1.5 text-muted-foreground hover:bg-primary/5 hover:text-primary transition-colors"
                >
                  {sg}
                </button>
              ))}
            </div>
            <p className="text-[11px] text-muted-foreground flex items-center gap-1.5">
              <ShieldCheck className="h-3.5 w-3.5 text-primary shrink-0" />
              Не является медицинской консультацией и не заменяет консультацию врача.
            </p>
          </CardContent>
        </Card>

        {/* FAQ */}
        <div>
          <h2 className="text-lg font-bold mb-3">Частые вопросы</h2>
          <Accordion type="single" collapsible className="w-full">
            {FAQ.map((f, i) => (
              <AccordionItem key={i} value={`f${i}`}>
                <AccordionTrigger className="text-left text-sm font-medium">{f.q}</AccordionTrigger>
                <AccordionContent className="text-sm text-muted-foreground">{f.a}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    );
  }

  // ── Чат ──
  return (
    <div className="flex flex-col h-[calc(100dvh-10.5rem)] md:h-[calc(100vh-3rem)]">
      <div className="mb-3 flex items-center gap-3">
        <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center shrink-0">
          <BotMessageSquare className="h-5 w-5 text-primary-foreground" />
        </div>
        <div className="flex-1 min-w-0">
          <h1 className="font-bold leading-tight">ИИ-доктор</h1>
          <p className="text-xs text-muted-foreground flex items-center gap-1">
            <ShieldCheck className="h-3 w-3 text-primary" /> Учитывает ваши анализы и документы
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={reset}>
          <RotateCcw className="h-4 w-4 mr-1" /> Завершить
        </Button>
      </div>

      <div className="flex-1 overflow-y-auto rounded-xl border bg-card p-4 space-y-4">
        {messages.map((m, i) => (
          <div key={i} className={"flex gap-3 " + (m.role === "user" ? "justify-end" : "")}>
            {m.role === "ai" && (
              <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center shrink-0 mt-0.5">
                <BotMessageSquare className="h-4 w-4 text-primary-foreground" />
              </div>
            )}
            <div className={"max-w-[88%] md:max-w-[80%] space-y-3 " + (m.role === "user" ? "" : "")}>
              <div
                className={
                  "rounded-2xl px-4 py-3 text-sm " +
                  (m.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted")
                }
              >
                {renderMd(m.text)}
              </div>
              {m.conclusion && <ConclusionCard c={m.conclusion} />}
            </div>
            {m.role === "user" && (
              <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center shrink-0 mt-0.5">
                <User className="h-4 w-4" />
              </div>
            )}
          </div>
        ))}
        {busy && (
          <div className="flex gap-3">
            <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center shrink-0">
              <BotMessageSquare className="h-4 w-4 text-primary-foreground animate-pulse" />
            </div>
            <div className="bg-muted rounded-2xl px-4 py-3 text-sm text-muted-foreground">ИИ-доктор печатает…</div>
          </div>
        )}
        {done && (
          <div className="flex justify-center">
            <div className="text-xs text-muted-foreground flex items-center gap-1.5 bg-muted rounded-full px-3 py-1.5">
              <CheckCircle2 className="h-3.5 w-3.5 text-primary" /> Консультация завершена
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      <div className="mt-3 flex gap-2">
        <input
          className="flex-1 rounded-xl border bg-card px-4 py-2.5 text-sm outline-none focus:ring-2 focus:ring-primary/40 disabled:opacity-50"
          placeholder={done ? "Консультация завершена" : "Сообщение…"}
          value={input}
          disabled={busy || done}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && sendReply()}
        />
        <Button size="icon" className="rounded-xl h-10 w-10" disabled={busy || done || !input.trim()} onClick={sendReply}>
          <Send className="h-4 w-4" />
        </Button>
      </div>
      <p className="text-[11px] text-muted-foreground text-center mt-2 flex items-center justify-center gap-1">
        <ShieldCheck className="h-3 w-3 text-primary" />
        Не является диагнозом. При срочном состоянии звоните 103/112.
      </p>
    </div>
  );
}
