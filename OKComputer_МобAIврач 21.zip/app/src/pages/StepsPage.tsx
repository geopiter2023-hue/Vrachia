import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Cell, ReferenceLine } from "recharts";
import { Footprints, Flame, Plus, Target, TrendingUp, BotMessageSquare } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

const PERIODS = [
  { key: "7d", label: "7 дн" },
  { key: "30d", label: "30 дней" },
  { key: "6m", label: "6 мес." },
  { key: "1y", label: "1 год" },
] as const;

function fmt(n: number): string {
  return n.toLocaleString("ru-RU");
}

export default function StepsPage() {
  const utils = trpc.useUtils();
  const [period, setPeriod] = useState<(typeof PERIODS)[number]["key"]>("7d");
  const [addOpen, setAddOpen] = useState(false);
  const [stepsInput, setStepsInput] = useState("");
  const [dateInput, setDateInput] = useState("");

  const { data: today } = trpc.steps.today.useQuery(undefined, { refetchInterval: 30000 });
  const { data: stats } = trpc.steps.stats.useQuery({ period });
  const addMut = trpc.steps.add.useMutation({
    onSuccess: async () => {
      toast.success("Шаги записаны 👟");
      setAddOpen(false);
      setStepsInput("");
      await Promise.all([utils.steps.today.invalidate(), utils.steps.stats.invalidate()]);
    },
  });

  const steps = today?.steps ?? 0;
  const goal = today?.goal ?? 10000;
  const pct = Math.min(100, Math.round((steps / goal) * 100));
  const goalDone = steps >= goal;

  // Кольцо прогресса
  const R = 120;
  const C = 2 * Math.PI * R;

  const levelLabel =
    steps >= 12500 ? "Очень высокая активность" :
    steps >= 10000 ? "Высокая активность" :
    steps >= 7500 ? "Хорошая активность" :
    steps >= 5000 ? "Умеренная активность" :
    steps > 0 ? "Низкая активность — добавьте прогулку" : "Данных за сегодня пока нет";

  const submit = () => {
    const n = parseInt(stepsInput.replace(/\D/g, ""));
    if (!n || n <= 0) { toast.error("Введите количество шагов"); return; }
    addMut.mutate({ steps: n, date: dateInput || undefined });
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Footprints className="h-6 w-6 text-primary" /> Шагомер
        </h1>
        <p className="text-sm text-muted-foreground">Активность по дням, цель {fmt(goal)} шагов. Вносите вручную или через Telegram-бота («шаги 8500»).</p>
      </div>

      {/* ── Сегодня: кольцо + производные ── */}
      <div className="rounded-2xl border bg-card p-6 shadow-sm">
        <div className="grid grid-cols-3 gap-2 text-center mb-4">
          <div>
            <div className="text-xs text-muted-foreground">Калории</div>
            <div className="text-2xl font-bold text-orange-500">{fmt(today?.kcal ?? 0)}</div>
          </div>
          <div>
            <div className="text-xs text-muted-foreground">Активное время</div>
            <div className="text-2xl font-bold text-lime-600">
              {Math.floor((today?.activeMin ?? 0) / 60) > 0 && `${Math.floor((today?.activeMin ?? 0) / 60)}ч `}
              {(today?.activeMin ?? 0) % 60}м
            </div>
          </div>
          <div>
            <div className="text-xs text-muted-foreground">Км</div>
            <div className="text-2xl font-bold text-sky-500">{String(today?.km ?? 0).replace(".", ",")}</div>
          </div>
        </div>

        <div className="relative mx-auto w-fit">
          <svg width={280} height={280} viewBox="0 0 280 280">
            <circle cx={140} cy={140} r={R} fill="none" strokeWidth={14} className="stroke-muted" strokeLinecap="round" />
            <circle
              cx={140} cy={140} r={R} fill="none" strokeWidth={14} strokeLinecap="round"
              stroke={goalDone ? "#0d9488" : "#0ea5e9"}
              strokeDasharray={C}
              strokeDashoffset={C - (C * pct) / 100}
              transform="rotate(-90 140 140)"
              style={{ transition: "stroke-dashoffset 0.6s ease" }}
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <div className="text-xs text-muted-foreground">Сегодня</div>
            <div className="text-5xl font-bold tracking-tight text-sky-600">{fmt(steps)}</div>
            {goalDone ? (
              <div className="mt-1 flex items-center gap-1 text-sm font-medium text-teal-600">
                <Target className="h-4 w-4" /> Цель достигнута!
              </div>
            ) : (
              <div className="mt-1 text-sm text-muted-foreground">до цели {fmt(goal - steps)}</div>
            )}
            <div className="mt-1 text-xs text-muted-foreground">{levelLabel}</div>
          </div>
        </div>

        <Button className="w-full mt-4 h-11" onClick={() => setAddOpen(true)}>
          <Plus className="h-4 w-4" /> Добавить шаги
        </Button>
      </div>

      {/* ── Статистика ── */}
      <div className="rounded-2xl border bg-card p-5 shadow-sm space-y-4">
        <div className="flex rounded-xl border overflow-hidden">
          {PERIODS.map((p) => (
            <button
              key={p.key}
              onClick={() => setPeriod(p.key)}
              className={cn(
                "flex-1 py-2 text-sm font-medium transition-colors",
                period === p.key ? "bg-sky-500 text-white" : "text-sky-600 hover:bg-sky-50 dark:hover:bg-sky-950/40"
              )}
            >
              {p.label}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-2 gap-4 text-center">
          <div>
            <div className="text-xs text-muted-foreground">В среднем{stats?.monthly ? " (в день за месяц)" : ""}</div>
            <div className="text-2xl font-bold text-sky-600">{fmt(stats?.avg ?? 0)}</div>
          </div>
          <div>
            <div className="text-xs text-muted-foreground">Всего за период</div>
            <div className="text-2xl font-bold text-sky-600">{fmt(stats?.total ?? 0)}</div>
          </div>
        </div>

        <div className="h-56">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={stats?.series ?? []} margin={{ top: 8, right: 4, left: -18, bottom: 0 }}>
              <XAxis dataKey="label" tick={{ fontSize: 10 }} interval={period === "30d" ? 4 : 0} tickLine={false} axisLine={false} />
              <YAxis tick={{ fontSize: 10 }} tickFormatter={(v: number) => (v >= 1000 ? `${Math.round(v / 1000)}k` : String(v))} tickLine={false} axisLine={false} />
              {!stats?.monthly && <ReferenceLine y={goal} stroke="#0d9488" strokeDasharray="4 4" />}
              <Bar dataKey="steps" radius={[4, 4, 0, 0]}>
                {(stats?.series ?? []).map((d, i) => (
                  <Cell key={i} fill={!stats?.monthly && d.steps >= goal ? "#14b8a6" : "#38bdf8"} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
        {(stats?.daysWithData ?? 0) === 0 && (
          <p className="text-center text-sm text-muted-foreground">
            Данных пока нет — добавьте шаги кнопкой выше или напишите боту «шаги 8500»
          </p>
        )}
      </div>

      {/* ── Подсказка про бота ── */}
      <div className="rounded-2xl border bg-teal-50 dark:bg-teal-950/30 border-teal-200 dark:border-teal-900 p-4 flex items-start gap-3">
        <BotMessageSquare className="h-5 w-5 text-teal-600 shrink-0 mt-0.5" />
        <div className="text-sm">
          <div className="font-medium">Быстрый ввод через Telegram</div>
          <p className="text-muted-foreground mt-0.5">
            Отправьте боту сообщение «шаги 8500» — и они появятся здесь автоматически.
            Посмотреть дневную норму шагов можно в настройках трекера вашего телефона (Apple Здоровье, Google Fit, Mi Fitness).
          </p>
        </div>
      </div>

      {/* ── Диалог добавления ── */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><TrendingUp className="h-5 w-5 text-primary" /> Добавить шаги</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <Input
              inputMode="numeric"
              placeholder="Например, 8500"
              value={stepsInput}
              onChange={(e) => setStepsInput(e.target.value)}
              className="h-12 text-lg"
              autoFocus
            />
            <div>
              <label className="text-xs text-muted-foreground">Дата (если не сегодня)</label>
              <Input type="date" value={dateInput} onChange={(e) => setDateInput(e.target.value)} max={new Date().toISOString().slice(0, 10)} />
            </div>
            <Button className="w-full h-11" onClick={submit} disabled={addMut.isPending}>
              <Flame className="h-4 w-4" /> Записать
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
