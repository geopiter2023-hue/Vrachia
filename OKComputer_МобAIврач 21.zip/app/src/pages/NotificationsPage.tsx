import { trpc } from "@/providers/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { fmtDateTime } from "@/lib/health-utils";
import { AlertTriangle, Info, OctagonAlert, CheckCheck } from "lucide-react";

const ICON = {
  info: <Info className="h-5 w-5 text-sky-500" />,
  warning: <AlertTriangle className="h-5 w-5 text-orange-500" />,
  critical: <OctagonAlert className="h-5 w-5 text-red-500" />,
};

export default function NotificationsPage() {
  const utils = trpc.useUtils();
  const { data, isLoading } = trpc.health.notifications.list.useQuery();
  const markRead = trpc.health.notifications.markRead.useMutation({
    onSuccess: () => utils.health.notifications.list.invalidate(),
  });
  const markAll = trpc.health.notifications.markAllRead.useMutation({
    onSuccess: () => utils.health.notifications.list.invalidate(),
  });

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl md:text-2xl font-bold">Уведомления</h1>
          <p className="text-muted-foreground text-sm mt-1">
            Напоминания о контроле анализов и предупреждения о критических изменениях
          </p>
        </div>
        <Button variant="outline" onClick={() => markAll.mutate()}>
          <CheckCheck className="h-4 w-4 mr-1.5" /> Прочитать все
        </Button>
      </div>

      {isLoading ? (
        <div className="space-y-3">{[0, 1, 2].map((i) => <Skeleton key={i} className="h-20" />)}</div>
      ) : (
        <div className="space-y-2.5">
          {(data ?? []).map((n) => (
            <Card
              key={Number(n.id)}
              className={n.isRead ? "opacity-60" : n.severity === "critical" ? "border-red-300 dark:border-red-900" : ""}
            >
              <CardContent className="py-4 flex items-start gap-3.5">
                <div className="mt-0.5 shrink-0">{ICON[n.severity as keyof typeof ICON]}</div>
                <div className="flex-1">
                  <div className="font-medium">{n.title}</div>
                  <div className="text-sm text-muted-foreground mt-0.5">{n.body}</div>
                  <div className="text-xs text-muted-foreground mt-1.5">{fmtDateTime(n.createdAt)}</div>
                </div>
                {!n.isRead && (
                  <Button variant="ghost" size="sm" onClick={() => markRead.mutate({ id: Number(n.id) })}>
                    Прочитано
                  </Button>
                )}
              </CardContent>
            </Card>
          ))}
          {(data ?? []).length === 0 && (
            <div className="text-center text-muted-foreground py-16">Уведомлений нет</div>
          )}
        </div>
      )}
    </div>
  );
}
