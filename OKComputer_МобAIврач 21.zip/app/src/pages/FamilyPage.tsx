import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  STATUS_LABEL,
  STATUS_CLASS,
  STATUS_DOT,
  fmtDate,
  type Status,
} from "@/lib/health-utils";
import {
  Users,
  Plus,
  Trash2,
  FileText,
  BotMessageSquare,
  Activity,
  Send,
  ArrowLeft,
  Droplet,
} from "lucide-react";
import { toast } from "sonner";
import FamilyOverview from "@/components/FamilyOverview";

const RELATIONS: Record<string, string> = {
  mother: "Мама",
  father: "Папа",
  spouse: "Супруг(а)",
  son: "Сын",
  daughter: "Дочь",
  grandmother: "Бабушка",
  grandfather: "Дедушка",
  sibling: "Брат/сестра",
  other: "Родственник",
};

const FAM_DOC_TYPES: Record<string, string> = {
  analysis: "Анализ",
  conclusion: "Заключение",
  discharge: "Выписка",
  instrumental: "Исследование",
  vaccine: "Прививка",
  other: "Прочее",
};

function age(birth?: string | null) {
  if (!birth) return null;
  const years = Math.floor((Date.now() - new Date(birth).getTime()) / (365.25 * 864e5));
  return `${years} ${years % 10 === 1 && years % 100 !== 11 ? "год" : years % 10 >= 2 && years % 10 <= 4 && (years % 100 < 10 || years % 100 >= 20) ? "года" : "лет"}`;
}

type Msg = { role: "user" | "ai"; text: string };

export default function FamilyPage() {
  const utils = trpc.useUtils();
  const { data, isLoading } = trpc.family.list.useQuery();
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const detail = trpc.family.detail.useQuery({ id: selectedId! }, { enabled: selectedId !== null });

  const invalidate = () => {
    utils.family.list.invalidate();
    if (selectedId) utils.family.detail.invalidate({ id: selectedId });
  };

  // ── Форма нового члена семьи ──
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: "", relation: "mother", sex: "female", birthDate: "", bloodType: "", notes: "" });
  const createMut = trpc.family.create.useMutation({
    onSuccess: () => {
      toast.success("Член семьи добавлен");
      invalidate();
      setOpen(false);
      setForm({ name: "", relation: "mother", sex: "female", birthDate: "", bloodType: "", notes: "" });
    },
  });
  const delMut = trpc.family.remove.useMutation({
    onSuccess: () => {
      toast.success("Удалено");
      setSelectedId(null);
      invalidate();
    },
  });

  // ── Форма документа ──
  const [docOpen, setDocOpen] = useState(false);
  const [docForm, setDocForm] = useState({ title: "", docType: "analysis", docDate: new Date().toISOString().slice(0, 10), source: "", content: "" });
  const docMut = trpc.family.addDocument.useMutation({
    onSuccess: (res) => {
      if (res.extracted.length)
        toast.success(`Документ сохранён. Извлечено показателей: ${res.extracted.length} — ${res.extracted.map((e) => `${e.name} ${e.value}`).join(", ")}`, { duration: 8000 });
      else toast.success("Документ сохранён");
      invalidate();
      setDocOpen(false);
      setDocForm({ title: "", docType: "analysis", docDate: new Date().toISOString().slice(0, 10), source: "", content: "" });
    },
  });
  const delDocMut = trpc.family.removeDocument.useMutation({ onSuccess: invalidate });

  // ── AI-чат по члену семьи ──
  const [chat, setChat] = useState<Msg[]>([]);
  const [q, setQ] = useState("");
  const askMut = trpc.family.ask.useMutation({
    onSuccess: (res) => setChat((m) => [...m, { role: "ai", text: res.answer }]),
  });
  const ask = (question: string) => {
    if (!question.trim() || !selectedId || askMut.isPending) return;
    setChat((m) => [...m, { role: "user", text: question }]);
    setQ("");
    askMut.mutate({ memberId: selectedId, question });
  };

  // ════════ Детальный вид члена семьи ════════
  if (selectedId !== null) {
    const d = detail.data;
    if (detail.isLoading || !d) return <Skeleton className="h-96" />;
    const m = d.member;
    return (
      <div className="space-y-5">
        <div className="flex items-center gap-3 flex-wrap">
          <Button variant="ghost" size="sm" onClick={() => { setSelectedId(null); setChat([]); }}>
            <ArrowLeft className="h-4 w-4 mr-1" /> К семье
          </Button>
          <div className="flex-1" />
          <Button
            variant="ghost" size="sm" className="text-destructive"
            onClick={() => confirm(`Удалить «${m.name}» со всеми данными?`) && delMut.mutate({ id: selectedId })}
          >
            <Trash2 className="h-4 w-4 mr-1" /> Удалить
          </Button>
        </div>

        <Card>
          <CardContent className="pt-5 flex items-start gap-4">
            <div className="h-14 w-14 rounded-2xl bg-primary/10 flex items-center justify-center shrink-0 text-2xl font-bold text-primary">
              {m.name[0]}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-xl font-bold flex items-center gap-2 flex-wrap">
                {m.name}
                <Badge variant="secondary">{RELATIONS[m.relation] ?? m.relation}</Badge>
              </div>
              <div className="text-sm text-muted-foreground mt-1 flex flex-wrap gap-x-3">
                {age(m.birthDate) && <span>{age(m.birthDate)}</span>}
                {m.bloodType && (
                  <span className="flex items-center gap-1">
                    <Droplet className="h-3.5 w-3.5 text-red-500" /> {m.bloodType}
                  </span>
                )}
              </div>
              {m.notes && <p className="text-sm text-muted-foreground mt-2">{m.notes}</p>}
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="biomarkers">
          <TabsList className="w-full sm:w-auto">
            <TabsTrigger value="biomarkers" className="flex-1 sm:flex-none">
              <Activity className="h-4 w-4 mr-1.5" /> Показатели
            </TabsTrigger>
            <TabsTrigger value="docs" className="flex-1 sm:flex-none">
              <FileText className="h-4 w-4 mr-1.5" /> Документы ({d.documents.length})
            </TabsTrigger>
            <TabsTrigger value="ai" className="flex-1 sm:flex-none">
              <BotMessageSquare className="h-4 w-4 mr-1.5" /> AI
            </TabsTrigger>
          </TabsList>

          <TabsContent value="biomarkers" className="mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {d.biomarkers.filter((b) => b.latest).map((b) => (
                <div key={b.biomarker.code} className="rounded-xl border bg-card px-4 py-3.5">
                  <div className="flex items-center gap-3">
                    <span className="h-2.5 w-2.5 rounded-full shrink-0" style={{ background: STATUS_DOT[b.status as Status] }} />
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium truncate">{b.biomarker.name}</div>
                      <div className="text-xs text-muted-foreground">норма {b.biomarker.refLow}–{b.biomarker.refHigh} {b.biomarker.unit}</div>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="font-semibold">{b.latest!.value} <span className="text-xs font-normal text-muted-foreground">{b.biomarker.unit}</span></div>
                      <div className="text-xs text-muted-foreground">{fmtDate(b.latest!.date)}</div>
                    </div>
                    <Badge className={STATUS_CLASS[b.status as Status]} variant="secondary">{STATUS_LABEL[b.status as Status]}</Badge>
                  </div>
                </div>
              ))}
              {d.biomarkers.every((b) => !b.latest) && (
                <div className="md:col-span-2 text-center text-muted-foreground py-12 text-sm">
                  Показателей пока нет — загрузите анализ во вкладке «Документы», биомаркеры будут извлечены автоматически
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="docs" className="mt-4 space-y-3">
            <Dialog open={docOpen} onOpenChange={setDocOpen}>
              <DialogTrigger asChild>
                <Button className="w-full sm:w-auto"><Plus className="h-4 w-4 mr-1.5" /> Загрузить документ</Button>
              </DialogTrigger>
              <DialogContent className="max-h-[90vh] overflow-y-auto">
                <DialogHeader><DialogTitle>Документ для {m.name}</DialogTitle></DialogHeader>
                <div className="space-y-4 pt-2">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1.5">
                      <Label>Название</Label>
                      <Input value={docForm.title} onChange={(e) => setDocForm({ ...docForm, title: e.target.value })} />
                    </div>
                    <div className="space-y-1.5">
                      <Label>Тип</Label>
                      <Select value={docForm.docType} onValueChange={(v) => setDocForm({ ...docForm, docType: v })}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {Object.entries(FAM_DOC_TYPES).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-1.5">
                      <Label>Дата</Label>
                      <Input type="date" value={docForm.docDate} onChange={(e) => setDocForm({ ...docForm, docDate: e.target.value })} />
                    </div>
                    <div className="space-y-1.5">
                      <Label>Источник</Label>
                      <Input value={docForm.source} onChange={(e) => setDocForm({ ...docForm, source: e.target.value })} />
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <Label>Текст документа — биомаркеры извлекутся автоматически 🤖</Label>
                    <Textarea rows={5} placeholder="Например: Гемоглобин 132 г/л. Глюкоза 5.5..." value={docForm.content} onChange={(e) => setDocForm({ ...docForm, content: e.target.value })} />
                  </div>
                  <Button
                    className="w-full"
                    disabled={!docForm.title || docMut.isPending}
                    onClick={() => docMut.mutate({ memberId: selectedId, title: docForm.title, docType: docForm.docType as any, docDate: docForm.docDate, source: docForm.source || undefined, content: docForm.content || undefined })}
                  >
                    Сохранить и распознать
                  </Button>
                </div>
              </DialogContent>
            </Dialog>

            {d.documents.map((doc) => (
              <Card key={Number(doc.id)}>
                <CardContent className="py-4 flex items-start gap-3.5">
                  <div className="h-9 w-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                    <FileText className="h-4.5 w-4.5 text-primary" size={18} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-medium text-sm">{doc.title}</span>
                      <Badge variant="outline" className="text-xs">{FAM_DOC_TYPES[doc.docType]}</Badge>
                    </div>
                    <div className="text-xs text-muted-foreground mt-0.5">
                      {fmtDate(String(doc.docDate))}{doc.source ? ` · ${doc.source}` : ""}
                    </div>
                    {doc.content && <p className="text-sm text-muted-foreground mt-1.5 line-clamp-2">{doc.content}</p>}
                  </div>
                  <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-destructive shrink-0"
                    onClick={() => confirm("Удалить документ?") && delDocMut.mutate({ id: Number(doc.id) })}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="ai" className="mt-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <BotMessageSquare className="h-4.5 w-4.5 text-primary" size={18} />
                  AI-анализ данных: {m.name}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="min-h-32 max-h-96 overflow-y-auto space-y-3">
                  {chat.length === 0 && (
                    <div className="text-sm text-muted-foreground space-y-2">
                      <p>Спросите о состоянии {m.name}:</p>
                      <div className="flex flex-wrap gap-1.5">
                        {["Что означают показатели?", "Есть ли ухудшение?", "Какая динамика?"].map((s) => (
                          <button key={s} onClick={() => ask(s)} className="text-xs rounded-full border px-3 py-1.5 hover:bg-accent">
                            {s}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                  {chat.map((msg, i) => (
                    <div key={i} className={"text-sm rounded-2xl px-4 py-3 whitespace-pre-line " + (msg.role === "user" ? "bg-primary text-primary-foreground ml-8" : "bg-muted mr-4")}>
                      {msg.text.replace(/\*\*/g, "")}
                    </div>
                  ))}
                  {askMut.isPending && <div className="text-sm text-muted-foreground">Анализирую данные…</div>}
                </div>
                <div className="flex gap-2">
                  <Input placeholder="Вопрос о показателях…" value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === "Enter" && ask(q)} />
                  <Button onClick={() => ask(q)} disabled={askMut.isPending || !q.trim()}>
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    );
  }

  // ════════ Список семьи ════════
  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-xl md:text-2xl font-bold flex items-center gap-2">
            <Users className="h-6 w-6 text-primary" /> Семья
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            Здоровье близких под рукой: документы, анализы и AI-анализ по каждому
          </p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button><Plus className="h-4 w-4 mr-1.5" /> Добавить</Button>
          </DialogTrigger>
          <DialogContent className="max-h-[90vh] overflow-y-auto">
            <DialogHeader><DialogTitle>Новый член семьи</DialogTitle></DialogHeader>
            <div className="space-y-4 pt-2">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label>Имя</Label>
                  <Input placeholder="Галина Петровна" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
                </div>
                <div className="space-y-1.5">
                  <Label>Кем приходится</Label>
                  <Select value={form.relation} onValueChange={(v) => setForm({ ...form, relation: v, sex: ["mother", "daughter", "grandmother"].includes(v) ? "female" : "male" })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {Object.entries(RELATIONS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label>Дата рождения</Label>
                  <Input type="date" value={form.birthDate} onChange={(e) => setForm({ ...form, birthDate: e.target.value })} />
                </div>
                <div className="space-y-1.5">
                  <Label>Группа крови</Label>
                  <Input placeholder="A(II) Rh+" value={form.bloodType} onChange={(e) => setForm({ ...form, bloodType: e.target.value })} />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label>Заметки: хронические заболевания, лекарства, аллергии</Label>
                <Textarea rows={3} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
              </div>
              <Button
                className="w-full"
                disabled={!form.name || createMut.isPending}
                onClick={() => createMut.mutate({ name: form.name, relation: form.relation, sex: form.sex as any, birthDate: form.birthDate || undefined, bloodType: form.bloodType || undefined, notes: form.notes || undefined })}
              >
                Сохранить
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Попечительский режим: сводка статусов близких */}
      <FamilyOverview onSelect={(id) => setSelectedId(id)} />

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">{[0, 1, 2].map((i) => <Skeleton key={i} className="h-48" />)}</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {(data ?? []).map((m) => (
            <button key={Number(m.id)} onClick={() => setSelectedId(Number(m.id))} className="text-left">
              <Card className="h-full transition-all hover:shadow-md hover:border-primary/40">
                <CardContent className="pt-5 space-y-3">
                  <div className="flex items-center gap-3.5">
                    <div className="h-12 w-12 rounded-2xl bg-primary/10 flex items-center justify-center shrink-0 text-xl font-bold text-primary">
                      {m.name[0]}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold flex items-center gap-2 flex-wrap">
                        {m.name}
                        <Badge variant="secondary">{RELATIONS[m.relation] ?? m.relation}</Badge>
                      </div>
                      <div className="text-xs text-muted-foreground mt-0.5 flex flex-wrap gap-x-2.5">
                        {age(m.birthDate) && <span>{age(m.birthDate)}</span>}
                        {m.bloodType && <span className="flex items-center gap-1"><Droplet className="h-3 w-3 text-red-500" />{m.bloodType}</span>}
                      </div>
                    </div>
                  </div>
                  {m.notes && <p className="text-xs text-muted-foreground line-clamp-2">{m.notes}</p>}
                  <div className="flex items-center gap-2 text-xs text-muted-foreground flex-wrap">
                    <Badge variant="outline">{m.stats.biomarkers} показателей</Badge>
                    <Badge variant="outline">{m.stats.documents} документов</Badge>
                    {m.stats.abnormal > 0 && (
                      <Badge className="bg-orange-100 text-orange-800 dark:bg-orange-950 dark:text-orange-300" variant="secondary">
                        {m.stats.abnormal} отклонений
                      </Badge>
                    )}
                  </div>
                  {m.top.filter((t) => t.status !== "normal").slice(0, 2).map((t) => (
                    <div key={t.code} className="flex items-center gap-2 text-sm rounded-lg bg-muted px-3 py-2">
                      <span className="h-2 w-2 rounded-full shrink-0" style={{ background: STATUS_DOT[t.status as Status] }} />
                      <span className="flex-1 truncate">{t.name}</span>
                      <b>{t.latest?.value}</b> <span className="text-xs text-muted-foreground">{t.unit}</span>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </button>
          ))}
          {(data ?? []).length === 0 && (
            <div className="md:col-span-2 text-center text-muted-foreground py-16">
              Добавьте членов семьи, чтобы держать их медицинские данные под рукой
            </div>
          )}
        </div>
      )}
    </div>
  );
}
