import { trpc } from "@/providers/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { fmtDateTime } from "@/lib/health-utils";
import { ScrollText } from "lucide-react";

const ACTION_LABEL: Record<string, string> = {
  upload: "Загрузка документа",
  delete: "Удаление",
  measurement: "Измерение",
  vital: "Физиология",
  ai_query: "AI-запрос",
  export: "Экспорт",
  init: "Инициализация",
  sync: "Синхронизация",
};

export default function AuditPage() {
  const { data, isLoading } = trpc.health.audit.list.useQuery();

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl md:text-2xl font-bold">Журнал действий</h1>
        <p className="text-muted-foreground text-sm mt-1">
          Фиксация всех операций с данными и истории AI-запросов (Audit Log)
        </p>
      </div>

      {isLoading ? (
        <div className="space-y-2">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-14" />)}</div>
      ) : (
        <Card>
          <CardContent className="py-3 divide-y">
            {(data ?? []).map((e) => (
              <div key={Number(e.id)} className="py-3 flex items-center gap-3">
                <ScrollText className="h-4 w-4 text-muted-foreground shrink-0" />
                <Badge variant="outline" className="shrink-0">
                  {ACTION_LABEL[e.action] ?? e.action}
                </Badge>
                <span className="text-sm flex-1 min-w-0 truncate">{e.detail}</span>
                <span className="text-xs text-muted-foreground shrink-0">{fmtDateTime(e.createdAt)}</span>
              </div>
            ))}
            {(data ?? []).length === 0 && (
              <div className="py-10 text-center text-muted-foreground text-sm">Журнал пуст</div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
