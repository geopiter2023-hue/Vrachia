import { trpc } from "@/providers/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { fmtDateTime } from "@/lib/health-utils";
import { Newspaper, RefreshCw, ExternalLink, Landmark } from "lucide-react";
import { toast } from "sonner";

export default function NewsPage() {
  const utils = trpc.useUtils();
  const { data, isLoading, isFetching } = trpc.news.list.useQuery(undefined, {
    refetchInterval: 30 * 60 * 1000, // автообновление каждые 30 минут
  });
  const refreshMut = trpc.news.refresh.useMutation({
    onSuccess: () => {
      toast.success("Лента новостей обновлена");
      utils.news.list.invalidate();
    },
    onError: () => toast.error("Источники новостей временно недоступны — показан кэш"),
  });

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-xl md:text-2xl font-bold flex items-center gap-2">
            <Landmark className="h-6 w-6 text-primary" /> Новости здравоохранения
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            {data?.source ? (
              <>
                Источник: <b className="text-foreground">{data.source}</b>
                {data.updatedAt && <> · обновлено {fmtDateTime(data.updatedAt)}</>}
              </>
            ) : (
              "Официальные новости Минздрава России"
            )}
            {" · автообновление каждые 30 минут"}
          </p>
        </div>
        <Button variant="outline" onClick={() => refreshMut.mutate()} disabled={refreshMut.isPending || isFetching}>
          <RefreshCw className={"h-4 w-4 mr-1.5 " + (refreshMut.isPending || isFetching ? "animate-spin" : "")} />
          Обновить
        </Button>
      </div>

      {isLoading ? (
        <div className="space-y-3">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-24" />)}</div>
      ) : (data?.items ?? []).length === 0 ? (
        <Card>
          <CardContent className="py-16 text-center text-muted-foreground">
            <Newspaper className="h-10 w-10 mx-auto mb-3 opacity-40" />
            Лента пока пуста. Нажмите «Обновить», чтобы загрузить новости.
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-2.5">
          {data!.items.map((n) => (
            <a key={Number(n.id)} href={n.link} target="_blank" rel="noopener noreferrer" className="block group">
              <Card className="transition-all group-hover:shadow-md group-hover:border-primary/40">
                <CardContent className="py-4 flex items-start gap-4">
                  <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                    <Newspaper className="h-5 w-5 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium leading-snug group-hover:text-primary transition-colors">
                      {n.title}
                    </div>
                    {n.summary && (
                      <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{n.summary}</p>
                    )}
                    <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
                      <Badge variant="secondary" className="text-xs">{n.source}</Badge>
                      {n.publishedAt && <span>{new Date(n.publishedAt).toLocaleString("ru-RU", { day: "numeric", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit" })}</span>}
                    </div>
                  </div>
                  <ExternalLink className="h-4 w-4 text-muted-foreground shrink-0 mt-1 opacity-0 group-hover:opacity-100 transition-opacity" />
                </CardContent>
              </Card>
            </a>
          ))}
        </div>
      )}
    </div>
  );
}
