import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { ShieldCheck, ScrollText, Trash2, ArrowLeft } from "lucide-react";
import { Link } from "react-router";
import { trpc } from "@/providers/trpc";
import { toast } from "sonner";

function LegalShell({ title, icon: Icon, children }: { title: string; icon: any; children: React.ReactNode }) {
  return (
    <div className="space-y-4 max-w-3xl">
      <Link to="/" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> На главную
      </Link>
      <h1 className="text-xl md:text-2xl font-bold flex items-center gap-2">
        <Icon className="h-6 w-6 text-primary" /> {title}
      </h1>
      <Card>
        <CardContent className="prose prose-sm dark:prose-invert max-w-none py-5 space-y-4 text-sm leading-relaxed">
          {children}
        </CardContent>
      </Card>
    </div>
  );
}

const H = ({ children }: { children: React.ReactNode }) => (
  <h3 className="font-semibold text-base pt-2">{children}</h3>
);

export function PrivacyPage() {
  return (
    <LegalShell title="Политика конфиденциальности" icon={ShieldCheck}>
      <p className="text-muted-foreground">Редакция от 01.08.2026 · Версия 1.0</p>
      <p>
        Настоящая Политика описывает, как сервис «AI Врач» (далее — Сервис) обрабатывает персональные
        данные пользователей в соответствии с Федеральным законом № 152-ФЗ «О персональных данных» и
        Федеральным законом № 323-ФЗ «Об основах охраны здоровья граждан в Российской Федерации».
      </p>
      <H>1. Какие данные обрабатываются</H>
      <p>
        1.1. Данные, которые вы загружаете добровольно: медицинские документы (PDF), результаты анализов,
        показатели артериального давления, масса тела, сведения о принимаемых лекарствах, записи о самочувствии.
      </p>
      <p>
        1.2. Указанные сведения относятся к специальной категории персональных данных (сведения о здоровье,
        ст. 10 ФЗ-152) и могут составлять врачебную тайну (ст. 13 ФЗ-323). Они обрабатываются только с вашего
        отдельного согласия и только для отображения вашей медицинской истории вам лично.
      </p>
      <p>1.3. Технические данные: журнал действий в Сервисе, идентификатор чата Telegram при подключении бота.</p>
      <H>2. Цели обработки</H>
      <p>
        Хранение и визуализация вашей медицинской истории; построение динамики показателей; формирование
        информационных (не медицинских) сводок и напоминаний; работа Telegram-бота по вашему запросу.
      </p>
      <H>3. Правовые основания</H>
      <p>Ваше согласие (ст. 6, 9, 10 ФЗ-152), данное при первом запуске Сервиса. Согласие может быть отозвано в любой момент — см. раздел 6.</p>
      <H>4. Хранение и передача</H>
      <p>
        4.1. Данные хранятся в защищённой базе данных. Вы уведомлены, что инфраструктура Сервиса может
        располагаться на серверах за пределами РФ (трансграничная передача, ст. 12 ФЗ-152) — соответствующее
        согласие запрашивается при первом запуске.
      </p>
      <p>
        4.2. При подключении Telegram-бота введённые вами сообщения (например, значения давления) передаются
        через инфраструктуру Telegram.
      </p>
      <p>4.3. Данные не продаются и не передаются третьим лицам в маркетинговых целях.</p>
      <H>5. Безопасность</H>
      <p>
        Применяются организационные и технические меры защиты: доступ по защищённому соединению (HTTPS),
        разграничение доступа к базе данных, журналирование действий.
      </p>
      <H>6. Ваши права (ст. 14 ФЗ-152)</H>
      <p>
        Вы вправе запросить уточнение, блокирование или удаление своих данных. Функция «Удалить все мои данные»
        доступна в разделе «Пользовательское соглашение» и выполняет полное безвозвратное удаление ваших записей.
        Отзыв согласия равносилен удалению данных.
      </p>
      <H>7. Контакты оператора</H>
      <p>По вопросам обработки персональных данных обращайтесь через раздел «ИИ-доктор» с пометкой «Вопрос по данным».</p>
    </LegalShell>
  );
}

export function TermsPage() {
  const delMut = trpc.health.deleteAllData.useMutation({
    onSuccess: () => {
      toast.success("Все данные удалены");
      try { localStorage.clear(); } catch { /* ignore */ }
      setTimeout(() => window.location.reload(), 800);
    },
    onError: () => toast.error("Не удалось удалить данные"),
  });
  const [confirmText, setConfirmText] = useState("");

  return (
    <LegalShell title="Пользовательское соглашение" icon={ScrollText}>
      <p className="text-muted-foreground">Редакция от 01.08.2026 · Версия 1.0</p>
      <H>1. Статус сервиса</H>
      <p>
        1.1. «AI Врач» — <b>информационный сервис</b> для хранения и визуализации личных медицинских данных.
        Сервис <b>не является медицинской организацией</b>, не оказывает медицинские услуги, не ставит диагнозы
        и не назначает лечение (ст. 84 ФЗ-323).
      </p>
      <p>
        1.2. Все материалы — статьи о показателях, сводки, «ИИ-доктор», индекс здоровья — носят исключительно
        ознакомительный характер и <b>не заменяют консультацию врача</b>. Имеются противопоказания.
        Необходима консультация специалиста.
      </p>
      <p>
        1.3. Не откладывайте обращение за медицинской помощью и не изменяйте назначенное врачом лечение
        на основании информации из Сервиса. При угрозе жизни звоните 103/112.
      </p>
      <H>2. Условия использования</H>
      <p>2.1. Сервис предназначен для лиц старше 18 лет.</p>
      <p>
        2.2. Вы загружаете только свои данные либо данные лиц, законным представителем которых являетесь
        (например, несовершеннолетних детей). Добавляя данные члена семьи, вы подтверждаете наличие его согласия.
      </p>
      <p>2.3. Вы отвечаете за достоверность загружаемых документов.</p>
      <H>3. Данные сторонних источников</H>
      <p>
        Справочник медучреждений составлен по открытым данным © OpenStreetMap contributors (лицензия ODbL)
        и носит справочный характер: актуальность телефонов, адресов и наличие лицензий у учреждений
        проверяйте самостоятельно. Информация о медицинских услугах не является рекламой.
      </p>
      <H>4. Ограничение ответственности</H>
      <p>
        Сервис предоставляется «как есть». Оператор не несёт ответственности за решения, принятые на основании
        информационных материалов Сервиса, а также за временную недоступность сервиса.
      </p>
      <H>5. Удаление данных и отзыв согласия</H>
      <p>
        Вы можете в любой момент полностью удалить все свои данные из Сервиса (ст. 14 ФЗ-152).
        Действие необратимо: будут удалены документы, измерения, дневники, лекарства, достижения и настройки.
      </p>

      <div className="rounded-xl border border-red-200 dark:border-red-900 bg-red-50 dark:bg-red-950/40 p-4 not-prose">
        <div className="font-semibold text-red-800 dark:text-red-300 flex items-center gap-2">
          <Trash2 className="h-4 w-4" /> Опасная зона
        </div>
        <p className="text-xs text-red-700 dark:text-red-400 mt-1">
          Полное и безвозвратное удаление всех ваших данных из сервиса.
        </p>
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button variant="destructive" size="sm" className="mt-3">Удалить все мои данные</Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Удалить все данные безвозвратно?</AlertDialogTitle>
              <AlertDialogDescription>
                Будут удалены все документы, измерения, дневники давления, лекарства, достижения и настройки.
                Восстановить данные будет невозможно. Для подтверждения введите слово УДАЛИТЬ.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <input
              className="w-full rounded-md border px-3 py-2 text-sm"
              placeholder="Введите УДАЛИТЬ"
              value={confirmText}
              onChange={(e) => setConfirmText(e.target.value)}
            />
            <AlertDialogFooter>
              <AlertDialogCancel onClick={() => setConfirmText("")}>Отмена</AlertDialogCancel>
              <AlertDialogAction
                disabled={confirmText !== "УДАЛИТЬ" || delMut.isPending}
                onClick={() => delMut.mutate()}
                className="bg-red-600 hover:bg-red-700"
              >
                {delMut.isPending ? "Удаляю…" : "Удалить навсегда"}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </LegalShell>
  );
}
