import { useRef, useState } from "react";
import { trpc } from "@/providers/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { BotMessageSquare, FileScan, ImageUp, Loader2, Save, TriangleAlert } from "lucide-react";
import { toast } from "sonner";
import { createWorker } from "tesseract.js";

// ─── Эвристический AI-анализ изображения (локально, canvas) ──────────────
type ImgStats = {
  width: number;
  height: number;
  brightness: number; // 0..255
  contrast: number; // std
  edgeDensity: number; // 0..1
  symmetry: number; // 0..1 (1 = полная симметрия)
  darkRatio: number; // доля тёмных пикселей
  brightRatio: number; // доля светлых пикселей
};

async function analyzeImage(img: HTMLImageElement): Promise<ImgStats> {
  const canvas = document.createElement("canvas");
  const maxSide = 400;
  const scale = Math.min(1, maxSide / Math.max(img.width, img.height));
  canvas.width = Math.round(img.width * scale);
  canvas.height = Math.round(img.height * scale);
  const ctx = canvas.getContext("2d")!;
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
  const { data } = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const n = canvas.width * canvas.height;
  const gray = new Float32Array(n);
  let sum = 0;
  for (let i = 0; i < n; i++) {
    const g = 0.299 * data[i * 4] + 0.587 * data[i * 4 + 1] + 0.114 * data[i * 4 + 2];
    gray[i] = g;
    sum += g;
  }
  const mean = sum / n;
  let varSum = 0, dark = 0, bright = 0;
  for (let i = 0; i < n; i++) {
    varSum += (gray[i] - mean) ** 2;
    if (gray[i] < 50) dark++;
    if (gray[i] > 205) bright++;
  }
  const contrast = Math.sqrt(varSum / n);
  // Плотность границ (упрощённый Sobel по X/Y)
  let edges = 0;
  const w = canvas.width, h = canvas.height;
  for (let y = 1; y < h - 1; y++) {
    for (let x = 1; x < w - 1; x++) {
      const gx = Math.abs(gray[y * w + x + 1] - gray[y * w + x - 1]);
      const gy = Math.abs(gray[(y + 1) * w + x] - gray[(y - 1) * w + x]);
      if (gx + gy > 60) edges++;
    }
  }
  // Симметрия лево/право
  let symSum = 0;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < Math.floor(w / 2); x++) {
      symSum += 1 - Math.abs(gray[y * w + x] - gray[y * w + (w - 1 - x)]) / 255;
    }
  }
  const symmetry = symSum / (h * Math.floor(w / 2));
  return {
    width: img.width,
    height: img.height,
    brightness: Math.round(mean),
    contrast: Math.round(contrast),
    edgeDensity: +(edges / n).toFixed(3),
    symmetry: +symmetry.toFixed(3),
    darkRatio: +(dark / n).toFixed(3),
    brightRatio: +(bright / n).toFixed(3),
  };
}

const IMG_TYPES: Record<string, { label: string; hints: (s: ImgStats) => string[] }> = {
  uzi: {
    label: "УЗИ",
    hints: (s) => [
      s.darkRatio > 0.35
        ? "Высокая доля анэхогенных (тёмных) зон — типично для структур с жидкостным содержимым; соотнесите с заключением специалиста."
        : "Доля анэхогенных зон умеренная.",
      s.edgeDensity > 0.08
        ? "Выраженная плотность границ — неоднородная эхоструктура тканей; врач обычно описывает это как «диффузные изменения» или «гетерогенность»."
        : "Эхоструктура по гистограмме относительно однородная.",
    ],
  },
  xray: {
    label: "Рентген / флюорография",
    hints: (s) => [
      s.contrast > 70
        ? "Высокий контраст снимка — плотные (костные) структуры и воздушные полости различимы чётко."
        : "Умеренный контраст — для оценки мягких тканей важно качество исходного снимка.",
      s.brightRatio > 0.3
        ? "Большая доля светлых участков — проверьте, не является ли это артефактом экспозиции."
        : "Экспозиция снимка выглядит сбалансированной.",
    ],
  },
  derma: {
    label: "Кожа / дерматоскопия",
    hints: (s) => [
      s.symmetry > 0.85
        ? "Высокая осевая симметрия изображения — при дерматоскопии симметрия образования обычно относят к благоприятным признакам (правило ABCD)."
        : "Выраженная асимметрия изображения — при оценке кожных образований асимметрия считается признаком, требующим осмотра дерматолога (правило ABCD).",
      "Цветовую неоднородность и границы образования может оценить только врач — запишитесь на дерматоскопию при любых сомнениях.",
    ],
  },
  other: {
    label: "Другое исследование",
    hints: () => ["Выполнен общий анализ характеристик изображения. Для интерпретации обратитесь к специалисту соответствующего профиля."],
  },
};

function qualityNotes(s: ImgStats): string[] {
  const q: string[] = [];
  if (s.brightness < 60) q.push("Изображение тёмное — при повторной съёмке добавьте освещение.");
  if (s.brightness > 200) q.push("Изображение пересвечено — часть деталей может быть потеряна.");
  if (s.contrast < 30) q.push("Низкий контраст — детали структур различимы слабо.");
  if (s.width < 600 || s.height < 600) q.push("Низкое разрешение — для анализа лучше использовать снимки от 800×800 пикселей.");
  if (!q.length) q.push("Техническое качество изображения достаточное для первичной оценки.");
  return q;
}

export default function ImagingPage() {
  const utils = trpc.useUtils();

  // ── OCR ──
  const [ocrImg, setOcrImg] = useState<string | null>(null);
  const [ocrFileName, setOcrFileName] = useState("");
  const [ocrText, setOcrText] = useState("");
  const [ocrProgress, setOcrProgress] = useState<number | null>(null);
  const [docTitle, setDocTitle] = useState("");
  const [docDate, setDocDate] = useState(new Date().toISOString().slice(0, 10));

  const createMut = trpc.health.documents.create.useMutation({
    onSuccess: (res) => {
      if (res.extracted.length) {
        toast.success(
          `Документ сохранён. AI извлёк показатели: ${res.extracted.map((e) => `${e.name} ${e.value}`).join(", ")}`,
          { duration: 9000 }
        );
      } else {
        toast.warning("Документ сохранён, но биомаркеры в тексте не найдены — проверьте распознавание.");
      }
      utils.health.documents.list.invalidate();
      utils.health.biomarkers.list.invalidate();
      utils.health.dashboard.invalidate();
      setOcrImg(null);
      setOcrText("");
      setDocTitle("");
    },
  });

  const runOcr = async () => {
    if (!ocrImg) return;
    setOcrProgress(0);
    try {
      const worker = await createWorker("rus", 1, {
        logger: (m: any) => {
          if (m.status === "recognizing text") setOcrProgress(Math.round(m.progress * 100));
        },
      });
      const { data } = await worker.recognize(ocrImg);
      await worker.terminate();
      setOcrText(data.text.trim());
      setOcrProgress(null);
      toast.success("Текст распознан — проверьте и сохраните");
    } catch {
      setOcrProgress(null);
      toast.error("Не удалось распознать изображение");
    }
  };

  // ── AI-анализ снимка ──
  const imgRef = useRef<HTMLImageElement>(null);
  const [scanImg, setScanImg] = useState<string | null>(null);
  const [scanType, setScanType] = useState("uzi");
  const [stats, setStats] = useState<ImgStats | null>(null);
  const [analyzing, setAnalyzing] = useState(false);

  const runAnalysis = async () => {
    if (!imgRef.current) return;
    setAnalyzing(true);
    // небольшая пауза для UX «модель думает»
    const s = await analyzeImage(imgRef.current);
    setTimeout(() => {
      setStats(s);
      setAnalyzing(false);
    }, 900);
  };

  const onFile = (f: File | undefined, setter: (v: string) => void, nameSetter?: (v: string) => void) => {
    if (!f) return;
    nameSetter?.(f.name);
    const reader = new FileReader();
    reader.onload = () => setter(String(reader.result));
    reader.readAsDataURL(f);
  };

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl md:text-2xl font-bold flex items-center gap-2">
          AI-анализ снимков <span>🤖</span>
        </h1>
        <p className="text-muted-foreground text-sm mt-1">
          Распознавание сканов анализов (OCR) с автоматическим извлечением показателей и AI-описание медицинских изображений — всё локально, без передачи данных
        </p>
      </div>

      <Tabs defaultValue="ocr">
        <TabsList className="w-full sm:w-auto">
          <TabsTrigger value="ocr" className="flex-1 sm:flex-none">
            <FileScan className="h-4 w-4 mr-1.5" /> Скан анализа (OCR)
          </TabsTrigger>
          <TabsTrigger value="scan" className="flex-1 sm:flex-none">
            <ImageUp className="h-4 w-4 mr-1.5" /> Медицинский снимок
          </TabsTrigger>
        </TabsList>

        {/* ─────────── OCR ─────────── */}
        <TabsContent value="ocr" className="space-y-4 mt-4">
          <Card>
            <CardContent className="pt-5 space-y-4">
              <label className="flex flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed px-4 py-8 cursor-pointer hover:bg-accent/50 transition-colors">
                <FileScan className="h-8 w-8 text-muted-foreground" />
                <span className="text-sm text-muted-foreground">
                  {ocrFileName || "Загрузите фото или скан бланка анализа (JPG, PNG)"}
                </span>
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    setOcrText("");
                    onFile(e.target.files?.[0], setOcrImg, setOcrFileName);
                  }}
                />
              </label>

              {ocrImg && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <img src={ocrImg} alt="scan" className="rounded-lg border max-h-80 object-contain w-full" />
                  <div className="space-y-3">
                    {ocrProgress !== null ? (
                      <div className="space-y-2 py-8">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Loader2 className="h-4 w-4 animate-spin" /> Распознаю текст (русский)… {ocrProgress}%
                        </div>
                        <Progress value={ocrProgress} />
                      </div>
                    ) : (
                      <Button onClick={runOcr} className="w-full">
                        <BotMessageSquare className="h-4 w-4 mr-1.5" /> Распознать текст
                      </Button>
                    )}
                  </div>
                </div>
              )}

              {ocrText && (
                <div className="space-y-3">
                  <div className="space-y-1.5">
                    <Label>Распознанный текст (можно исправить)</Label>
                    <Textarea rows={8} value={ocrText} onChange={(e) => setOcrText(e.target.value)} />
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1.5">
                      <Label>Название документа</Label>
                      <Input placeholder="Анализ крови" value={docTitle} onChange={(e) => setDocTitle(e.target.value)} />
                    </div>
                    <div className="space-y-1.5">
                      <Label>Дата анализа</Label>
                      <Input type="date" value={docDate} onChange={(e) => setDocDate(e.target.value)} />
                    </div>
                  </div>
                  <Button
                    className="w-full"
                    disabled={!docTitle || createMut.isPending}
                    onClick={() =>
                      createMut.mutate({
                        title: docTitle,
                        docType: "analysis",
                        docDate,
                        fileName: ocrFileName || undefined,
                        content: ocrText,
                        autoExtract: true,
                      })
                    }
                  >
                    <Save className="h-4 w-4 mr-1.5" />
                    {createMut.isPending ? "Сохранение…" : "Сохранить и извлечь показатели 🤖"}
                  </Button>
                  <p className="text-xs text-muted-foreground">
                    AI автоматически найдёт в тексте биомаркеры (гемоглобин, глюкозу, холестерин и др.), добавит их в вашу историю и включит в анализ динамики.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ─────────── AI-анализ снимка ─────────── */}
        <TabsContent value="scan" className="space-y-4 mt-4">
          <Card>
            <CardContent className="pt-5 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-end">
                <label className="flex flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed px-4 py-6 cursor-pointer hover:bg-accent/50 transition-colors">
                  <ImageUp className="h-7 w-7 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">УЗИ, рентген, дерматоскопия…</span>
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => {
                      setStats(null);
                      onFile(e.target.files?.[0], setScanImg);
                    }}
                  />
                </label>
                <div className="space-y-1.5">
                  <Label>Тип исследования</Label>
                  <Select value={scanType} onValueChange={setScanType}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {Object.entries(IMG_TYPES).map(([k, v]) => (
                        <SelectItem key={k} value={k}>{v.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {scanImg && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <img ref={imgRef} src={scanImg} alt="medical" className="rounded-lg border max-h-96 object-contain w-full" crossOrigin="anonymous" />
                  </div>
                  <div className="space-y-3">
                    <Button onClick={runAnalysis} disabled={analyzing} className="w-full">
                      {analyzing ? (
                        <><Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> AI анализирует…</>
                      ) : (
                        <><BotMessageSquare className="h-4 w-4 mr-1.5" /> Запустить AI-анализ 🤖</>
                      )}
                    </Button>

                    {stats && (
                      <div className="space-y-3">
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          {[
                            ["Разрешение", `${stats.width}×${stats.height}`],
                            ["Яркость", `${stats.brightness}/255`],
                            ["Контраст", String(stats.contrast)],
                            ["Плотность границ", `${(stats.edgeDensity * 100).toFixed(1)}%`],
                            ["Симметрия", `${(stats.symmetry * 100).toFixed(0)}%`],
                            ["Тёмные зоны", `${(stats.darkRatio * 100).toFixed(0)}%`],
                          ].map(([k, v]) => (
                            <div key={k} className="rounded-lg border px-3 py-2">
                              <div className="text-xs text-muted-foreground">{k}</div>
                              <div className="font-semibold">{v}</div>
                            </div>
                          ))}
                        </div>

                        <Card>
                          <CardHeader className="pb-2 pt-4">
                            <CardTitle className="text-sm flex items-center gap-2">
                              <Badge className="bg-primary text-primary-foreground">AI-заключение</Badge>
                              {IMG_TYPES[scanType].label}
                            </CardTitle>
                          </CardHeader>
                          <CardContent className="space-y-2 text-sm">
                            {qualityNotes(stats).map((t, i) => <p key={"q" + i}>• {t}</p>)}
                            {IMG_TYPES[scanType].hints(stats).map((t, i) => <p key={"h" + i}>• {t}</p>)}
                          </CardContent>
                        </Card>
                      </div>
                    )}
                  </div>
                </div>
              )}

              <div className="flex items-start gap-2 rounded-lg bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 px-3 py-2.5 text-xs text-amber-800 dark:text-amber-300">
                <TriangleAlert className="h-4 w-4 shrink-0 mt-0.5" />
                AI-анализ изображений носит предварительный характер, выполняется локально эвристической моделью и не заменяет заключение врача-рентгенолога. При отклонениях — очная консультация специалиста.
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
