import { trpc } from "@/providers/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Lock } from "lucide-react";
import { fmtDateTime } from "@/lib/health-utils";

export default function AchievementsPage() {
  const { data, isLoading } = trpc.wellness.achievements.useQuery();
  const today = trpc.wellness.today.useQuery();

  if (isLoading || !data) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-9 w-56" />
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-32" />)}
        </div>
      </div>
    );
  }

  const unlocked = data.filter((a) => a.unlocked);

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl md:text-2xl font-bold">Достижения</h1>
        <p className="text-muted-foreground text-sm mt-1">
          {unlocked.length} из {data.length} разблокировано
          {today.data && today.data.streak.current > 0 && (
            <> · текущая серия <b className="text-foreground">{today.data.streak.current} дн.</b> 🔥</>
          )}
        </p>
      </div>

      {/* Прогресс */}
      <div className="h-2.5 rounded-full bg-muted overflow-hidden">
        <div
          className="h-full rounded-full bg-gradient-to-r from-teal-500 to-emerald-500 transition-all duration-700"
          style={{ width: `${(unlocked.length / data.length) * 100}%` }}
        />
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {data.map((a) => (
          <Card
            key={a.code}
            className={
              a.unlocked
                ? "border-emerald-200 dark:border-emerald-900 bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-emerald-950/30 dark:to-teal-950/30"
                : "opacity-70"
            }
          >
            <CardContent className="p-4 flex flex-col items-center text-center gap-1.5">
              <div className={`text-3xl ${a.unlocked ? "" : "grayscale opacity-40"}`}>
                {a.unlocked ? a.icon : <Lock className="h-7 w-7 text-muted-foreground/40" />}
              </div>
              <div className="font-semibold text-sm">{a.title}</div>
              <div className="text-xs text-muted-foreground leading-snug">{a.text}</div>
              {a.unlocked && a.unlockedAt && (
                <div className="text-[10px] text-emerald-600 mt-1">{fmtDateTime(new Date(a.unlockedAt))}</div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
