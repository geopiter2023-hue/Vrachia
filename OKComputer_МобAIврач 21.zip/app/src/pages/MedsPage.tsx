import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Pill, Plus, Trash2, Check, Send, MessageCircle, Copy, RefreshCw } from "lucide-react";
import { toast } from "sonner";

export default function MedsPage() {
  const utils = trpc.useUtils();
  const meds = trpc.bot.medications.list.useQuery();
  const link = trpc.bot.linkStatus.useQuery();
  const points = trpc.bot.points.balance.useQuery();
  const [name, setName] = useState("");
  const [dosage, setDosage] = useState("");
  const [times, setTimes] = useState("09:00");
  const [open, setOpen] = useState(false);

  const add = trpc.bot.medications.add.useMutation({
    onSuccess: () => {
      utils.bot.medications.list.invalidate();
      setName(""); setDosage(""); setTimes("09:00"); setOpen(false);
      toast.success("Лекарство добавлено в расписание");
    },
  });
  const take = trpc.bot.medications.take.useMutation({
    onSuccess: () => {
      utils.bot.medications.list.invalidate();
      utils.bot.points.balance.invalidate();
      toast.success("Приём отмечен · +5 баллов 🏅");
    },
  });
  const remove = trpc.bot.medications.remove.useMutation({
    onSuccess: () => utils.bot.medications.list.invalidate(),
  });
  const genCode = trpc.bot.generateLinkCode.useMutation();
  const unlink = trpc.bot.unlink.useMutation({
    onSuccess: () => {
      utils.bot.linkStatus.invalidate();
      toast.success("Бот отвязан");
    },
  });

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl md:text-2xl font-bold">Лекарства и напоминания</h1>
        <p className="text-muted-foreground text-sm mt-1">
          Расписание приёма, отметки и связка с мессенджер-ботом
        </p>
      </div>

      {/* Баллы здоровья */}
      {points.data && (
        <Card className="border-0 bg-gradient-to-r from-amber-50 to-yellow-50 dark:from-amber-950/40 dark:to-yellow-950/40">
          <CardContent className="p-4 flex items-center gap-4">
            <div className="text-3xl">{points.data.level === "Золото" ? "🥇" : points.data.level === "Серебро" ? "🥈" : "🥉"}</div>
            <div className="flex-1">
              <div className="font-bold">{points.data.total} баллов здоровья</div>
              <div className="text-xs text-muted-foreground">
                Уровень «{points.data.level}»
                {points.data.nextLevelAt && ` · до следующего уровня ${points.data.nextLevelAt - points.data.total} баллов`}
              </div>
              <div className="mt-1.5 h-1.5 rounded-full bg-black/10 dark:bg-white/10 overflow-hidden max-w-xs">
                <div
                  className="h-full bg-amber-500 rounded-full transition-all"
                  style={{ width: `${Math.min(100, (points.data.total / (points.data.nextLevelAt ?? 500)) * 100)}%` }}
                />
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Расписание лекарств */}
      <Card>
        <CardHeader className="pb-3 flex flex-row items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <Pill className="h-4 w-4 text-primary" /> Мои лекарства
          </CardTitle>
          <Button size="sm" variant="outline" onClick={() => setOpen((v) => !v)}>
            <Plus className="h-4 w-4 mr-1" /> Добавить
          </Button>
        </CardHeader>
        <CardContent className="space-y-2">
          {open && (
            <div className="rounded-lg border p-3 space-y-2 bg-muted/40">
              <div className="grid grid-cols-2 gap-2">
                <div className="col-span-2">
                  <Label className="text-xs">Название</Label>
                  <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Например, Витамин D" />
                </div>
                <div>
                  <Label className="text-xs">Дозировка</Label>
                  <Input value={dosage} onChange={(e) => setDosage(e.target.value)} placeholder="2000 МЕ" />
                </div>
                <div>
                  <Label className="text-xs">Время (через запятую)</Label>
                  <Input value={times} onChange={(e) => setTimes(e.target.value)} placeholder="09:00,21:00" />
                </div>
              </div>
              <Button
                size="sm"
                disabled={!name.trim() || add.isPending}
                onClick={() => add.mutate({ name: name.trim(), dosage: dosage || undefined, times })}
              >
                Сохранить
              </Button>
            </div>
          )}
          {meds.isLoading && <Skeleton className="h-16" />}
          {meds.data?.filter((m) => m.isActive).length === 0 && !open && (
            <p className="text-sm text-muted-foreground py-2">
              Пока пусто. Добавьте лекарство — система напомнит о приёме в указанное время, а бот примет отметку «принял».
            </p>
          )}
          {meds.data?.filter((m) => m.isActive).map((m) => (
            <div key={m.id} className="flex items-center gap-3 rounded-lg border px-3 py-2.5">
              <div className={`h-9 w-9 rounded-lg flex items-center justify-center shrink-0 ${m.takenToday ? "bg-emerald-100 dark:bg-emerald-950" : "bg-primary/10"}`}>
                {m.takenToday ? <Check className="h-4 w-4 text-emerald-600" /> : <Pill className="h-4 w-4 text-primary" />}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium truncate">{m.name}</div>
                <div className="text-xs text-muted-foreground">
                  {m.dosage && `${m.dosage} · `}{m.times.split(",").join(" и ")}
                  {m.totalTakes > 0 && ` · принято ${m.totalTakes} раз`}
                </div>
              </div>
              {m.takenToday ? (
                <Badge variant="secondary" className="bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400">принято</Badge>
              ) : (
                <Button size="sm" variant="outline" onClick={() => take.mutate({ id: m.id })} disabled={take.isPending}>
                  Принял
                </Button>
              )}
              <Button size="icon" variant="ghost" onClick={() => remove.mutate({ id: m.id })}>
                <Trash2 className="h-4 w-4 text-muted-foreground" />
              </Button>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Подключение бота */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <MessageCircle className="h-4 w-4 text-sky-500" /> Мессенджер-бот
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {link.data?.linked ? (
            <div className="flex items-center justify-between gap-2">
              <div className="text-sm">
                ✅ Бот подключён{link.data.accounts[0]?.username && ` (@${link.data.accounts[0].username})`}.
                Пишите ему «120/80», «вес 82.5» или «принял».
              </div>
              <Button size="sm" variant="outline" onClick={() => unlink.mutate()}>Отвязать</Button>
            </div>
          ) : (
            <>
              <p className="text-sm text-muted-foreground">
                Записывайте давление, вес и приём лекарств прямо из мессенджера — сообщением «120/80» или «принял».
                Сгенерируйте код и отправьте его боту:
              </p>
              {genCode.data ? (
                <div className="rounded-lg border bg-sky-50 dark:bg-sky-950/40 p-4 text-center space-y-2">
                  <div className="text-xs text-muted-foreground">Ваш код связки (действует 10 минут):</div>
                  <div className="text-3xl font-mono font-bold tracking-[0.3em]">{genCode.data.code}</div>
                  <div className="flex items-center justify-center gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        navigator.clipboard.writeText(genCode.data!.code);
                        toast.success("Код скопирован");
                      }}
                    >
                      <Copy className="h-3.5 w-3.5 mr-1" /> Копировать
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => genCode.mutate()}>
                      <RefreshCw className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Отправьте этот код боту первым сообщением — аккаунт свяжется автоматически.
                  </p>
                </div>
              ) : (
                <Button onClick={() => genCode.mutate()} disabled={genCode.isPending} variant="outline">
                  <Send className="h-4 w-4 mr-2" /> Получить код связки
                </Button>
              )}
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
