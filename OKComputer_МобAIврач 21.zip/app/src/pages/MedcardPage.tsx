import { useMemo, useState } from "react";
import { trpc } from "@/providers/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { fmtDate } from "@/lib/health-utils";
import {
  CalendarClock,
  FileText,
  FlaskConical,
  Syringe,
  HeartPulse,
  FileDown,
  FileSpreadsheet,
  ChevronDown,
  ChevronRight,
} from "lucide-react";
import { toast } from "sonner";
import { exportMedcardPdf } from "@/lib/medcard-pdf";
import { FileType } from "lucide-react";

const MONTHS = [
  "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
  "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь",
];

const CATEGORY: Record<string, { label: string; icon: any; cls: string }> = {
  document: { label: "Документ", icon: FileText, cls: "bg-sky-100 text-sky-800 dark:bg-sky-950 dark:text-sky-300" },
  measurement: { label: "Анализы", icon: FlaskConical, cls: "bg-teal-100 text-teal-800 dark:bg-teal-950 dark:text-teal-300" },
  vaccine: { label: "Прививка", icon: Syringe, cls: "bg-violet-100 text-violet-800 dark:bg-violet-950 dark:text-violet-300" },
  vital: { label: "Физиология", icon: HeartPulse, cls: "bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300" },
};

const FILTERS = [
  { key: "all", label: "Все события" },
  { key: "measurement", label: "Анализы" },
  { key: "document", label: "Документы" },
  { key: "vaccine", label: "Прививки" },
  { key: "vital", label: "Физиология" },
];

function download(filename: string, content: string, mime: string) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

type TlItem = { date: string; category: string; title: string; detail: string };
type Year = { year: number; months: { month: number; items: TlItem[] }[] };

export default function MedcardPage() {
  const { data, isLoading, isError, refetch, isFetching } = trpc.health.timeline.useQuery(undefined, {
    retry: 2,
  });
  const [filter, setFilter] = useState("all");
  const [year, setYear] = useState<string>("all");
  const [openYears, setOpenYears] = useState<Set<number>>(new Set());
  const [openMonths, setOpenMonths] = useState<Set<string>>(new Set());

  const years: Year[] = useMemo(() => {
    let ys = (data?.years ?? []) as Year[];
    if (year !== "all") ys = ys.filter((y) => y.year === Number(year));
    if (filter !== "all")
      ys = ys
        .map((y) => ({
          ...y,
          months: y.months
            .map((m) => ({ ...m, items: m.items.filter((i) => i.category === filter) }))
            .filter((m) => m.items.length),
        }))
        .filter((y) => y.months.length);
    return ys;
  }, [data, filter, year]);

  const allYears = (data?.years ?? []).map((y) => y.year);

  const toggleYear = (y: number) =>
    setOpenYears((s) => { const n = new Set(s); n.has(y) ? n.delete(y) : n.add(y); return n; });
  const toggleMonth = (k: string) =>
    setOpenMonths((s) => { const n = new Set(s); n.has(k) ? n.delete(k) : n.add(k); return n; });

  const isYearOpen = (y: number) => openYears.size === 0 ? true : openYears.has(y);
  const isMonthOpen = (k: string) => openMonths.size === 0 ? true : openMonths.has(k);

  // ── Экспорт ──
  const exportTxt = () => {
    const lines: string[] = [
      "МЕДИЦИНСКАЯ КАРТА — AI Врач",
      `Сформировано: ${new Date().toLocaleString("ru-RU")}`,
      `Период: ${year === "all" ? "все годы" : year} · Фильтр: ${FILTERS.find((f) => f.key === filter)?.label}`,
      "",
    ];
    for (const y of years) {
      lines.push(`══════════ ${y.year} ГОД ══════════`);
      for (const m of y.months) {
        lines.push(`\n── ${MONTHS[m.month - 1]} ${y.year} ──`);
        for (const i of m.items) {
          lines.push(`  • ${fmtDate(i.date)} [${CATEGORY[i.category]?.label ?? i.category}] ${i.title}`);
          if (i.detail) lines.push(`    ${i.detail.replace(/ ⚠/g, " [ОТКЛОНЕНИЕ]")}`);
        }
      }
      lines.push("");
    }
    lines.push("Результат не является диагнозом — при отклонениях требуется консультация врача.");
    download(`медкарта-${year === "all" ? "все-годы" : year}.txt`, lines.join("\n"), "text/plain");
    toast.success("Медкарта выгружена (TXT)");
  };

  const exportCsv = () => {
    const rows = ["year;month;date;category;title;detail"];
    for (const y of years)
      for (const m of y.months)
        for (const i of m.items)
          rows.push(
            `${y.year};${m.month};${i.date};${CATEGORY[i.category]?.label ?? i.category};"${i.title.replace(/"/g, '""')}";"${i.detail.replace(/"/g, '""')}"`
          );
    download(`медкарта-${year === "all" ? "все-годы" : year}.csv`, "\uFEFF" + rows.join("\n"), "text/csv");
    toast.success("Медкарта выгружена (CSV)");
  };

  const totalEvents = years.reduce((a, y) => a + y.months.reduce((b, m) => b + m.items.length, 0), 0);

  const [pdfBusy, setPdfBusy] = useState(false);
  const exportPdf = async () => {
    setPdfBusy(true);
    try {
      await exportMedcardPdf(years, {
        period: year === "all" ? "все годы" : year,
        filterLabel: FILTERS.find((f) => f.key === filter)?.label ?? "Все события",
      });
      toast.success("Медкарта выгружена (PDF)");
    } catch {
      toast.error("Не удалось сформировать PDF — проверьте соединение");
    } finally {
      setPdfBusy(false);
    }
  };

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl md:text-2xl font-bold flex items-center gap-2">
          <CalendarClock className="h-6 w-6 text-primary" /> Медкарта
        </h1>
        <p className="text-muted-foreground text-sm mt-1">
          Полная хронология здоровья по годам и месяцам: анализы, документы, прививки, физиология
        </p>
      </div>

      {/* Панель фильтров и экспорта */}
      <Card>
        <CardContent className="pt-4 pb-4 space-y-3">
          <div className="flex flex-wrap gap-1.5">
            {FILTERS.map((f) => (
              <button
                key={f.key}
                onClick={() => setFilter(f.key)}
                className={
                  "text-xs rounded-full px-3 py-1.5 font-medium transition-colors " +
                  (filter === f.key
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground hover:bg-accent")
                }
              >
                {f.label}
              </button>
            ))}
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <select
              value={year}
              onChange={(e) => setYear(e.target.value)}
              className="h-9 rounded-md border bg-background px-3 text-sm"
            >
              <option value="all">Все годы</option>
              {allYears.map((y) => (
                <option key={y} value={y}>{y}</option>
              ))}
            </select>
            <span className="text-xs text-muted-foreground">Событий: {totalEvents}</span>
            <div className="flex gap-2 ml-auto">
              <Button variant="outline" size="sm" onClick={exportPdf} disabled={pdfBusy || years.length === 0}>
                <FileType className="h-4 w-4 mr-1" /> {pdfBusy ? "PDF…" : "PDF"}
              </Button>
              <Button variant="outline" size="sm" onClick={exportTxt}>
                <FileDown className="h-4 w-4 mr-1" /> TXT
              </Button>
              <Button variant="outline" size="sm" onClick={exportCsv}>
                <FileSpreadsheet className="h-4 w-4 mr-1" /> CSV
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Хронология */}
      {isLoading ? (
        <Card>
          <CardContent className="py-16 text-center space-y-3">
            <div className="text-sm text-muted-foreground">Загружаю хронологию здоровья…</div>
            <div className="space-y-3">{[0, 1, 2].map((i) => <Skeleton key={i} className="h-20" />)}</div>
          </CardContent>
        </Card>
      ) : isError ? (
        <Card>
          <CardContent className="py-16 text-center space-y-3">
            <div className="text-sm text-muted-foreground">
              Не удалось загрузить медкарту — проверьте соединение
            </div>
            <Button variant="outline" size="sm" onClick={() => refetch()} disabled={isFetching}>
              {isFetching ? "Загрузка…" : "Повторить"}
            </Button>
          </CardContent>
        </Card>
      ) : years.length === 0 ? (
        <Card>
          <CardContent className="py-16 text-center space-y-2">
            <div className="text-sm font-medium">Событий пока нет</div>
            <p className="text-xs text-muted-foreground max-w-xs mx-auto">
              Загрузите анализы и заключения в разделе «Документы» или добавьте измерения в «Показателях» —
              хронология по годам и месяцам построится автоматически.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {years.map((y) => {
            const yCount = y.months.reduce((a, m) => a + m.items.length, 0);
            const yOpen = isYearOpen(y.year);
            return (
              <Card key={y.year}>
                <button
                  onClick={() => toggleYear(y.year)}
                  className="w-full flex items-center gap-3 px-5 py-4 text-left"
                >
                  {yOpen ? <ChevronDown className="h-5 w-5 text-primary" /> : <ChevronRight className="h-5 w-5 text-muted-foreground" />}
                  <span className="text-lg font-bold">{y.year} год</span>
                  <Badge variant="secondary" className="ml-auto">{yCount} событий</Badge>
                </button>
                {yOpen && (
                  <CardContent className="pt-0 pb-4 space-y-3">
                    {y.months.map((m) => {
                      const mk = `${y.year}-${m.month}`;
                      const mOpen = isMonthOpen(mk);
                      return (
                        <div key={mk} className="rounded-xl border">
                          <button
                            onClick={() => toggleMonth(mk)}
                            className="w-full flex items-center gap-2.5 px-4 py-3 text-left"
                          >
                            {mOpen ? <ChevronDown className="h-4 w-4 text-primary" /> : <ChevronRight className="h-4 w-4 text-muted-foreground" />}
                            <span className="font-semibold text-sm">{MONTHS[m.month - 1]}</span>
                            <span className="text-xs text-muted-foreground ml-auto">{m.items.length} событий</span>
                          </button>
                          {mOpen && (
                            <div className="px-4 pb-3 space-y-2">
                              {m.items.map((i, idx) => {
                                const c = CATEGORY[i.category] ?? CATEGORY.document;
                                const Icon = c.icon;
                                return (
                                  <div key={idx} className="flex items-start gap-3 rounded-lg bg-muted/60 px-3 py-2.5">
                                    <div className="h-8 w-8 rounded-lg bg-card flex items-center justify-center shrink-0">
                                      <Icon className="h-4 w-4 text-primary" />
                                    </div>
                                    <div className="flex-1 min-w-0">
                                      <div className="flex items-center gap-2 flex-wrap">
                                        <span className="text-sm font-medium">{i.title}</span>
                                        <Badge className={c.cls + " text-xs"} variant="secondary">{c.label}</Badge>
                                      </div>
                                      {i.detail && (
                                        <div className="text-xs text-muted-foreground mt-1 whitespace-pre-line">{i.detail}</div>
                                      )}
                                      <div className="text-xs text-muted-foreground mt-0.5">{fmtDate(i.date)}</div>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </CardContent>
                )}
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
