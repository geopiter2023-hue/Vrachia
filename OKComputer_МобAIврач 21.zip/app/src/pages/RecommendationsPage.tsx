import { trpc } from "@/providers/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Salad,
  Dumbbell,
  AlertTriangle,
  Sparkles,
  Info,
} from "lucide-react";
import RetestDeals from "@/components/RetestDeals";

const PRIORITY = {
  high: { label: "Важно", cls: "bg-rose-100 text-rose-700 border-rose-200" },
  medium: { label: "Желательно", cls: "bg-amber-100 text-amber-700 border-amber-200" },
  low: { label: "Профилактика", cls: "bg-emerald-100 text-emerald-700 border-emerald-200" },
} as const;

type Rec = { title: string; detail: string; reason: string; priority: keyof typeof PRIORITY };

function RecCard({ r }: { r: Rec }) {
  const p = PRIORITY[r.priority] ?? PRIORITY.low;
  return (
    <Card>
      <CardContent className="p-4 space-y-2">
        <div className="flex items-start justify-between gap-2">
          <div className="font-semibold text-sm leading-snug">{r.title}</div>
          <Badge variant="outline" className={`shrink-0 ${p.cls}`}>
            {p.label}
          </Badge>
        </div>
        <p className="text-sm text-muted-foreground leading-relaxed">{r.detail}</p>
        <p className="text-xs text-muted-foreground/80 flex items-center gap-1">
          <Info className="h-3 w-3 shrink-0" /> Основание: {r.reason}
        </p>
      </CardContent>
    </Card>
  );
}

export default function RecommendationsPage() {
  const { data, isLoading } = trpc.health.recommendations.useQuery();

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl md:text-2xl font-bold flex items-center gap-2">
          <Sparkles className="h-6 w-6 text-primary" /> Рекомендации
        </h1>
        <p className="text-muted-foreground text-sm mt-1">
          Персональные советы по питанию и спорту на основе отклонений в анализах и физиологии
        </p>
      </div>

      {/* Витрина выгоды: что пересдать и где дешевле */}
      <RetestDeals />

      {isLoading ? (
        <div className="space-y-3">
          <Skeleton className="h-24 w-full" />
          <Skeleton className="h-24 w-full" />
          <Skeleton className="h-24 w-full" />
        </div>
      ) : data ? (
        <>
          <Card className="border-primary/30 bg-primary/5">
            <CardContent className="p-4 text-sm">{data.summary}</CardContent>
          </Card>

          {data.contraindications.length > 0 && (
            <div className="space-y-2">
              <h2 className="font-semibold flex items-center gap-2 text-rose-700">
                <AlertTriangle className="h-5 w-5" /> Ограничения и противопоказания
              </h2>
              {data.contraindications.map((c, i) => (
                <Card key={i} className="border-rose-200 bg-rose-50">
                  <CardContent className="p-4 text-sm text-rose-800">{c}</CardContent>
                </Card>
              ))}
            </div>
          )}

          <div className="space-y-3">
            <h2 className="font-semibold flex items-center gap-2">
              <Salad className="h-5 w-5 text-emerald-600" /> Питание
            </h2>
            <div className="grid gap-3 md:grid-cols-2">
              {data.nutrition.map((r, i) => (
                <RecCard key={i} r={r as Rec} />
              ))}
            </div>
          </div>

          <div className="space-y-3">
            <h2 className="font-semibold flex items-center gap-2">
              <Dumbbell className="h-5 w-5 text-sky-600" /> Спорт и активность
            </h2>
            <div className="grid gap-3 md:grid-cols-2">
              {data.sport.map((r, i) => (
                <RecCard key={i} r={r as Rec} />
              ))}
            </div>
          </div>

          <p className="text-xs text-muted-foreground border-t pt-3">
            Рекомендации сформированы локальным движком анализа на основании ваших данных и носят
            информационный характер. Перед изменением диеты или началом тренировок при отклонениях
            проконсультируйтесь с врачом.
          </p>
        </>
      ) : null}
    </div>
  );
}
