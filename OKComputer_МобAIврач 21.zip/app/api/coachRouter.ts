// ─── Проактивный ИИ-коуч, отчёты для врача, витрина выгоды ───────────────
import { z } from "zod";
import { createRouter, userProcedure } from "./middleware";
import { getDb } from "./queries/connection";
import {
  biomarkers,
  measurements,
  documents,
  bpEntries,
  wellnessChecks,
  vitals,
  clinics,
} from "@db/schema";
import { desc, eq, or, isNull, sql } from "drizzle-orm";
import { analyzeBiomarker, type BiomarkerAnalysis } from "./analysis";
import { computeHealthScore } from "./wellnessRouter";

async function loadAnalyses(userId: number): Promise<BiomarkerAnalysis[]> {
  const db = getDb();
  const [bs, ms] = await Promise.all([
    db.select().from(biomarkers).where(or(isNull(biomarkers.userId), eq(biomarkers.userId, userId))),
    db.select().from(measurements).where(eq(measurements.userId, userId)),
  ]);
  return bs.map((b) => analyzeBiomarker(b, ms.filter((m) => m.biomarkerId === Number(b.id))));
}

// Правила коуча: код биомаркера → совет с источником (клинические рекомендации)
const COACH_RULES: Record<
  string,
  { high?: string; low?: string; source: string }
> = {
  VITD: {
    low: "Витамин D ниже нормы. Обсудите с врачом приём колекальциферола 1000–2000 МЕ/сут и контроль через 2–3 месяца.",
    source: "Клинические рекомендации РАЭ «Дефицит витамина D у взрослых», 2021; Endocrine Society Guidelines",
  },
  URIC: {
    high: "Мочевая кислота повышена. Ограничьте красное мясо, субпродукты, пиво и сладкие напитки; пейте 1,5–2 л воды в день. При повторном повышении — консультация ревматолога.",
    source: "EULAR рекомендации по ведению гиперурикемии, 2016; Ассоциация ревматологов России",
  },
  CHOL: {
    high: "Холестерин выше оптимального уровня. Основа снижения — меньше насыщенных жиров, больше клетчатки и рыбы, 150 мин активности в неделю. Оцените сердечно-сосудистый риск по шкале SCORE с врачом.",
    source: "ESC/EAS рекомендации по дислипидемиям, 2019; РНКОА «Нарушения липидного обмена», 2023",
  },
  LDL: {
    high: "ЛПНП выше целевого уровня. Это главный модифицируемый фактор атеросклероза: рацион средиземноморского типа и регулярная активность снижают его на 10–15%.",
    source: "ESC/EAS Guidelines for the management of dyslipidaemias, 2019",
  },
  TG: {
    high: "Триглицериды повышены. Главные причины — избыток простых углеводов и алкоголь. Снижение веса на 5–10% уменьшает ТГ на ~20%.",
    source: "ESC/EAS 2019; Американская кардиологическая ассоциация (AHA), 2021",
  },
  GLU: {
    high: "Глюкоза на верхней границе или выше. Проверьте гликированный гемоглобин (HbA1c) — он показывает средний сахар за 3 месяца.",
    source: "Алгоритмы СД 2 типа (10-й выпуск), Ассоциация эндокринологов России",
  },
  HGB: {
    low: "Гемоглобин снижен. Проверьте ферритин и витамин B12 — чаще всего это железодефицит. Приём железа без анализа ферритина не рекомендуется.",
    source: "Клинические рекомендации «Железодефицитная анемия», Минздрав России",
  },
  FERR: {
    low: "Ферритин низкий — запасы железа истощены даже при нормальном гемоглобине. Обсудите с врачом препараты железа и поиск причины.",
    source: "КР «Железодефицитная анемия»; WHO guideline on ferritin, 2020",
  },
  B12: {
    low: "Витамин B12 ниже нормы. Длительный дефицит влияет на нервную систему — стоит обсудить добавки и причину (рацион, всасывание).",
    source: "КР «В12-дефицитная анемия»; British Society for Haematology, 2014",
  },
  WBC: {
    low: "Лейкоциты ниже нормы (лейкопения). Частая причина — перенесённая вирусная инфекция; стоит пересдать через 2–4 недели и показать результат терапевту.",
    source: "КР по клинической лабораторной диагностике; UpToDate: Approach to leukopenia",
  },
  TSH: {
    high: "ТТГ повышен — признак снижения функции щитовидной железы. Проверьте Т4 свободный и обратитесь к эндокринологу.",
    source: "КР «Гипотиреоз у взрослых», Ассоциация эндокринологов России",
    low: "ТТГ снижен — возможна избыточная функция щитовидной железы. Проверьте Т4 и Т3 свободные, обратитесь к эндокринологу.",
  },
  ALT: {
    high: "АЛТ повышена — маркер нагрузки на печень. Исключите алкоголь на 2–4 недели, проверьте ГГТ и сделайте УЗИ печени.",
    source: "КР «Неалкогольная жировая болезнь печени», РГГ, 2021",
  },
  NEUTABS: {
    low: "Абсолютные нейтрофилы снижены (нейтропения). Это влияет на защиту от инфекций — результат стоит показать терапевту в ближайшее время.",
    source: "UpToDate: Neutropenia in adults; КР по гематологии",
  },
};

export const coachRouter = createRouter({
  // Проактивные инсайты коуча для главной страницы
  insights: userProcedure.query(async ({ ctx }) => {
    const analyses = await loadAnalyses(ctx.user.id);
    const withData = analyses.filter((a) => a.latest);
    const insights: {
      kind: "alert" | "trend" | "praise" | "action";
      title: string;
      body: string;
      source?: string;
      code?: string;
      biomarkerName?: string;
    }[] = [];

    // 1. Критические отклонения — правила коуча
    for (const a of withData) {
      if (a.status === "normal") continue;
      const rule = COACH_RULES[a.biomarker.code];
      const dir = a.status === "low" ? "low" : "high";
      const text = rule?.[dir as "high" | "low"];
      if (text) {
        insights.push({
          kind: a.status === "critical" ? "alert" : "action",
          title: `${a.biomarker.name}: ${a.latest!.value} ${a.biomarker.unit}`,
          body: text,
          source: rule?.source,
          code: a.biomarker.code,
          biomarkerName: a.biomarker.name,
        });
      }
    }

    // 2. Ухудшающаяся динамика (два подряд ухудшения)
    for (const a of withData) {
      if (a.points.length < 2 || a.status === "normal") continue;
      const last = a.points[a.points.length - 1];
      const prev = a.points[a.points.length - 2];
      const { refLow, refHigh } = a.biomarker;
      if (refLow == null || refHigh == null) continue;
      const dev = (v: number) => (v > refHigh ? v - refHigh : v < refLow ? refLow - v : 0);
      if (dev(last.value) > dev(prev.value) && dev(prev.value) > 0) {
        insights.push({
          kind: "trend",
          title: `${a.biomarker.name} ухудшается`,
          body: `Два анализа подряд отклонение растёт: ${prev.value} → ${last.value} ${a.biomarker.unit}. Это повод не откладывать визит к врачу.`,
          code: a.biomarker.code,
          biomarkerName: a.biomarker.name,
        });
      }
    }

    // 3. Давление за неделю
    const db = getDb();
    const since7 = new Date(Date.now() - 7 * 864e5);
    const bp = await db.select().from(bpEntries).where(eq(bpEntries.userId, ctx.user.id)).orderBy(desc(bpEntries.measuredAt)).limit(60);
    const week = bp.filter((e) => new Date(e.measuredAt) >= since7);
    if (week.length >= 3) {
      const avgS = week.reduce((a, e) => a + e.sys, 0) / week.length;
      const avgD = week.reduce((a, e) => a + e.dia, 0) / week.length;
      if (avgS >= 135 || avgD >= 85) {
        insights.push({
          kind: "alert",
          title: `Среднее АД за неделю ${Math.round(avgS)}/${Math.round(avgD)}`,
          body: "Домашнее давление устойчиво выше 135/85 — критерий гипертонии по домашнему мониторингу. Запишитесь к терапевту и возьмите с собой дневник.",
          source: "ESC/ESH Guidelines for the management of arterial hypertension, 2018; КР «Артериальная гипертензия у взрослых», 2024",
        });
      } else if (avgS < 125 && avgD < 80) {
        insights.push({
          kind: "praise",
          title: "Давление в отличной форме",
          body: `Среднее за неделю ${Math.round(avgS)}/${Math.round(avgD)} при ${week.length} измерениях. Так держать!`,
        });
      }
    }

    // 4. Похвала за регулярность
    const checks = await db.select({ d: wellnessChecks.checkDate }).from(wellnessChecks).where(eq(wellnessChecks.userId, ctx.user.id)).catch(() => [] as any[]);
    const weekChecks = checks.filter((c: any) => new Date(String(c.d)) >= since7).length;
    if (weekChecks >= 5) {
      insights.push({
        kind: "praise",
        title: "Отличная регулярность",
        body: `${weekChecks} чек-инов за неделю — вы в 10% самых дисциплинированных пользователей. Регулярный самоконтроль снижает риски осложнений.`,
      });
    }

    // 5. Нет данных — навигационный совет
    if (!withData.length) {
      insights.push({
        kind: "action",
        title: "Начните с загрузки анализов",
        body: "Загрузите последний результат анализа крови (PDF) — я распознаю показатели и начну следить за динамикой.",
      });
    }

    const order = { alert: 0, trend: 1, action: 2, praise: 3 } as const;
    return insights.sort((a, b) => order[a.kind] - order[b.kind]).slice(0, 6);
  }),

  // Отчёт для врача — одна страница перед приёмом
  doctorBrief: userProcedure.query(async ({ ctx }) => {
    const uid = ctx.user.id;
    const analyses = await loadAnalyses(uid);
    const withData = analyses.filter((a) => a.latest);
    const db = getDb();
    const [docs, bp, { score }] = await Promise.all([
      db.select().from(documents).where(eq(documents.userId, uid)).orderBy(desc(documents.docDate)).limit(10),
      db.select().from(bpEntries).where(eq(bpEntries.userId, uid)).orderBy(desc(bpEntries.measuredAt)).limit(90),
      computeHealthScore(uid),
    ]);
    const abnormal = withData.filter((a) => a.status !== "normal");
    const since30 = new Date(Date.now() - 30 * 864e5);
    const bp30 = bp.filter((e) => new Date(e.measuredAt) >= since30);
    return {
      generatedAt: new Date().toISOString(),
      healthScore: score,
      abnormal: abnormal.map((a) => ({
        name: a.biomarker.name,
        value: a.latest!.value,
        unit: a.biomarker.unit,
        refLow: a.biomarker.refLow,
        refHigh: a.biomarker.refHigh,
        status: a.status,
        date: a.latest!.date,
        trend: a.trend,
      })),
      normalCount: withData.length - abnormal.length,
      bpSummary: bp30.length
        ? {
            count: bp30.length,
            avgSys: Math.round(bp30.reduce((x, e) => x + e.sys, 0) / bp30.length),
            avgDia: Math.round(bp30.reduce((x, e) => x + e.dia, 0) / bp30.length),
            maxSys: Math.max(...bp30.map((e) => e.sys)),
          }
        : null,
      recentDocs: docs.slice(0, 5).map((d) => ({
        title: d.title,
        date: d.docDate,
        type: d.docType,
        source: d.source,
      })),
      questions: [
        abnormal.length ? `Что делать с отклонениями: ${abnormal.slice(0, 3).map((a) => a.biomarker.name).join(", ")}?` : null,
        bp30.length && bp30.reduce((x, e) => x + e.sys, 0) / bp30.length >= 135 ? "Нужна ли коррекция терапии по давлению?" : null,
        "Какие анализы пересдать и когда?",
      ].filter(Boolean) as string[],
    };
  }),

  // «Мой год здоровья» — красивая годовая сводка (Wrapped)
  yearWrapped: userProcedure
    .input(z.object({ year: z.number().optional() }))
    .query(async ({ input, ctx }) => {
      const year = input.year ?? new Date().getFullYear();
      const db = getDb();
      const uid = ctx.user.id;
      const prefix = `${year}-`;
      const [ms, docs, checks, bp, vs] = await Promise.all([
        db.select().from(measurements).where(eq(measurements.userId, uid)),
        db.select().from(documents).where(eq(documents.userId, uid)),
        db.select().from(wellnessChecks).where(eq(wellnessChecks.userId, uid)).catch(() => [] as any[]),
        db.select().from(bpEntries).where(eq(bpEntries.userId, uid)),
        db.select().from(vitals).where(eq(vitals.userId, uid)),
      ]);
      const yearMs = ms.filter((m) => String(m.measuredAt).startsWith(prefix));
      const yearDocs = docs.filter((d) => String(d.docDate).startsWith(prefix));
      const yearChecks = checks.filter((c: any) => String(c.checkDate).startsWith(prefix));
      const yearBp = bp.filter((e) => new Date(e.measuredAt).getFullYear() === year);
      const analyses = await loadAnalyses(uid);
      const withData = analyses.filter((a) => a.latest);
      const inNorm = withData.filter((a) => a.status === "normal").length;
      const months = new Set(yearMs.map((m) => String(m.measuredAt).slice(0, 7)));
      return {
        year,
        measurements: yearMs.length,
        documents: yearDocs.length,
        checkins: yearChecks.length,
        bpEntries: yearBp.length,
        activeMonths: months.size,
        biomarkersInNorm: inNorm,
        biomarkersTotal: withData.length,
        topImprovement: withData
          .filter((a) => a.points.length >= 2 && a.trend === "down" && a.status === "normal")
          .slice(0, 3)
          .map((a) => a.biomarker.name),
        vitalsCount: vs.filter((v) => new Date(v.measuredAt).getFullYear() === year).length,
      };
    }),

  // Витрина выгоды: что пересдать + где дешевле
  retestDeals: userProcedure.query(async ({ ctx }) => {
    const analyses = await loadAnalyses(ctx.user.id);
    const db = getDb();
    const due: { name: string; value: number; unit: string; daysAgo: number; reason: string }[] = [];
    for (const a of analyses) {
      if (!a.latest || a.status === "normal") continue;
      const days = Math.floor((Date.now() - new Date(a.latest.date).getTime()) / 864e5);
      if (days >= 60) {
        due.push({
          name: a.biomarker.name,
          value: a.latest.value,
          unit: a.biomarker.unit,
          daysAgo: days,
          reason: a.status === "critical" ? "Критическое отклонение — пересдайте как можно скорее" : "Отклонению больше 2 месяцев — нужен контроль",
        });
      }
    }
    // Клиники с ценами из базы (агрегированные данные)
    const offers = await db
      .select({
        name: clinics.name,
        city: clinics.city,
        priceFrom: clinics.priceFrom,
        rating: clinics.rating,
      })
      .from(clinics)
      .orderBy(sql`price_from IS NULL, price_from ASC`)
      .limit(5)
      .catch(() => [] as any[]);
    return { due, offers };
  }),
});
