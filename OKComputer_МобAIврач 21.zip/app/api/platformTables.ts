// ── Платформа: самосоздание таблиц клиник и маркетплейса (идемпотентно) ──
import { getDb } from "./queries/connection";
import { sql } from "drizzle-orm";

let ready = false;
export async function ensurePlatformTables() {
  if (ready) return;
  const db = getDb();
  await db.execute(sql.raw(`CREATE TABLE IF NOT EXISTS clinic_accounts (
    id bigint unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
    email varchar(255) NOT NULL,
    password_hash varchar(128) NOT NULL,
    org_name varchar(255) NOT NULL,
    license_number varchar(128),
    phone varchar(64),
    created_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_email (email)
  )`));
  await db.execute(sql.raw(`CREATE TABLE IF NOT EXISTS clinic_profiles (
    id bigint unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
    account_id bigint unsigned NOT NULL,
    name varchar(255) NOT NULL,
    city varchar(128) NOT NULL,
    address varchar(512),
    phone varchar(64),
    website varchar(512),
    specialties text,
    services text,
    price_from double,
    description text,
    is_published tinyint(1) NOT NULL DEFAULT 0,
    created_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_acc (account_id), KEY idx_city (city), KEY idx_pub (is_published)
  )`));
  await db.execute(sql.raw(`CREATE TABLE IF NOT EXISTS clinic_promotions (
    id bigint unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
    account_id bigint unsigned NOT NULL,
    city varchar(128) NOT NULL,
    tariff varchar(32) NOT NULL,
    price_month double NOT NULL,
    status varchar(32) NOT NULL DEFAULT 'active',
    started_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ends_at timestamp NULL,
    KEY idx_acc (account_id), KEY idx_city_status (city, status)
  )`));
  await db.execute(sql.raw(`CREATE TABLE IF NOT EXISTS clinic_bookings (
    id bigint unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
    user_id bigint unsigned NOT NULL,
    profile_id bigint unsigned NOT NULL,
    account_id bigint unsigned NOT NULL,
    specialty varchar(128),
    preferred_date varchar(32),
    contact_phone varchar(64) NOT NULL,
    comment text,
    reason text,
    status varchar(32) NOT NULL DEFAULT 'new',
    created_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_acc (account_id), KEY idx_user (user_id)
  )`));
  await db.execute(sql.raw(`CREATE TABLE IF NOT EXISTS market_products (
    id bigint unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
    category varchar(128) NOT NULL,
    name varchar(255) NOT NULL,
    sku varchar(64),
    unit varchar(32) NOT NULL DEFAULT 'упак.',
    price double NOT NULL,
    stock bigint NOT NULL DEFAULT 0,
    supplier varchar(255),
    requires_license tinyint(1) NOT NULL DEFAULT 0,
    description text,
    KEY idx_cat (category)
  )`));
  await db.execute(sql.raw(`CREATE TABLE IF NOT EXISTS market_orders (
    id bigint unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
    account_id bigint unsigned NOT NULL,
    total double NOT NULL,
    status varchar(32) NOT NULL DEFAULT 'new',
    comment text,
    created_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_acc (account_id)
  )`));
  await db.execute(sql.raw(`CREATE TABLE IF NOT EXISTS market_order_items (
    id bigint unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
    order_id bigint unsigned NOT NULL,
    product_id bigint unsigned NOT NULL,
    qty bigint NOT NULL,
    price double NOT NULL,
    KEY idx_order (order_id)
  )`));
  ready = true;
}
