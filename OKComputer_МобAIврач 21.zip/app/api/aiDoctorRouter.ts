import { z } from "zod";
import { createRouter, userProcedure } from "./middleware";
import { getDb } from "./queries/connection";
import { biomarkers, measurements, documents } from "@db/schema";
import { desc, eq, isNull, or } from "drizzle-orm";
import { analyzeBiomarker } from "./analysis";

// ── Сессии консультаций (в памяти процесса) ─────────────────────────────
type ChatMsg = { role: "ai" | "user"; text: string };
type Session = {
  id: string;
  complaint: string;
  flow: Flow;
  step: number;
  answers: string[];
  history: ChatMsg[];
  createdAt: number;
  userId: number;
};
const sessions = new Map<string, Session>();
let seq = 1;

// ── Диалоговые сценарии по группам симптомов ────────────────────────────
type Diag = { name: string; prob: number; note: string };
type Conclusion = {
  diagnoses: Diag[];
  plan: string[];
  redFlags: string[];
  specialist: string;
  selfCare: string[];
  urgent: boolean;
};
type Flow = {
  id: string;
  title: string;
  keys: string[];
  specialist: string;
  questions: string[];
  conclude: (complaint: string, answers: string[]) => Conclusion;
};

const yes = (s: string) => /^(да|ага|угу|бывает|иногда|есть|конечно|yes)/i.test(s.trim());

const FLOWS: Flow[] = [
  {
    id: "eyes",
    title: "Зрение и работа за компьютером",
    keys: ["глаз", "зрени", "экран", "компьютер", "песок в глазах", "сухость глаз", "мутн", "двоен", "устают глаза", "резь в глазах"],
    specialist: "офтальмолог",
    questions: [
      "Как давно появились эти ощущения — дни, недели или уже несколько месяцев?",
      "Сколько часов в день вы проводите за экраном без перерыва?",
      "Это происходит только во время работы за компьютером или бывает и в других ситуациях — на прогулке, за рулём, во время отдыха?",
      "Бывают ли в такие моменты боль, тяжесть или скованность в области шеи или затылка?",
      "Замечали ли вы двоение в глазах, затуманенность или повышенную чувствительность к свету экрана?",
      "Проверяли ли вы зрение у офтальмолога и пробовали ли уже что-то — перерывы, увлажняющие капли, настройку яркости экрана?",
    ],
    conclude: (_c, a) => {
      const long = Number((a[1] ?? "").match(/\d+/)?.[0] ?? 0) >= 6 || /много|весь день|\d{2,}/.test(a[1] ?? "");
      const neck = yes(a[3] ?? "");
      const vision = yes(a[4] ?? "");
      return {
        diagnoses: [
          { name: "Синдром зрительного утомления (астенопия)", prob: long ? 78 : 62, note: "Длительная фокусировка на экране, редкое моргание, сухость глаз и «мутная» картинка к концу дня — типичная картина." },
          { name: "Синдром сухого глаза", prob: 41, note: "При работе за экраном моргательный рефлекс снижается в 3–4 раза, слёзная плёнка высыхает." },
          ...(neck ? [{ name: "Цервикокраниалгия (напряжение мышц шеи)", prob: 38, note: "Скованность шеи и затылка усиливает зрительное утомление и ощущение «помутнения»." }] : []),
          ...(vision ? [{ name: "Нарушение рефракции — стоит исключить", prob: 24, note: "Двоение и затуманенность могут указывать на неподобранную коррекцию." }] : []),
        ],
        plan: [
          "Правило 20-20-20: каждые 20 минут — 20 секунд смотреть на объект в 6 метрах.",
          "Проверить зрение у офтальмолога, если обследования не было больше года.",
          "Экран на уровне или чуть ниже глаз, расстояние 50–70 см, яркость под окружающий свет.",
          "Если симптомы не уйдут за 2 недели при соблюдении режима — очный приём офтальмолога.",
        ],
        redFlags: [
          "Резкая потеря зрения, «занавеска» перед глазом",
          "Вспышки света или ливень «мушек»",
          "Сильная боль в глазу с покраснением",
          "Двоение, которое не проходит после отдыха",
        ],
        specialist: "офтальмолог",
        selfCare: [
          "Увлажняющие капли «искусственная слеза» без консервантов — по необходимости",
          "Перерыв 5–10 минут каждый час работы",
          "Гимнастика для глаз: перевод взгляда ближний–дальний объект 10 раз",
        ],
        urgent: false,
      };
    },
  },
  {
    id: "head",
    title: "Головная боль и головокружение",
    keys: ["голов", "мигрен", "кружит", "головокруж", "болит голова", "помутнение сознания", "сознани", "предобмороч"],
    specialist: "невролог",
    questions: [
      "Как давно это началось и как часто повторяется — каждый день, несколько раз в неделю, редко?",
      "Опишите характер: это боль (пульсирующая, давящая, ноющая) или скорее головокружение и «ватная» голова?",
      "Бывало ли, что во время приступов вы полностью теряли сознание или падали?",
      "Есть ли связь с длительной работой за компьютером, недосыпом, стрессом или пропущенным приёмом пищи?",
      "Сопровождается ли тошнотой, чувствительностью к свету и звуку, онемением лица или конечностей?",
      "Измеряли ли вы артериальное давление в момент приступа? Какие были цифры?",
    ],
    conclude: (_c, a) => {
      const faint = yes(a[2] ?? "");
      const nausea = /тошнот|свет|звук/i.test(a[4] ?? "") && yes(a[4] ?? "");
      return {
        diagnoses: [
          { name: "Головная боль напряжения", prob: 64, note: "Самая частая причина: связана с длительным статичным положением, стрессом и недосыпом." },
          ...(nausea ? [{ name: "Мигрень", prob: 47, note: "Пульсирующая боль с чувствительностью к свету/звуку и тошнотой — характерные признаки." }] : []),
          { name: "Вестибулярное головокружение", prob: 30, note: "Ощущение «мутной» головы и неустойчивости может быть связано с внутренним ухом или шейным отделом." },
          ...(faint ? [{ name: "Синкопальные состояния — требуется обследование", prob: 22, note: "Эпизоды потери сознания нельзя оставлять без оценки врача." }] : []),
        ],
        plan: [
          "Вести дневник приступов: дата, длительность, провоцирующий фактор, давление в моменте.",
          "Измерить давление и пульс во время следующего эпизода и записать цифры в дневник давления.",
          "Нормализовать сон (7–8 часов), регулярное питание и потребление воды.",
          faint ? "Записаться к неврологу в ближайшие дни — эпизоды потери сознания требуют очной оценки." : "Если приступы участятся или изменят характер — приём невролога.",
        ],
        redFlags: [
          "Внезапная «громовая» боль, которой не было никогда",
          "Потеря сознания, судороги",
          "Онемение или слабость в половине тела, нарушение речи",
          "Температура + ригидность затылочных мышц",
        ],
        specialist: "невролог",
        selfCare: ["Проветрить комнату, отложить экраны на 30–60 минут", "Стакан воды и лёгкий перекус, если пропущен приём пищи", "Спокойная прогулка на свежем воздухе"],
        urgent: faint,
      };
    },
  },
  {
    id: "throat",
    title: "Горло, насморк и кашель",
    keys: ["горл", "насморк", "кашел", "простуд", "температур", "орви", "грипп", "насморк", "заложен"],
    specialist: "терапевт",
    questions: [
      "Как давно началось и есть ли повышение температуры? Если да — до каких цифр?",
      "Что беспокоит сильнее: боль в горле, кашель или насморк?",
      "Кашель сухой или с мокротой?",
      "Был ли контакт с заболевшими в последнюю неделю?",
      "Есть ли одышка, боль в груди или свистящее дыхание?",
    ],
    conclude: (_c, a) => {
      const dyspnea = yes(a[4] ?? "");
      return {
        diagnoses: [
          { name: "Острая респираторная вирусная инфекция (ОРВИ)", prob: 72, note: "Частая «простуда» с болью в горле, насморком, кашлем и небольшой слабостью." },
          { name: "Грипп или гриппоподобная инфекция", prob: 36, note: "Вероятнее при высокой температуре, ломоте в теле и контакте с заболевшими." },
          { name: "Острый фарингит / ринит", prob: 28, note: "Локальное воспаление слизистой без выраженной общей интоксикации." },
        ],
        plan: [
          "Измерять температуру 2 раза в день и записывать в систему.",
          "Обильное тёплое питьё, проветривание, увлажнение воздуха.",
          dyspnea ? "При одышке и боли в груди — очный осмотр терапевта в ближайшие 1–2 дня." : "Наблюдение 2–3 дня: при ухудшении или температуре выше 38,5 более 3 дней — к терапевту.",
        ],
        redFlags: ["Одышка в покое, боль в груди", "Температура выше 39, не снижающаяся", "Спутанность сознания, сильная слабость", "Гнойный налёт на миндалинах с высокой температурой"],
        specialist: "терапевт",
        selfCare: ["Полоскание горла тёплым солевым раствором", "Промывание носа солевым раствором", "Постельный режим при температуре"],
        urgent: dyspnea,
      };
    },
  },
  {
    id: "heart",
    title: "Сердце и давление",
    keys: ["сердц", "давлен", "пульс", "за грудиной", "в груди", "гипертони", "тахикард", "колет сердце"],
    specialist: "кардиолог",
    questions: [
      "Опишите характер ощущений: тяжесть, жжение, острая, колющая или ноющая боль?",
      "Связано ли это с физической нагрузкой (подъём по лестнице, ходьба) и проходит ли в покое?",
      "Отдаёт ли боль в левую руку, спину, шею или нижнюю челюсть?",
      "Какие цифры давления и пульса вы видели за последнее время?",
      "Есть ли одышка, отёки на ногах к вечеру, перебои в работе сердца?",
    ],
    conclude: (_c, a) => {
      const exert = yes(a[1] ?? "");
      return {
        diagnoses: [
          ...(exert ? [{ name: "Стенокардия напряжения — требуется исключить", prob: 44, note: "Боль/тяжесть при нагрузке, проходящая в покое, — повод для планового, но не откладываемого обследования." }] : []),
          { name: "Функциональные кардиалгии", prob: 52, note: "Колющие кратковременные боли, чаще у молодых, связаны со стрессом и не несут риска." },
          { name: "Артериальная гипертензия", prob: 38, note: "Оценивается по дневнику давления — важны регулярные измерения утром и вечером." },
        ],
        plan: [
          "Вести дневник давления: утром и вечером, сидя, после 5 минут покоя — в разделе «Дневник давления».",
          "ЭКГ и консультация кардиолога в плановом порядке.",
          "Ограничить соль до 5 г/сутки, кофеин — до 1–2 чашек в первой половине дня.",
          "Регулярная аэробная нагрузка 30 минут в день, если нет противопоказаний.",
        ],
        redFlags: ["Давящая боль за грудиной дольше 10–15 минут с потом и одышкой — немедленно 103/112", "Давление выше 180/110 с головной болью", "Обморок"],
        specialist: "кардиолог",
        selfCare: ["Спокойно сесть, расстегнуть тесную одежду, измерить давление", "Свежий воздух, дыхание 4 секунды вдох — 6 секунд выдох"],
        urgent: false,
      };
    },
  },
  {
    id: "generic",
    title: "Общее самочувствие",
    keys: [],
    specialist: "терапевт",
    questions: [
      "Как давно это беспокоит — дни, недели, месяцы?",
      "Что усиливает и что облегчает состояние?",
      "Есть ли температура, потеря веса, сильная слабость?",
      "Какие хронические заболевания у вас есть и какие лекарства принимаете постоянно?",
      "Обращались ли уже к врачу с этим и какие обследования проходили?",
    ],
    conclude: () => ({
      diagnoses: [
        { name: "Функциональное расстройство / реакция на перегрузку", prob: 46, note: "Наиболее частая причина неспецифических жалоб при сохранных анализах." },
        { name: "Проявление хронического состояния", prob: 30, note: "Стоит сопоставить с имеющимися диагнозами и динамикой ваших анализов." },
      ],
      plan: [
        "Зафиксировать жалобы в дневнике: когда возникает, что провоцирует.",
        "Сдать базовые анализы, если их нет за последний год: общий анализ крови, глюкоза, ферритин, витамин D, ТТГ.",
        "Плановый приём терапевта с результатами дневника и анализов.",
      ],
      redFlags: ["Немотивированная потеря веса более 5% за полгода", "Длительная температура 37,2–38 без причины", "Усиление симптомов несмотря на отдых"],
      specialist: "терапевт",
      selfCare: ["Сон 7–8 часов, регулярные приёмы пищи", "Умеренная физическая активность", "Достаточное потребление воды"],
      urgent: false,
    }),
  },
];

function pickFlow(complaint: string): Flow {
  const t = complaint.toLowerCase();
  let best: Flow = FLOWS[FLOWS.length - 1];
  let bestScore = 0;
  for (const f of FLOWS) {
    const score = f.keys.reduce((s, k) => s + (t.includes(k) ? 1 : 0), 0);
    if (score > bestScore) {
      best = f;
      bestScore = score;
    }
  }
  return best;
}

// ── Персонализация по данным пользователя ───────────────────────────────
async function userContext(userId: number): Promise<string[]> {
  try {
    const db = getDb();
    const [bs, ms, docs] = await Promise.all([
      db.select().from(biomarkers).where(or(isNull(biomarkers.userId), eq(biomarkers.userId, userId))),
      db.select().from(measurements).where(eq(measurements.userId, userId)),
      db.select().from(documents).where(eq(documents.userId, userId)).orderBy(desc(documents.docDate)),
    ]);
    const lines: string[] = [];
    const analyses = bs.map((b) => analyzeBiomarker(b, ms.filter((m) => m.biomarkerId === Number(b.id))));
    const abnormal = analyses.filter((a) => a.latest && a.status !== "normal").slice(0, 5);
    for (const a of abnormal) {
      lines.push(`По вашим анализам: ${a.biomarker.name} — ${a.latest?.value} ${a.biomarker.unit} (${a.status === "high" ? "выше" : "ниже"} нормы).`);
    }
    if (docs.length) {
      lines.push(`В системе ${docs.length} документ(ов), последний — «${docs[0].title}» от ${String(docs[0].docDate).slice(0, 10)}.`);
    }
    return lines;
  } catch {
    return [];
  }
}

function conclusionText(c: Conclusion, flow: Flow, personal: string[]): string {
  const d = c.diagnoses
    .map((x) => `**${x.name} — ${x.prob}%**\n${x.note}`)
    .join("\n\n");
  const plan = c.plan.map((p, i) => `${i + 1}. ${p}`).join("\n");
  const flags = c.redFlags.map((f) => `• ${f}`).join("\n");
  const care = c.selfCare.map((f) => `• ${f}`).join("\n");
  const pers = personal.length ? `\n\n**Учтены ваши данные:**\n${personal.map((p) => `• ${p}`).join("\n")}` : "";
  return (
    `**Заключение по теме «${flow.title}»**\n\n**Наиболее вероятные причины:**\n\n${d}\n\n**План действий:**\n${plan}\n\n**Что можно сделать уже сейчас:**\n${care}\n\n**Красные флаги — при них не откладывайте обращение за помощью:**\n${flags}\n\n**К кому обращаться:** ${c.specialist}.` +
    pers +
    `\n\n_Это предварительная оценка, а не диагноз. Окончательное заключение может дать только врач на очном приёме._`
  );
}

export const aiDoctorRouter = createRouter({
  // Начало консультации
  start: userProcedure
    .input(z.object({ complaint: z.string().min(2).max(2000) }))
    .mutation(async ({ ctx, input }) => {
      const flow = pickFlow(input.complaint);
      const id = `s${Date.now().toString(36)}-${seq++}`;
      const greeting =
        `Здравствуйте! Я ИИ-доктор системы «AI Врач». Вы написали: «${input.complaint.slice(0, 300)}».\n\n` +
        `Чтобы точнее оценить ситуацию, задам несколько уточняющих вопросов — это займёт около минуты.`;
      const firstQ = flow.questions[0];
      const s: Session = {
        id,
        complaint: input.complaint,
        flow,
        step: 0,
        answers: [],
        history: [
          { role: "ai", text: greeting },
          { role: "user", text: input.complaint },
          { role: "ai", text: `**Вопрос 1 из ${flow.questions.length}:**\n${firstQ}` },
        ],
        createdAt: Date.now(),
        userId: ctx.user.id,
      };
      sessions.set(id, s);
      // Чистим старые сессии
      for (const [k, v] of sessions) if (Date.now() - v.createdAt > 6 * 3600_000) sessions.delete(k);
      return { sessionId: id, messages: [greeting, `**Вопрос 1 из ${flow.questions.length}:**\n${firstQ}`], done: false };
    }),

  // Ответ на вопрос / продолжение диалога
  reply: userProcedure
    .input(z.object({ sessionId: z.string(), message: z.string().min(1).max(2000) }))
    .mutation(async ({ ctx, input }) => {
      const s = sessions.get(input.sessionId);
      if (!s || s.userId !== ctx.user.id) return { messages: ["Сессия устарела. Начните консультацию заново."], done: true, conclusion: null };
      s.answers.push(input.message);
      s.history.push({ role: "user", text: input.message });
      s.step += 1;
      if (s.step < s.flow.questions.length) {
        const q = `**Вопрос ${s.step + 1} из ${s.flow.questions.length}:**\n${s.flow.questions[s.step]}`;
        s.history.push({ role: "ai", text: q });
        return { messages: [q], done: false, conclusion: null };
      }
      // Заключение
      const personal = await userContext(ctx.user.id);
      const concl = s.flow.conclude(s.complaint, s.answers);
      const text = conclusionText(concl, s.flow, personal);
      const closing =
        "Консультация завершена. Если появятся красные флаги или состояние ухудшится — обратитесь за медицинской помощью, не дожидаясь новой консультации.";
      s.history.push({ role: "ai", text }, { role: "ai", text: closing });
      sessions.delete(input.sessionId);
      return {
        messages: [text, closing],
        done: true,
        conclusion: {
          specialist: concl.specialist,
          urgent: concl.urgent,
          diagnoses: concl.diagnoses,
          redFlags: concl.redFlags,
          plan: concl.plan,
        },
      };
    }),

  // Быстрый разбор состояния по загруженным данным
  stateSummary: userProcedure.query(async ({ ctx }) => {
    const personal = await userContext(ctx.user.id);
    const db = getDb();
    const [bs, ms] = await Promise.all([
      db.select().from(biomarkers).where(or(isNull(biomarkers.userId), eq(biomarkers.userId, ctx.user.id))),
      db.select().from(measurements).where(eq(measurements.userId, ctx.user.id)),
    ]);
    const analyses = bs.map((b) => analyzeBiomarker(b, ms.filter((m) => m.biomarkerId === Number(b.id))));
    const abnormal = analyses.filter((a) => a.latest && a.status !== "normal");
    return {
      totalBiomarkers: analyses.filter((a) => a.latest).length,
      abnormalCount: abnormal.length,
      abnormal: abnormal.slice(0, 8).map((a) => ({
        name: a.biomarker.name,
        value: a.latest?.value,
        unit: a.biomarker.unit,
        status: a.status,
      })),
      notes: personal,
    };
  }),
});
