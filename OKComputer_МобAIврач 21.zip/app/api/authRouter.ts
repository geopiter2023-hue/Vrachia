import { z } from "zod";
import crypto from "node:crypto";
import { TRPCError } from "@trpc/server";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { users, sessions, otpCodes, userConsents } from "@db/schema";
import { and, desc, eq, gt } from "drizzle-orm";
import { SESSION_DAYS, ensureAuthTables, getSessionUser, sessionCookie, createSession, readSessionToken } from "./session";

// Реэкспорт для обратной совместимости импортов
export { ensureAuthTables, getSessionUser } from "./session";

const CODE_TTL_MIN = 10;

// ── Утилиты ───────────────────────────────────────────────────────────────
function hashCode(code: string, identifier: string): string {
  const secret = process.env.APP_SECRET ?? "ai-vrach";
  return crypto.createHash("sha256").update(`${code}:${identifier}:${secret}`).digest("hex");
}

// ── Отправка кода: email (SMTP) / SMS (SMS Aero) ──────────────────────────
async function sendEmailCode(to: string, code: string): Promise<{ ok: boolean; reason?: string }> {
  const { SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_FROM } = process.env as Record<string, string | undefined>;
  if (!SMTP_HOST) return { ok: false, reason: "smtp_not_configured" };
  try {
    const { createRequire } = await import("node:module");
    const require = createRequire(import.meta.url);
    const nodemailer = require("nodemailer");
    const transport = nodemailer.createTransport({
      host: SMTP_HOST,
      port: Number(SMTP_PORT ?? 465),
      secure: Number(SMTP_PORT ?? 465) === 465,
      auth: SMTP_USER ? { user: SMTP_USER, pass: SMTP_PASS } : undefined,
    });
    await transport.sendMail({
      from: SMTP_FROM ?? SMTP_USER ?? "no-reply@vrachia.ru",
      to,
      subject: `${code} — код входа в AI Врач`,
      text: `Ваш код входа: ${code}\n\nОн действует ${CODE_TTL_MIN} минут. Если вы не запрашивали код — просто игнорируйте это письмо.`,
    });
    return { ok: true };
  } catch (e) {
    console.error("SMTP send failed:", e);
    return { ok: false, reason: "smtp_failed" };
  }
}

async function sendSmsCode(phone: string, code: string): Promise<{ ok: boolean; reason?: string }> {
  const { SMSAERO_EMAIL, SMSAERO_API_KEY } = process.env as Record<string, string | undefined>;
  if (!SMSAERO_EMAIL || !SMSAERO_API_KEY) return { ok: false, reason: "sms_not_configured" };
  try {
    const auth = Buffer.from(`${SMSAERO_EMAIL}:${SMSAERO_API_KEY}`).toString("base64");
    const resp = await fetch("https://gate.smsaero.ru/v2/sms/send", {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Basic ${auth}` },
      body: JSON.stringify({ number: phone, text: `${code} — код входа в AI Врач`, sign: "SMS Aero" }),
    });
    const j: any = await resp.json();
    return j?.success ? { ok: true } : { ok: false, reason: "sms_failed" };
  } catch (e) {
    console.error("SMS send failed:", e);
    return { ok: false, reason: "sms_failed" };
  }
}

function normalizePhone(p: string): string {
  let d = p.replace(/\D/g, "");
  if (d.startsWith("8")) d = "7" + d.slice(1);
  if (!d.startsWith("7")) d = "7" + d;
  return d;
}

// ── Проверка кода и выдача сессии ─────────────────────────────────────────
async function consumeCode(channel: string, identifier: string, code: string) {
  const db = getDb();
  const rows = await db
    .select()
    .from(otpCodes)
    .where(and(eq(otpCodes.channel, channel), eq(otpCodes.identifier, identifier), gt(otpCodes.expiresAt, new Date())))
    .orderBy(desc(otpCodes.id))
    .limit(1);
  const row = rows[0];
  if (!row) return { ok: false as const, error: "Код не найден или истёк — запросите новый" };
  if (row.attempts >= 5) return { ok: false as const, error: "Слишком много попыток — запросите новый код" };
  if (row.codeHash !== hashCode(code, identifier)) {
    await db.update(otpCodes).set({ attempts: row.attempts + 1 }).where(eq(otpCodes.id, row.id));
    return { ok: false as const, error: "Неверный код" };
  }
  await db.update(otpCodes).set({ verified: true }).where(eq(otpCodes.id, row.id));
  return { ok: true as const };
}

// ── Rate limiting (в памяти процесса) ────────────────────────────────────
const rlBuckets = new Map<string, { count: number; resetAt: number }>();
function rateLimit(key: string, max: number, windowMs: number): { ok: boolean; retryAfterSec: number } {
  const now = Date.now();
  const b = rlBuckets.get(key);
  if (!b || now >= b.resetAt) {
    rlBuckets.set(key, { count: 1, resetAt: now + windowMs });
    return { ok: true, retryAfterSec: 0 };
  }
  if (b.count >= max) return { ok: false, retryAfterSec: Math.ceil((b.resetAt - now) / 1000) };
  b.count += 1;
  return { ok: true, retryAfterSec: 0 };
}
// Периодическая очистка ведёрок
setInterval(() => {
  const now = Date.now();
  for (const [k, b] of rlBuckets) if (now >= b.resetAt) rlBuckets.delete(k);
}, 10 * 60e3).unref?.();

export const authRouter = createRouter({
  // Запрос кода по email или SMS
  requestCode: publicQuery
    .input(z.object({
      channel: z.enum(["email", "phone"]),
      identifier: z.string().min(3).max(255),
    }))
    .mutation(async ({ input }) => {
      await ensureAuthTables();
      const db = getDb();
      const identifier = input.channel === "email"
        ? input.identifier.trim().toLowerCase()
        : normalizePhone(input.identifier);
      if (input.channel === "email" && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(identifier)) {
        return { sent: false, error: "Введите корректный email" };
      }
      if (input.channel === "phone" && identifier.length < 11) {
        return { sent: false, error: "Введите корректный номер телефона" };
      }
      // Антиспам: не более 5 кодов в час на один адрес/номер и не чаще раза в минуту
      const hourly = rateLimit(`otp:h:${input.channel}:${identifier}`, 5, 3600e3);
      if (!hourly.ok) return { sent: false, error: `Слишком много запросов кода — попробуйте через ${Math.ceil(hourly.retryAfterSec / 60)} мин` };
      const cooldown = rateLimit(`otp:c:${input.channel}:${identifier}`, 1, 60e3);
      if (!cooldown.ok) return { sent: false, error: "Код уже отправлен — подождите минуту и запросите снова" };
      const code = String(crypto.randomInt(100000, 999999));
      const expires = new Date(Date.now() + CODE_TTL_MIN * 60e3);
      await db.insert(otpCodes).values({
        channel: input.channel,
        identifier,
        codeHash: hashCode(code, identifier),
        expiresAt: expires,
      });
      const r = input.channel === "email" ? await sendEmailCode(identifier, code) : await sendSmsCode(identifier, code);
      if (!r.ok) {
        return {
          sent: false,
          error: r.reason === "smtp_not_configured"
            ? "Отправка писем пока не настроена на сервере — используйте вход через Telegram"
            : r.reason === "sms_not_configured"
              ? "Отправка SMS пока не настроена на сервере — используйте вход через Telegram"
              : "Не удалось отправить код — попробуйте ещё раз или другой способ",
        };
      }
      return { sent: true, identifier };
    }),

  // Подтверждение кода → сессия
  verifyCode: publicQuery
    .input(z.object({
      channel: z.enum(["email", "phone"]),
      identifier: z.string().min(3).max(255),
      code: z.string().length(6),
    }))
    .mutation(async ({ input, ctx }) => {
      await ensureAuthTables();
      const db = getDb();
      const identifier = input.channel === "email"
        ? input.identifier.trim().toLowerCase()
        : normalizePhone(input.identifier);
      // Антиперебор: не более 10 попыток подтверждения в 10 минут на адрес/номер
      const rl = rateLimit(`otp:v:${input.channel}:${identifier}`, 10, 600e3);
      if (!rl.ok) return { ok: false, error: "Слишком много попыток — попробуйте позже" };
      const chk = await consumeCode(input.channel, identifier, input.code);
      if (!chk.ok) return { ok: false, error: chk.error };

      // Найти или создать пользователя
      const where = input.channel === "email" ? eq(users.email, identifier) : eq(users.phone, identifier);
      let [user] = await db.select().from(users).where(where).limit(1);
      if (!user) {
        const r = await db.insert(users).values(
          input.channel === "email" ? { email: identifier } : { phone: identifier }
        );
        const id = Number((r as any)[0]?.insertId ?? (r as any).insertId);
        [user] = await db.select().from(users).where(eq(users.id, id)).limit(1);
      }
      const token = await createSession(Number(user.id));
      ctx.resHeaders.append("Set-Cookie", sessionCookie(ctx.req, token, SESSION_DAYS * 86400));
      return { ok: true };
    }),

  // Вход через Telegram: выдать код для отправки боту
  telegramStart: publicQuery.mutation(async () => {
    const rl = rateLimit("otp:tg:start", 60, 60e3);
    if (!rl.ok) throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "Слишком много запросов — подождите минуту" });
    await ensureAuthTables();
    const db = getDb();
    const abc = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    let code = "";
    for (let i = 0; i < 6; i++) code += abc[crypto.randomInt(abc.length)];
    const expires = new Date(Date.now() + CODE_TTL_MIN * 60e3);
    await db.insert(otpCodes).values({
      channel: "telegram",
      identifier: code,
      codeHash: hashCode(code, code),
      expiresAt: expires,
    });
    return { code, expiresInMin: CODE_TTL_MIN };
  }),

  // Проверка: подтвердил ли пользователь код в боте → сессия
  telegramCheck: publicQuery
    .input(z.object({ code: z.string().length(6) }))
    .mutation(async ({ input, ctx }) => {
      await ensureAuthTables();
      const db = getDb();
      const code = input.code.toUpperCase();
      const rl = rateLimit(`otp:tg:check:${code}`, 12, 600e3);
      if (!rl.ok) return { ok: false, error: "Слишком много проверок — запросите новый код" };
      const rows = await db
        .select()
        .from(otpCodes)
        .where(and(eq(otpCodes.channel, "telegram"), eq(otpCodes.identifier, code), gt(otpCodes.expiresAt, new Date())))
        .orderBy(desc(otpCodes.id))
        .limit(1);
      const row = rows[0];
      if (!row || !row.verified || !row.tgChatId) return { ok: false, pending: true };

      let [user] = await db.select().from(users).where(eq(users.tgChatId, row.tgChatId)).limit(1);
      if (!user) {
        const r = await db.insert(users).values({ tgChatId: row.tgChatId });
        const id = Number((r as any)[0]?.insertId ?? (r as any).insertId);
        [user] = await db.select().from(users).where(eq(users.id, id)).limit(1);
      }
      const token = await createSession(Number(user.id));
      ctx.resHeaders.append("Set-Cookie", sessionCookie(ctx.req, token, SESSION_DAYS * 86400));
      return { ok: true, pending: false };
    }),

  // Текущий пользователь
  me: publicQuery.query(async ({ ctx }) => {
    const user = await getSessionUser(ctx.req);
    if (!user) return { user: null };
    let hasConsent = false;
    try {
      const db = getDb();
      const c = await db
        .select({ id: userConsents.id })
        .from(userConsents)
        .where(eq(userConsents.userId, Number(user.id)))
        .limit(1);
      hasConsent = c.length > 0;
    } catch { /* ignore */ }
    return {
      user: {
        id: Number(user.id),
        email: user.email,
        phone: user.phone,
        tgChatId: user.tgChatId,
      },
      hasConsent,
    };
  }),

  logout: publicQuery.mutation(async ({ ctx }) => {
    const token = readSessionToken(ctx.req);
    if (token) {
      try {
        await ensureAuthTables();
        await getDb().delete(sessions).where(eq(sessions.token, token));
      } catch { /* ignore */ }
    }
    ctx.resHeaders.append("Set-Cookie", sessionCookie(ctx.req, "", 0));
    return { ok: true };
  }),
});
