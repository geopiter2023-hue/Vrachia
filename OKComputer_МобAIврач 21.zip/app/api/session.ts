// ── Сессии и базовые auth-таблицы (без зависимостей на tRPC, чтобы не было циклов) ──
import crypto from "node:crypto";
import { getDb } from "./queries/connection";
import { users, sessions } from "@db/schema";
import { and, eq, gt, sql } from "drizzle-orm";

export const SESSION_DAYS = 90;
const COOKIE = "ai_vrach_session";

// ── Таблицы (самосоздание) ────────────────────────────────────────────────
let ready = false;
export async function ensureAuthTables() {
  if (ready) return;
  const db = getDb();
  await db.execute(sql.raw(`CREATE TABLE IF NOT EXISTS users (
    id bigint unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
    email varchar(255), phone varchar(32), tg_chat_id varchar(64), tg_username varchar(64),
    created_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_email (email), UNIQUE KEY uq_phone (phone), KEY idx_tg (tg_chat_id)
  )`));
  await db.execute(sql.raw(`CREATE TABLE IF NOT EXISTS sessions (
    id bigint unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
    token varchar(128) NOT NULL,
    user_id bigint unsigned NOT NULL,
    created_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp NOT NULL,
    UNIQUE KEY uq_token (token), KEY idx_user (user_id)
  )`));
  await db.execute(sql.raw(`CREATE TABLE IF NOT EXISTS otp_codes (
    id bigint unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
    channel varchar(16) NOT NULL,
    identifier varchar(255) NOT NULL,
    code_hash varchar(128) NOT NULL,
    attempts int NOT NULL DEFAULT 0,
    verified tinyint(1) NOT NULL DEFAULT 0,
    tg_chat_id varchar(64),
    expires_at timestamp NOT NULL,
    created_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_ident (identifier), KEY idx_channel (channel)
  )`));
  await db.execute(sql.raw(`CREATE TABLE IF NOT EXISTS user_consents (
    id bigint unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
    version varchar(16) NOT NULL,
    user_id bigint unsigned,
    accepted_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
  )`));
  // Миграция старой таблицы согласий без user_id
  try { await db.execute(sql.raw(`ALTER TABLE user_consents ADD COLUMN user_id bigint unsigned`)); } catch { /* уже есть */ }
  ready = true;
}

// ── Утилиты ───────────────────────────────────────────────────────────────
export function newToken(): string {
  return crypto.randomBytes(32).toString("hex");
}

export function readSessionToken(req: Request): string | null {
  const raw = req.headers.get("cookie") ?? "";
  for (const part of raw.split(";")) {
    const [k, ...v] = part.trim().split("=");
    if (k === COOKIE) return decodeURIComponent(v.join("="));
  }
  return null;
}

export async function getSessionUser(req: Request) {
  const token = readSessionToken(req);
  if (!token) return null;
  try {
    await ensureAuthTables();
    const db = getDb();
    const rows = await db
      .select({ id: sessions.id, userId: sessions.userId })
      .from(sessions)
      .where(and(eq(sessions.token, token), gt(sessions.expiresAt, new Date())))
      .limit(1);
    if (!rows.length) return null;
    const u = await db.select().from(users).where(eq(users.id, rows[0].userId)).limit(1);
    if (u[0] && (u[0] as any).blocked) return null; // заблокированный пользователь = неавторизован
    return u[0] ?? null;
  } catch {
    return null;
  }
}

export function sessionCookie(req: Request, token: string, maxAgeSec: number): string {
  const secure = new URL(req.url).protocol === "https:" ? "; Secure" : "";
  return `${COOKIE}=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAgeSec}${secure}`;
}

export async function createSession(userId: number): Promise<string> {
  const db = getDb();
  const token = newToken();
  const expires = new Date(Date.now() + SESSION_DAYS * 864e5);
  await db.insert(sessions).values({ token, userId, expiresAt: expires });
  return token;
}
