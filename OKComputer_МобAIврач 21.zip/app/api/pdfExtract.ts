// ─── Извлечение текста из PDF и распознавание биомаркеров ────────────────
import { PDFParse } from "pdf-parse";

export async function pdfToText(buf: Buffer): Promise<string> {
  try {
    const parser = new PDFParse({ data: buf });
    const res = await parser.getText();
    await parser.destroy().catch(() => {});
    return res.text ?? "";
  } catch {
    return "";
  }
}

// Синонимы/варианты написания популярных показателей → код биомаркера
export const BIOMARKER_SYNONYMS: Record<string, string> = {
  // Общий анализ крови
  "гемоглобин": "HGB", "hemoglobin": "HGB", "hgb": "HGB", "hb": "HGB",
  "эритроциты": "RBC", "rbc": "RBC", "red blood cells": "RBC",
  "лейкоциты": "WBC", "wbc": "WBC", "white blood cells": "WBC",
  "тромбоциты": "PLT", "plt": "PLT", "platelets": "PLT",
  "гематокрит": "HCT", "hct": "HCT", "hematocrit": "HCT",
  "соэ": "ESR", "сое": "ESR", "esr": "ESR", "скорость оседания эритроцитов": "ESR",
  "нейтрофилы": "NEUT", "лимфоциты": "LYMPH", "моноциты": "MONO",
  "эозинофилы": "EO", "базофилы": "BASO",
  "общее количество лейкоцитов": "WBC", "общее количество эритроцитов": "RBC",
  "общее количество тромбоцитов": "PLT",
  "сегментоядерные нейтрофилы": "NEUTSEG", "палочкоядерные нейтрофилы": "NEUTBAND",
  "абсолютное содержание нейтрофилов": "NEUTABS",
  "абсолютное содержание эозинофилов": "EOABS",
  "абсолютное содержание базофилов": "BASOABS",
  "абсолютное содержание моноцитов": "MONOABS",
  "абсолютное содержание лимфоцитов": "LYMPHABS",
  "плазматические клетки": "PLASMA",
  "mcv": "MCV", "средний объем эритроцитов": "MCV", "средний объём эритроцитов": "MCV",
  "mch": "MCH", "mchc": "MCHC", "rdw": "RDW",
  // Биохимия
  "глюкоза": "GLU", "glucose": "GLU", "сахар крови": "GLU", "glu": "GLU",
  "гликированный гемоглобин": "HBA1C", "hba1c": "HBA1C", "hb a1c": "HBA1C",
  "холестерин общий": "CHOL", "общий холестерин": "CHOL", "холестерин": "CHOL",
  "cholesterol": "CHOL", "chol": "CHOL",
  "холестерин лпвп": "HDL", "лпвп": "HDL", "hdl": "HDL", "липопротеиды высокой плотности": "HDL",
  "холестерин лпнп": "LDL", "лпнп": "LDL", "ldl": "LDL", "липопротеиды низкой плотности": "LDL",
  "триглицериды": "TG", "tg": "TG", "triglycerides": "TG",
  "мочевина": "UREA", "urea": "UREA",
  "креатинин": "CREA", "creatinine": "CREA", "crea": "CREA",
  "мочевая кислота": "URIC", "uric acid": "URIC", "uric": "URIC",
  "билирубин общий": "BIL", "общий билирубин": "BIL", "bilirubin": "BIL",
  "билирубин прямой": "DBIL", "прямой билирубин": "DBIL",
  "алт": "ALT", "alt": "ALT", "аланинаминотрансфераза": "ALT",
  "аст": "AST", "ast": "AST", "аспартатаминотрансфераза": "AST",
  "ггт": "GGT", "ggt": "GGT", "гамма-глутамилтрансфераза": "GGT", "гамма гт": "GGT",
  "щелочная фосфатаза": "ALP", "alp": "ALP",
  "общий белок": "TP", "белок общий": "TP", "total protein": "TP",
  "альбумин": "ALB", "albumin": "ALB",
  "железо": "FE", "ferrum": "FE", "сывороточное железо": "FE",
  "цинк": "ZN", "селен": "SE", "медь": "CU",
  "коэффициент атерогенности": "ATHERO", "индекс атерогенности": "ATHERO",
  "ферритин": "FERR", "ferritin": "FERR", "ferr": "FERR",
  "кальций": "CA", "calcium": "CA", "кальций общий": "CA",
  "калий": "K", "potassium": "K",
  "натрий": "NA", "sodium": "NA",
  "магний": "MG", "magnesium": "MG",
  "фосфор": "P", "phosphorus": "P",
  "витамин d": "VITD", "витамин д": "VITD", "25-oh витамин d": "VITD", "25(oh)d": "VITD",
  "vitamin d": "VITD", "vitd": "VITD", "витамин b12": "B12", "витамин в12": "B12",
  "фолиевая кислота": "FOL", "витамин b9": "FOL",
  "амилаза": "AMY", "панкреатическая амилаза": "AMY",
  "липаза": "LIPA",
  "срб": "CRP", "crp": "CRP", "с-реактивный белок": "CRP", "c-реактивный белок": "CRP",
  "прокальцитонин": "PCT",
  "лактат": "LAC",
  // Гормоны
  "ттг": "TSH", "tsh": "TSH", "тиреотропный гормон": "TSH",
  "т4 свободный": "FT4", "ft4": "FT4", "свободный т4": "FT4", "тироксин свободный": "FT4",
  "т3 свободный": "FT3", "ft3": "FT3", "трийодтиронин свободный": "FT3",
  "инсулин": "INS", "insulin": "INS",
  "кортизол": "CORT", "cortisol": "CORT",
  "тестостерон": "TEST", "testosterone": "TEST",
  "эстрадиол": "E2", "estradiol": "E2",
  "прогестерон": "PROG", "пролактин": "PRL", "prolactin": "PRL",
  "лг": "LH", "фсг": "FSH", "fsh": "FSH",
  "паратгормон": "PTH", "pth": "PTH",
  "витамин d (25-он)": "VITD",
  // Коагулограмма
  "мно": "INR", "inr": "INR", "международное нормализованное отношение": "INR",
  "протромбиновое время": "PT", "протромбиновый индекс": "PTI", "протромбин": "PT",
  "аптв": "APTT", "aptt": "APTT",
  "фибриноген": "FIB", "fibrinogen": "FIB",
  "d-димер": "DDIM", "d-dimer": "DDIM", "д-димер": "DDIM",
  // Онкомаркеры
  "пса": "PSA", "psa": "PSA", "пса общий": "PSA",
  "са 125": "CA125", "ca-125": "CA125", "ca125": "CA125",
  "са 15-3": "CA153", "са 19-9": "CA199",
  "рэа": "CEA", "cea": "CEA",
  "афп": "AFP", "afp": "AFP",
  // Моча
  "белок в моче": "UPROT", "глюкоза в моче": "UGLU",
};

// Категории по коду
const CODE_CATEGORY: Record<string, string> = {
  HGB: "Общий анализ крови", RBC: "Общий анализ крови", WBC: "Общий анализ крови",
  PLT: "Общий анализ крови", HCT: "Общий анализ крови", ESR: "Общий анализ крови",
  NEUT: "Общий анализ крови", LYMPH: "Общий анализ крови", MONO: "Общий анализ крови",
  EO: "Общий анализ крови", BASO: "Общий анализ крови", MCV: "Общий анализ крови",
  MCH: "Общий анализ крови", MCHC: "Общий анализ крови", RDW: "Общий анализ крови",
  NEUTSEG: "Общий анализ крови", NEUTBAND: "Общий анализ крови",
  NEUTABS: "Общий анализ крови", EOABS: "Общий анализ крови", BASOABS: "Общий анализ крови",
  MONOABS: "Общий анализ крови", LYMPHABS: "Общий анализ крови", PLASMA: "Общий анализ крови",
  GLU: "Биохимия", HBA1C: "Биохимия", CHOL: "Биохимия", HDL: "Биохимия", LDL: "Биохимия",
  TG: "Биохимия", UREA: "Биохимия", CREA: "Биохимия", URIC: "Биохимия", BIL: "Биохимия",
  DBIL: "Биохимия", ALT: "Биохимия", AST: "Биохимия", GGT: "Биохимия", ALP: "Биохимия",
  TP: "Биохимия", ALB: "Биохимия", FE: "Биохимия", FERR: "Биохимия", CA: "Биохимия",
  ZN: "Биохимия", SE: "Биохимия", CU: "Биохимия", ATHERO: "Биохимия",
  K: "Биохимия", NA: "Биохимия", MG: "Биохимия", P: "Биохимия", VITD: "Витамины",
  B12: "Витамины", FOL: "Витамины", AMY: "Биохимия", LIPA: "Биохимия", CRP: "Биохимия",
  PCT: "Биохимия", LAC: "Биохимия",
  TSH: "Гормоны", FT4: "Гормоны", FT3: "Гормоны", INS: "Гормоны", CORT: "Гормоны",
  TEST: "Гормоны", E2: "Гормоны", PROG: "Гормоны", PRL: "Гормоны", LH: "Гормоны",
  FSH: "Гормоны", PTH: "Гормоны",
  INR: "Коагулограмма", PT: "Коагулограмма", PTI: "Коагулограмма", APTT: "Коагулограмма",
  FIB: "Коагулограмма", DDIM: "Коагулограмма",
  PSA: "Онкомаркеры", CA125: "Онкомаркеры", CA153: "Онкомаркеры", CA199: "Онкомаркеры",
  CEA: "Онкомаркеры", AFP: "Онкомаркеры",
  UPROT: "Анализ мочи", UGLU: "Анализ мочи",
};

export const CODE_DEFAULT_NAME: Record<string, string> = {
  HGB: "Гемоглобин", RBC: "Эритроциты", WBC: "Лейкоциты", PLT: "Тромбоциты",
  HCT: "Гематокрит", ESR: "СОЭ", NEUT: "Нейтрофилы", LYMPH: "Лимфоциты",
  MONO: "Моноциты", EO: "Эозинофилы", BASO: "Базофилы", MCV: "Средний объём эритроцитов (MCV)",
  MCH: "MCH", MCHC: "MCHC", RDW: "RDW",
  NEUTSEG: "Нейтрофилы сегментоядерные", NEUTBAND: "Нейтрофилы палочкоядерные",
  NEUTABS: "Нейтрофилы абс.", EOABS: "Эозинофилы абс.", BASOABS: "Базофилы абс.",
  MONOABS: "Моноциты абс.", LYMPHABS: "Лимфоциты абс.", PLASMA: "Плазматические клетки",
  GLU: "Глюкоза", HBA1C: "Гликированный гемоглобин", CHOL: "Холестерин общий",
  HDL: "Холестерин ЛПВП", LDL: "Холестерин ЛПНП", TG: "Триглицериды",
  UREA: "Мочевина", CREA: "Креатинин", URIC: "Мочевая кислота",
  BIL: "Билирубин общий", DBIL: "Билирубин прямой", ALT: "АЛТ", AST: "АСТ",
  GGT: "ГГТ", ALP: "Щелочная фосфатаза", TP: "Общий белок", ALB: "Альбумин",
  FE: "Железо", FERR: "Ферритин", CA: "Кальций", K: "Калий", NA: "Натрий",
  ZN: "Цинк", SE: "Селен", CU: "Медь", ATHERO: "Коэффициент атерогенности",
  MG: "Магний", P: "Фосфор", VITD: "Витамин D (25-OH)", B12: "Витамин B12",
  FOL: "Фолиевая кислота", AMY: "Амилаза", LIPA: "Липаза", CRP: "С-реактивный белок",
  PCT: "Прокальцитонин", LAC: "Лактат",
  TSH: "ТТГ", FT4: "Т4 свободный", FT3: "Т3 свободный", INS: "Инсулин",
  CORT: "Кортизол", TEST: "Тестостерон", E2: "Эстрадиол", PROG: "Прогестерон",
  PRL: "Пролактин", LH: "ЛГ", FSH: "ФСГ", PTH: "Паратгормон",
  INR: "МНО", PT: "Протромбиновое время", PTI: "Протромбиновый индекс",
  APTT: "АПТВ", FIB: "Фибриноген", DDIM: "D-димер",
  PSA: "ПСА общий", CA125: "СА 125", CA153: "СА 15-3", CA199: "СА 19-9",
  CEA: "РЭА", AFP: "АФП", UPROT: "Белок в моче", UGLU: "Глюкоза в моче",
};

export const CODE_DEFAULT_UNIT: Record<string, string> = {
  HGB: "г/л", RBC: "10¹²/л", WBC: "10⁹/л", PLT: "10⁹/л", HCT: "%", ESR: "мм/ч",
  NEUT: "%", LYMPH: "%", MONO: "%", EO: "%", BASO: "%", MCV: "фл", MCH: "пг", MCHC: "г/л", RDW: "%",
  GLU: "ммоль/л", HBA1C: "%", CHOL: "ммоль/л", HDL: "ммоль/л", LDL: "ммоль/л",
  TG: "ммоль/л", UREA: "ммоль/л", CREA: "мкмоль/л", URIC: "мкмоль/л",
  BIL: "мкмоль/л", DBIL: "мкмоль/л", ALT: "Ед/л", AST: "Ед/л", GGT: "Ед/л",
  ALP: "Ед/л", TP: "г/л", ALB: "г/л", FE: "мкмоль/л", FERR: "мкг/л",
  ZN: "мкмоль/л", SE: "мкмоль/л", CU: "мкмоль/л", ATHERO: "",
  NEUTSEG: "%", NEUTBAND: "%", NEUTABS: "10⁹/л", EOABS: "10⁹/л",
  BASOABS: "10⁹/л", MONOABS: "10⁹/л", LYMPHABS: "10⁹/л", PLASMA: "%",
  CA: "ммоль/л", K: "ммоль/л", NA: "ммоль/л", MG: "ммоль/л", P: "ммоль/л",
  VITD: "нг/мл", B12: "пг/мл", FOL: "нг/мл", AMY: "Ед/л", LIPA: "Ед/л",
  CRP: "мг/л", PCT: "нг/мл", LAC: "ммоль/л",
  TSH: "мМЕ/л", FT4: "пмоль/л", FT3: "пмоль/л", INS: "мкМЕ/мл",
  CORT: "нмоль/л", TEST: "нмоль/л", E2: "пг/мл", PROG: "нг/мл", PRL: "мМЕ/л",
  LH: "МЕ/л", FSH: "МЕ/л", PTH: "пг/мл",
  INR: "", PT: "сек", PTI: "%", APTT: "сек", FIB: "г/л", DDIM: "мкг/л",
  PSA: "нг/мл", CA125: "Ед/мл", CA153: "Ед/мл", CA199: "Ед/мл", CEA: "нг/мл", AFP: "МЕ/мл",
  UPROT: "г/л", UGLU: "ммоль/л",
};

export function codeCategory(code: string): string {
  return CODE_CATEGORY[code] ?? "Прочее";
}

const UNIT_RE = "(?:ммоль/л|мкмоль/л|г/л|мг/л|мкг/л|нг/мл|пг/мл|Ед/л|МЕ/л|мМЕ/л|мкМЕ/мл|МЕ/мл|Ед/мл|мм/ч|фл|пг|сек|10[¹^]?[29]/л|10[¹^]?12/л|ммоль|%)";

export type ExtractedBiomarker = {
  code: string;
  name: string;
  value: number;
  unit: string;
  refLow: number | null;
  refHigh: number | null;
  category: string;
};

// Нормализация текста из PDF
function normalize(text: string): string {
  return text
    .replace(/\u00a0/g, " ")
    .replace(/−/g, "-")
    .replace(/,/g, ".")
    // "ЛПВП-холестерин" → "лпвпхолестерин": дефис между кириллическими буквами убираем
    .replace(/(?<=[а-яё])-(?=[а-яё])/gi, "")
    .replace(/[ \t]+/g, " ");
}

// Сортировка синонимов: длинные фразы первыми ("холестерин лпвп" раньше "холестерин")
const SORTED_KEYS = Object.keys(BIOMARKER_SYNONYMS)
  .filter((k) => !k.includes("(") && !k.includes(")"))
  .sort((a, b) => b.length - a.length);

// Хвосты названий в скобках: "витамин d" + "(25-oh)" должны совпасть
function matchKey(low: string, idx: number, key: string): number {
  // возвращает длину совпавшего фрагмента в исходной строке (с учётом регистра hay)
  let len = key.length;
  const after = low.slice(idx + len, idx + len + 40);
  const tail = after.match(/^\s*\(([^)]{1,25})\)/);
  if (tail) {
    const inner = tail[1].toLowerCase().trim();
    // скобка с текстом (25-oh, скрининг и т.п.) — часть названия; с цифрой — референс, пропускаем
    if (/[a-zа-я]/.test(inner)) {
      // внутри скобки не должно быть значения показателя: следующий токен — не число со значением
      const innerHasValue = /\d+\s*-\s*\d+/.test(inner) && !/oh|d|hb|а1c|скр/i.test(inner);
      if (!innerHasValue) len += tail[0].length;
    }
  }
  return len;
}

export function extractBiomarkersFromText(text: string): ExtractedBiomarker[] {
  const norm = normalize(text);
  const lines = norm.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  const found = new Map<string, ExtractedBiomarker>();
  const spans: { start: number; end: number }[] = [];

  const tryMatch = (hay: string): void => {
    const low = hay.toLowerCase();
    for (const key of SORTED_KEYS) {
      const code = BIOMARKER_SYNONYMS[key];
      if (found.has(code)) continue;
      const idx = low.indexOf(key);
      if (idx < 0) continue;
      // не матчим ключ внутри уже распознанного более длинного названия
      if (spans.some((s) => idx >= s.start && idx < s.end)) continue;
      // не матчим ключ в середине слова ("холестерин" внутри "лпвпхолестерин")
      if (idx > 0 && /[a-zа-яё]/i.test(low[idx - 1])) continue;
      const matchedLen = matchKey(low, idx, key);
      // после названия ищем: [ед] значение [ед] [референс a - b]
      const rest = hay.slice(idx + matchedLen, idx + matchedLen + 120);
      const m = rest.match(
        new RegExp(`^[^0-9<>-]{0,25}(?:${UNIT_RE})?[^0-9<>-]{0,10}(<?|>?)\\s*(\\d+(?:\\.\\d+)?)\\s*(${UNIT_RE})?(?:[^0-9]{0,15}(\\d+(?:\\.\\d+)?)\\s*(?:-|–|—)\\s*(\\d+(?:\\.\\d+)?))?`, "i")
      );
      if (!m) continue;
      const value = parseFloat(m[2]);
      if (isNaN(value)) continue;
      const unit = (m[3] ?? CODE_DEFAULT_UNIT[code] ?? "").trim();
      const refLow = m[4] != null ? parseFloat(m[4]) : null;
      const refHigh = m[5] != null ? parseFloat(m[5]) : null;
      spans.push({ start: idx, end: idx + matchedLen });
      found.set(code, {
        code,
        name: CODE_DEFAULT_NAME[code] ?? key,
        value,
        unit: unit || CODE_DEFAULT_UNIT[code] || "",
        refLow: refLow != null && !isNaN(refLow) ? refLow : null,
        refHigh: refHigh != null && !isNaN(refHigh) ? refHigh : null,
        category: codeCategory(code),
      });
    }
  };

  for (const line of lines) tryMatch(line);

  // Дубль-проход по всему тексту (на случай склеенных строк)
  tryMatch(norm.replace(/\r?\n/g, ". "));

  return [...found.values()];
}
