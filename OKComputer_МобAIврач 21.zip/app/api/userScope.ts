// ─── Мультитенантность: user_id во всех пользовательских таблицах ────────
// Самолечащаяся миграция: при первом обращении добавляет колонку user_id
// и индекс во все таблицы, где их ещё нет. Существующие строки (NULL)
// наследует первый вошедший пользователь.
import { getDb } from "./queries/connection";
import { sql } from "drizzle-orm";

// [таблица, создавать ли индекс idx_user]
const USER_TABLES: [string, boolean][] = [
  ["documents", true],
  ["document_files", true],
  ["biomarkers", true],
  ["measurements", true],
  ["vitals", true],
  ["notifications", true],
  ["audit_log", true],
  ["pets", true],
  ["pet_events", true],
  ["family_members", true],
  ["family_documents", true],
  ["family_measurements", true],
  ["bp_entries", true],
  ["wellness_checks", true],
  ["user_achievements", true],
  ["bot_links", true],
  ["medications", true],
  ["medication_logs", true],
  ["health_points", true],
  ["user_consents", true],
];

let scopeReady = false;
const scopePromise: { p: Promise<void> | null } = { p: null };

async function doMigrate() {
  const db = getDb();
  for (const [table, withIndex] of USER_TABLES) {
    try {
      await db.execute(sql.raw(`ALTER TABLE ${table} ADD COLUMN user_id bigint unsigned NULL`));
    } catch { /* колонка уже есть или таблицы нет */ }
    if (withIndex) {
      try {
        await db.execute(sql.raw(`CREATE INDEX idx_user ON ${table} (user_id)`));
      } catch { /* индекс уже есть */ }
    }
  }
  // Уникальные ключи, которые были глобальными, становятся per-user
  // wellness_checks: было UNIQUE(check_date) → UNIQUE(user_id, check_date)
  try { await db.execute(sql.raw(`ALTER TABLE wellness_checks DROP INDEX uq_wellness_date`)); } catch { }
  try { await db.execute(sql.raw(`CREATE UNIQUE INDEX uq_wellness_user_date ON wellness_checks (user_id, check_date)`)); } catch { }
  // user_achievements: было UNIQUE(code) → UNIQUE(user_id, code)
  try { await db.execute(sql.raw(`ALTER TABLE user_achievements DROP INDEX code`)); } catch { }
  try { await db.execute(sql.raw(`CREATE UNIQUE INDEX uq_ach_user_code ON user_achievements (user_id, code)`)); } catch { }
  // Ключевые индексы под выборки пользователя
  const compositeIndexes: [string, string][] = [
    ["measurements", "CREATE INDEX idx_meas_user_date ON measurements (user_id, measured_at)"],
    ["vitals", "CREATE INDEX idx_vitals_user_date ON vitals (user_id, measured_at)"],
    ["bp_entries", "CREATE INDEX idx_bp_user_date ON bp_entries (user_id, measured_at)"],
    ["documents", "CREATE INDEX idx_docs_user_date ON documents (user_id, doc_date)"],
    ["notifications", "CREATE INDEX idx_notif_user ON notifications (user_id, is_read)"],
    ["medication_logs", "CREATE INDEX idx_medlog_user ON medication_logs (user_id, medication_id)"],
    ["health_points", "CREATE INDEX idx_points_user ON health_points (user_id, action)"],
  ];
  for (const [, ddl] of compositeIndexes) {
    try { await db.execute(sql.raw(ddl)); } catch { /* уже есть */ }
  }
}

export function ensureUserScope(): Promise<void> {
  if (scopeReady) return Promise.resolve();
  if (!scopePromise.p) {
    scopePromise.p = doMigrate().then(() => { scopeReady = true; }).catch(() => {
      scopePromise.p = null; // повторим при следующем вызове
    });
  }
  return scopePromise.p;
}

// Привязка «сиротских» данных (user_id IS NULL) к первому вошедшему пользователю.
// Идемпотентно: после первого вызова массовых UPDATE не выполняется.
const claimedUsers = new Set<number>();
export async function claimLegacyData(userId: number): Promise<void> {
  if (claimedUsers.has(userId)) return;
  claimedUsers.add(userId);
  try {
    const db = getDb();
    for (const [table] of USER_TABLES) {
      try {
        await db.execute(sql.raw(`UPDATE ${table} SET user_id = ${Number(userId)} WHERE user_id IS NULL`));
      } catch { /* таблица может отсутствовать */ }
    }
  } catch { /* не критично */ }
}
