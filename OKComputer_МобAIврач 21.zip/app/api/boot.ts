import { Hono } from "hono";
import { bodyLimit } from "hono/body-limit";
import type { HttpBindings } from "@hono/node-server";
import { fetchRequestHandler } from "@trpc/server/adapters/fetch";
import { appRouter } from "./router";
import { createContext } from "./context";
import { env } from "./lib/env";

const app = new Hono<{ Bindings: HttpBindings }>();

app.use(bodyLimit({ maxSize: 50 * 1024 * 1024 }));
app.use("/api/trpc/*", async (c) => {
  return fetchRequestHandler({
    endpoint: "/api/trpc",
    req: c.req.raw,
    router: appRouter,
    createContext,
  });
});
app.get("/api/documents/:id/file", async (c) => {
  const id = Number(c.req.param("id"));
  if (!Number.isFinite(id)) return c.json({ error: "Bad id" }, 400);
  const { getDb } = await import("./queries/connection");
  const { documents, documentFiles } = await import("@db/schema");
  const { eq, asc } = await import("drizzle-orm");
  const db = getDb();
  const [doc] = await db.select().from(documents).where(eq(documents.id, id));
  if (!doc) return c.json({ error: "Файл не найден" }, 404);
  let base64 = doc.fileData ?? "";
  if (!base64) {
    const chunks = await db
      .select({ data: documentFiles.data })
      .from(documentFiles)
      .where(eq(documentFiles.docId, id))
      .orderBy(asc(documentFiles.chunk));
    base64 = chunks.map((r) => r.data).join("");
  }
  if (!base64) return c.json({ error: "Файл не найден" }, 404);
  const buf = Buffer.from(base64, "base64");
  const mime = doc.fileMime || "application/octet-stream";
  const name = encodeURIComponent(doc.fileName || `document-${id}`);
  return new Response(new Uint8Array(buf), {
    headers: {
      "Content-Type": mime,
      "Content-Length": String(buf.length),
      "Content-Disposition": `inline; filename*=UTF-8''${name}`,
      "Cache-Control": "private, max-age=3600",
    },
  });
});

// Вебхук мессенджер-бота (Telegram-совместимый формат + простой JSON)
app.post("/api/bot/webhook", async (c) => {
  try {
    const body = await c.req.json().catch(() => ({}));
    // Telegram update: { message: { chat: { id }, text, from: { username } } }
    const msg = body.message ?? body;
    const chatId = String(msg?.chat?.id ?? msg?.chatId ?? "");
    const text = String(msg?.text ?? "");
    const username = msg?.from?.username ?? msg?.username;
    if (!chatId || !text) return c.json({ ok: true });
    const { handleBotMessage } = await import("./botRouter");
    const reply = await handleBotMessage(chatId, text, username);
    // Если задан BOT_TOKEN — отправляем ответ в Telegram; иначе возвращаем в JSON
    const token = process.env.BOT_TOKEN;
    if (token) {
      await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ chat_id: chatId, text: reply }),
      }).catch(() => {});
    }
    return c.json({ ok: true, reply: token ? undefined : reply });
  } catch {
    return c.json({ ok: true });
  }
});

app.all("/api/*", (c) => c.json({ error: "Not Found" }, 404));

export default app;

if (env.isProduction) {
  const { serve } = await import("@hono/node-server");
  const { serveStaticFiles } = await import("./lib/vite");
  serveStaticFiles(app);

  const port = parseInt(process.env.PORT || "3000");
  serve({ fetch: app.fetch, port }, () => {
    console.log(`Server running on http://localhost:${port}/`);
    // Сначала миграция user_id во все таблицы данных, потом фоновые задачи
    import("./userScope")
      .then(async (s) => {
        await s.ensureUserScope().catch(() => {});
        // Умные напоминания: контроль отклонений, пропуски измерений, серии чек-инов
        import("./wellnessRouter")
          .then((m) => {
            void m.generateSmartReminders().catch(() => {});
            setInterval(() => void m.generateSmartReminders().catch(() => {}), 12 * 3600 * 1000);
          })
          .catch(() => {});
        // Напоминания о приёме лекарств — каждую минуту сверяем расписание
        import("./botRouter")
          .then((m) => {
            setInterval(() => void m.checkMedicationReminders().catch(() => {}), 60 * 1000);
          })
          .catch(() => {});
      })
      .catch(() => {});
  });
}
