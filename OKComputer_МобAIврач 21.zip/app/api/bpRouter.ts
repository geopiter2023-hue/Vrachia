import { z } from "zod";
import { createRouter, userProcedure } from "./middleware";
import { getDb } from "./queries/connection";
import { bpEntries, vitals, notifications, auditLog } from "@db/schema";
import { and, desc, eq, gte } from "drizzle-orm";

export const bpRouter = createRouter({
  list: userProcedure
    .input(z.object({ days: z.number().default(365) }))
    .query(async ({ input, ctx }) => {
      const since = new Date(Date.now() - input.days * 864e5);
      return getDb()
        .select()
        .from(bpEntries)
        .where(and(eq(bpEntries.userId, ctx.user.id), gte(bpEntries.measuredAt, since)))
        .orderBy(desc(bpEntries.measuredAt))
        .limit(1000);
    }),

  add: userProcedure
    .input(
      z.object({
        sys: z.number().int().min(50).max(300),
        dia: z.number().int().min(30).max(200),
        pulse: z.number().int().min(20).max(250).optional(),
        arm: z.enum(["left", "right"]).default("left"),
        wellbeing: z.enum(["none", "great", "good", "ok", "bad"]).default("none"),
        note: z.string().max(1000).optional(),
        measuredAt: z.string(), // ISO
      })
    )
    .mutation(async ({ input, ctx }) => {
      const db = getDb();
      const userId = ctx.user.id;
      const at = new Date(input.measuredAt);
      await db.insert(bpEntries).values({
        userId,
        sys: input.sys,
        dia: input.dia,
        pulse: input.pulse ?? null,
        arm: input.arm,
        wellbeing: input.wellbeing,
        note: input.note || null,
        measuredAt: at,
      });
      // Дублируем в общие физиологические показатели — чтобы работали аналитика и рекомендации
      const rows: (typeof vitals.$inferInsert)[] = [
        { userId, vitalType: "pressure_sys", value: input.sys, measuredAt: at, source: "diary" },
        { userId, vitalType: "pressure_dia", value: input.dia, measuredAt: at, source: "diary" },
      ];
      if (input.pulse) rows.push({ userId, vitalType: "pulse", value: input.pulse, measuredAt: at, source: "diary" });
      await db.insert(vitals).values(rows);
      await db.insert(auditLog).values({
        userId,
        action: "bp_entry",
        detail: `Дневник давления: ${input.sys}/${input.dia}${input.pulse ? `, пульс ${input.pulse}` : ""}`,
      });
      const { awardPoints } = await import("./botRouter");
      await awardPoints("bp_entry", 5, `${input.sys}/${input.dia}`, userId);
      if (input.sys >= 160 || input.dia >= 100) {
        await db.insert(notifications).values({
          userId,
          title: "Высокое артериальное давление",
          body: `Запись в дневнике: ${input.sys}/${input.dia} мм рт. ст. — критическое значение.`,
          severity: "critical",
        });
      }
      return { ok: true };
    }),

  remove: userProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input, ctx }) => {
      await getDb().delete(bpEntries)
        .where(and(eq(bpEntries.id, input.id), eq(bpEntries.userId, ctx.user.id)));
      return { ok: true };
    }),

  stats: userProcedure.query(async ({ ctx }) => {
    const rows = await getDb()
      .select()
      .from(bpEntries)
      .where(and(eq(bpEntries.userId, ctx.user.id), gte(bpEntries.measuredAt, new Date(Date.now() - 90 * 864e5))))
      .orderBy(desc(bpEntries.measuredAt));
    if (!rows.length) return null;
    const avg = (f: (r: (typeof rows)[0]) => number | null) => {
      const vals = rows.map(f).filter((v): v is number => v != null);
      return vals.length ? Math.round(vals.reduce((a, b) => a + b, 0) / vals.length) : null;
    };
    const maxSys = Math.max(...rows.map((r) => r.sys));
    const high = rows.filter((r) => r.sys >= 140 || r.dia >= 90).length;
    return {
      count: rows.length,
      avgSys: avg((r) => r.sys),
      avgDia: avg((r) => r.dia),
      avgPulse: avg((r) => r.pulse),
      maxSys,
      highCount: high,
      highPct: Math.round((high / rows.length) * 100),
    };
  }),
});
