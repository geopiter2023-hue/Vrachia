// ─── Кабинет администратора платформы ────────────────────────────────────
// Доступ: email/пароль из env ADMIN_EMAILS / ADMIN_PASSWORD (список через запятую).
// Админ НЕ имеет доступа к медданным пользователей — только агрегаты и
// техническая информация (соответствие ФЗ-152).
import { z } from "zod";
import crypto from "node:crypto";
import { TRPCError } from "@trpc/server";
import { createRouter, publicQuery, t } from "./middleware";
import { getDb } from "./queries/connection";
import { sql } from "drizzle-orm";
import { ensurePlatformTables } from "./platformTables";

const ADMIN_COOKIE = "ai_vrach_admin";
const SESSION_DAYS = 7;

function adminUsers(): Array<{ email: string; password: string }> {
  const emails = (process.env.ADMIN_EMAILS ?? "").split(",").map((s) => s.trim().toLowerCase()).filter(Boolean);
  const passwords = (process.env.ADMIN_PASSWORD ?? "").split(",").map((s) => s.trim());
  return emails.map((email, i) => ({ email, password: passwords[i] ?? passwords[0] ?? "" }));
}

let ready = false;
async function ensureAdminTables() {
  if (ready) return;
  await ensurePlatformTables();
  const db = getDb();
  await db.execute(sql.raw(`CREATE TABLE IF NOT EXISTS admin_sessions (
    id bigint unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
    token varchar(128) NOT NULL,
    email varchar(255) NOT NULL,
    created_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp NOT NULL,
    UNIQUE KEY uq_token (token)
  )`));
  // Модерация клиник и блокировки пользователей — мягкие ALTER
  try { await db.execute(sql.raw(`ALTER TABLE clinic_profiles ADD COLUMN moderation varchar(16) NOT NULL DEFAULT 'pending'`)); } catch { /* есть */ }
  try { await db.execute(sql.raw(`ALTER TABLE clinic_accounts ADD COLUMN blocked tinyint(1) NOT NULL DEFAULT 0`)); } catch { /* есть */ }
  try { await db.execute(sql.raw(`ALTER TABLE users ADD COLUMN blocked tinyint(1) NOT NULL DEFAULT 0`)); } catch { /* есть */ }
  // Уже опубликованные клиники считаем одобренными (миграция)
  try { await db.execute(sql.raw(`UPDATE clinic_profiles SET moderation = 'approved' WHERE is_published = 1 AND moderation = 'pending'`)); } catch { /* ok */ }
  ready = true;
}

function readAdminToken(req: Request): string | null {
  const raw = req.headers.get("cookie") ?? "";
  for (const part of raw.split(";")) {
    const [k, ...v] = part.trim().split("=");
    if (k === ADMIN_COOKIE) return decodeURIComponent(v.join("="));
  }
  return null;
}

function adminCookie(req: Request, token: string, maxAgeSec: number): string {
  const secure = new URL(req.url).protocol === "https:" ? "; Secure" : "";
  return `${ADMIN_COOKIE}=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAgeSec}${secure}`;
}

async function getAdmin(req: Request): Promise<{ email: string } | null> {
  const token = readAdminToken(req);
  if (!token) return null;
  try {
    await ensureAdminTables();
    const db = getDb();
    const rows = await db.execute(sql.raw(
      `SELECT email FROM admin_sessions WHERE token = '${token.replace(/'/g, "")}' AND expires_at > NOW() LIMIT 1`
    ));
    const list = (rows as any)[0] as any[];
    return list?.length ? { email: list[0].email } : null;
  } catch {
    return null;
  }
}

const adminProcedure = t.procedure.use(async ({ ctx, next }) => {
  const admin = await getAdmin(ctx.req);
  if (!admin) throw new TRPCError({ code: "UNAUTHORIZED", message: "Требуется вход администратора" });
  return next({ ctx: { ...ctx, admin } });
});

// Хелпер для сырых запросов
async function q<T = any>(query: string): Promise<T[]> {
  const rows = await getDb().execute(sql.raw(query));
  return ((rows as any)[0] ?? []) as T[];
}

export const adminRouter = createRouter({
  // ── Вход ───────────────────────────────────────────────────────────────
  login: publicQuery
    .input(z.object({ email: z.string().email(), password: z.string().min(1).max(128) }))
    .mutation(async ({ input, ctx }) => {
      await ensureAdminTables();
      const email = input.email.trim().toLowerCase();
      const admins = adminUsers();
      const match = admins.find((a) => a.email === email && a.password && a.password === input.password);
      if (!match) return { ok: false as const, error: "Неверный email или пароль" };
      const token = crypto.randomBytes(32).toString("hex");
      await getDb().execute(sql.raw(
        `INSERT INTO admin_sessions (token, email, expires_at) VALUES ('${token}', '${email}', DATE_ADD(NOW(), INTERVAL ${SESSION_DAYS} DAY))`
      ));
      ctx.resHeaders.append("Set-Cookie", adminCookie(ctx.req, token, SESSION_DAYS * 86400));
      return { ok: true as const };
    }),

  logout: publicQuery.mutation(async ({ ctx }) => {
    const token = readAdminToken(ctx.req);
    if (token) {
      try { await getDb().execute(sql.raw(`DELETE FROM admin_sessions WHERE token = '${token.replace(/'/g, "")}'`)); } catch { /* ignore */ }
    }
    ctx.resHeaders.append("Set-Cookie", adminCookie(ctx.req, "", 0));
    return { ok: true };
  }),

  me: publicQuery.query(async ({ ctx }) => {
    const admin = await getAdmin(ctx.req);
    return { admin: admin ?? null, configured: adminUsers().length > 0 };
  }),

  // ── Дашборд платформы ──────────────────────────────────────────────────
  dashboard: adminProcedure.query(async () => {
    await ensureAdminTables();
    const [users] = await q<{ c: number }>(`SELECT COUNT(*) c FROM users`);
    const [usersWeek] = await q<{ c: number }>(`SELECT COUNT(*) c FROM users WHERE created_at > DATE_SUB(NOW(), INTERVAL 7 DAY)`);
    const [usersDay] = await q<{ c: number }>(`SELECT COUNT(*) c FROM users WHERE created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)`);
    const [clinics] = await q<{ c: number }>(`SELECT COUNT(*) c FROM clinic_accounts`);
    const [published] = await q<{ c: number }>(`SELECT COUNT(*) c FROM clinic_profiles WHERE is_published = 1`);
    const [pendingMod] = await q<{ c: number }>(`SELECT COUNT(*) c FROM clinic_profiles WHERE moderation = 'pending'`);
    const [bookings] = await q<{ c: number }>(`SELECT COUNT(*) c FROM clinic_bookings`);
    const [bookingsNew] = await q<{ c: number }>(`SELECT COUNT(*) c FROM clinic_bookings WHERE status = 'new'`);
    const [promos] = await q<{ c: number; s: number }>(`SELECT COUNT(*) c, COALESCE(SUM(price_month),0) s FROM clinic_promotions WHERE status = 'active'`);
    const [promosPending] = await q<{ c: number }>(`SELECT COUNT(*) c FROM clinic_promotions WHERE status = 'pending_payment'`);
    const [orders] = await q<{ c: number; s: number }>(`SELECT COUNT(*) c, COALESCE(SUM(total),0) s FROM market_orders`);
    const [ordersNew] = await q<{ c: number }>(`SELECT COUNT(*) c FROM market_orders WHERE status = 'new'`);
    return {
      users: { total: Number(users.c), week: Number(usersWeek.c), day: Number(usersDay.c) },
      clinics: { total: Number(clinics.c), published: Number(published.c), pendingModeration: Number(pendingMod.c) },
      bookings: { total: Number(bookings.c), new: Number(bookingsNew.c) },
      promotions: { active: Number(promos.c), revenueMonth: Number(promos.s), pendingPayment: Number(promosPending.c) },
      market: { orders: Number(orders.c), revenue: Number(orders.s), newOrders: Number(ordersNew.c) },
    };
  }),

  // ── Модерация клиник ───────────────────────────────────────────────────
  clinics: adminProcedure.query(async () => {
    await ensureAdminTables();
    const rows = await q<any>(`
      SELECT a.id account_id, a.email, a.org_name, a.license_number, a.phone, a.blocked, a.created_at,
             p.id profile_id, p.name, p.city, p.is_published, p.moderation
      FROM clinic_accounts a
      LEFT JOIN clinic_profiles p ON p.account_id = a.id
      ORDER BY a.id DESC LIMIT 500`);
    return {
      items: rows.map((r) => ({
        accountId: Number(r.account_id),
        email: r.email,
        orgName: r.org_name,
        licenseNumber: r.license_number,
        phone: r.phone,
        blocked: Boolean(r.blocked),
        createdAt: r.created_at,
        profileId: r.profile_id ? Number(r.profile_id) : null,
        profileName: r.name,
        city: r.city,
        isPublished: Boolean(r.is_published),
        moderation: r.moderation,
      })),
    };
  }),

  moderateClinic: adminProcedure
    .input(z.object({ profileId: z.number(), decision: z.enum(["approved", "rejected"]) }))
    .mutation(async ({ input }) => {
      await ensureAdminTables();
      if (input.decision === "approved") {
        await getDb().execute(sql.raw(`UPDATE clinic_profiles SET moderation = 'approved', is_published = 1 WHERE id = ${input.profileId}`));
      } else {
        await getDb().execute(sql.raw(`UPDATE clinic_profiles SET moderation = 'rejected', is_published = 0 WHERE id = ${input.profileId}`));
      }
      return { ok: true };
    }),

  blockClinic: adminProcedure
    .input(z.object({ accountId: z.number(), blocked: z.boolean() }))
    .mutation(async ({ input }) => {
      await ensureAdminTables();
      await getDb().execute(sql.raw(`UPDATE clinic_accounts SET blocked = ${input.blocked ? 1 : 0} WHERE id = ${input.accountId}`));
      if (input.blocked) {
        await getDb().execute(sql.raw(`UPDATE clinic_profiles SET is_published = 0 WHERE account_id = ${input.accountId}`));
        await getDb().execute(sql.raw(`UPDATE clinic_promotions SET status = 'stopped', ends_at = NOW() WHERE account_id = ${input.accountId} AND status IN ('active','pending_payment')`));
      }
      return { ok: true };
    }),

  // ── Рекламные кампании ─────────────────────────────────────────────────
  promotions: adminProcedure.query(async () => {
    await ensureAdminTables();
    const rows = await q<any>(`
      SELECT pr.id, pr.account_id, pr.city, pr.tariff, pr.price_month, pr.status, pr.started_at, pr.ends_at,
             a.org_name
      FROM clinic_promotions pr
      JOIN clinic_accounts a ON a.id = pr.account_id
      ORDER BY pr.id DESC LIMIT 500`);
    return {
      items: rows.map((r) => ({
        id: Number(r.id),
        accountId: Number(r.account_id),
        orgName: r.org_name,
        city: r.city,
        tariff: r.tariff,
        priceMonth: r.price_month,
        status: r.status,
        startedAt: r.started_at,
        endsAt: r.ends_at,
      })),
    };
  }),

  // Подтвердить оплату кампании → активация
  confirmPayment: adminProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await ensureAdminTables();
      await getDb().execute(sql.raw(`UPDATE clinic_promotions SET status = 'active' WHERE id = ${input.id} AND status = 'pending_payment'`));
      return { ok: true };
    }),

  stopPromotion: adminProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await ensureAdminTables();
      await getDb().execute(sql.raw(`UPDATE clinic_promotions SET status = 'stopped', ends_at = NOW() WHERE id = ${input.id}`));
      return { ok: true };
    }),

  // ── Маркетплейс: товары ────────────────────────────────────────────────
  products: adminProcedure.query(async () => {
    await ensureAdminTables();
    const rows = await q<any>(`SELECT * FROM market_products ORDER BY category, name LIMIT 1000`);
    return {
      items: rows.map((r) => ({
        id: Number(r.id), category: r.category, name: r.name, unit: r.unit,
        price: r.price, stock: Number(r.stock), supplier: r.supplier,
        requiresLicense: Boolean(r.requires_license), description: r.description,
      })),
    };
  }),

  saveProduct: adminProcedure
    .input(z.object({
      id: z.number().optional(),
      category: z.string().min(1).max(128),
      name: z.string().min(1).max(255),
      unit: z.string().max(32).default("упак."),
      price: z.number().min(0),
      stock: z.number().min(0),
      supplier: z.string().max(255).optional(),
      requiresLicense: z.boolean().default(false),
      description: z.string().max(2000).optional(),
    }))
    .mutation(async ({ input }) => {
      await ensureAdminTables();
      const esc = (s: string | undefined | null) => (s ?? "").replace(/'/g, "''");
      if (input.id) {
        await getDb().execute(sql.raw(
          `UPDATE market_products SET category='${esc(input.category)}', name='${esc(input.name)}', unit='${esc(input.unit)}',
           price=${input.price}, stock=${input.stock}, supplier='${esc(input.supplier)}',
           requires_license=${input.requiresLicense ? 1 : 0}, description='${esc(input.description)}' WHERE id=${input.id}`
        ));
      } else {
        await getDb().execute(sql.raw(
          `INSERT INTO market_products (category, name, unit, price, stock, supplier, requires_license, description)
           VALUES ('${esc(input.category)}','${esc(input.name)}','${esc(input.unit)}',${input.price},${input.stock},
           '${esc(input.supplier)}',${input.requiresLicense ? 1 : 0},'${esc(input.description)}')`
        ));
      }
      return { ok: true };
    }),

  deleteProduct: adminProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await ensureAdminTables();
      await getDb().execute(sql.raw(`DELETE FROM market_products WHERE id = ${input.id}`));
      return { ok: true };
    }),

  // ── Маркетплейс: заказы ────────────────────────────────────────────────
  orders: adminProcedure.query(async () => {
    await ensureAdminTables();
    const orders = await q<any>(`
      SELECT o.id, o.total, o.status, o.comment, o.created_at, a.org_name, a.email
      FROM market_orders o JOIN clinic_accounts a ON a.id = o.account_id
      ORDER BY o.id DESC LIMIT 300`);
    const items = await q<any>(`
      SELECT i.order_id, i.qty, i.price, p.name
      FROM market_order_items i JOIN market_products p ON p.id = i.product_id`);
    return {
      items: orders.map((o) => ({
        id: Number(o.id),
        orgName: o.org_name,
        email: o.email,
        total: o.total,
        status: o.status,
        comment: o.comment,
        createdAt: o.created_at,
        lines: items.filter((i) => Number(i.order_id) === Number(o.id))
          .map((i) => ({ name: i.name, qty: Number(i.qty), price: i.price })),
      })),
    };
  }),

  setOrderStatus: adminProcedure
    .input(z.object({ id: z.number(), status: z.enum(["paid", "shipped", "done", "cancelled"]) }))
    .mutation(async ({ input }) => {
      await ensureAdminTables();
      await getDb().execute(sql.raw(`UPDATE market_orders SET status = '${input.status}' WHERE id = ${input.id}`));
      return { ok: true };
    }),

  // ── Пользователи (только техническая информация, без медданных) ───────
  users: adminProcedure
    .input(z.object({ q: z.string().max(128).optional() }).optional())
    .query(async ({ input }) => {
      await ensureAdminTables();
      const needle = input?.q?.trim().toLowerCase().replace(/'/g, "");
      const where = needle
        ? `WHERE LOWER(COALESCE(email,'')) LIKE '%${needle}%' OR LOWER(COALESCE(phone,'')) LIKE '%${needle}%' OR LOWER(COALESCE(tg_username,'')) LIKE '%${needle}%'`
        : "";
      const rows = await q<any>(`
        SELECT id, email, phone, tg_username, blocked, created_at FROM users ${where}
        ORDER BY id DESC LIMIT 300`);
      return {
        items: rows.map((r) => ({
          id: Number(r.id),
          email: r.email,
          phone: r.phone,
          tgUsername: r.tg_username,
          blocked: Boolean(r.blocked),
          createdAt: r.created_at,
        })),
      };
    }),

  blockUser: adminProcedure
    .input(z.object({ id: z.number(), blocked: z.boolean() }))
    .mutation(async ({ input }) => {
      await ensureAdminTables();
      await getDb().execute(sql.raw(`UPDATE users SET blocked = ${input.blocked ? 1 : 0} WHERE id = ${input.id}`));
      if (input.blocked) {
        await getDb().execute(sql.raw(`DELETE FROM sessions WHERE user_id = ${input.id}`));
      }
      return { ok: true };
    }),
});
