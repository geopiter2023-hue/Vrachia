// ─── Локальный движок анализа биомаркеров ────────────────────────────────
// Rule-based анализ: референтные диапазоны, тренды, отклонения, риски.
// Все вычисления локальны, данные не покидают сервер.

import type { Biomarker, Measurement, Document } from "@db/schema";

// Минимальные структуры — чтобы движок работал и с личными, и с семейными данными
export type MeasurementLike = Pick<Measurement, "biomarkerId" | "value" | "measuredAt" | "documentId">;
export type DocumentLike = Pick<Document, "id" | "title" | "docDate">;

export type Point = { date: string; value: number; documentId: number | null };

export type BiomarkerAnalysis = {
  biomarker: Biomarker;
  points: Point[];
  latest: Point | null;
  status: "normal" | "low" | "high" | "critical" | "no_data";
  trend: "up" | "down" | "stable" | "insufficient";
  trendPct: number | null; // изменение между первой и последней точкой, %
  deviationPct: number | null; // насколько последнее значение за пределами нормы, %
};

const fmtDate = (d: string) =>
  new Date(d + (d.length === 10 ? "T00:00:00" : "")).toLocaleDateString("ru-RU", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });

export function analyzeBiomarker(b: Biomarker, ms: MeasurementLike[]): BiomarkerAnalysis {
  const points: Point[] = ms
    .map((m) => ({
      date: typeof m.measuredAt === "string" ? m.measuredAt : new Date(m.measuredAt).toISOString().slice(0, 10),
      value: m.value,
      documentId: m.documentId ?? null,
    }))
    .sort((a, c) => a.date.localeCompare(c.date));

  const latest = points.length ? points[points.length - 1] : null;

  let status: BiomarkerAnalysis["status"] = "no_data";
  let deviationPct: number | null = null;
  if (latest && b.refLow != null && b.refHigh != null) {
    const range = b.refHigh - b.refLow;
    if (latest.value < b.refLow) {
      deviationPct = ((b.refLow - latest.value) / range) * 100;
      status = deviationPct > 50 ? "critical" : "low";
    } else if (latest.value > b.refHigh) {
      deviationPct = ((latest.value - b.refHigh) / range) * 100;
      status = deviationPct > 50 ? "critical" : "high";
    } else {
      status = "normal";
      deviationPct = 0;
    }
  } else if (latest) {
    status = "normal";
  }

  let trend: BiomarkerAnalysis["trend"] = "insufficient";
  let trendPct: number | null = null;
  if (points.length >= 2) {
    const first = points[0].value;
    const last = points[points.length - 1].value;
    trendPct = first !== 0 ? ((last - first) / Math.abs(first)) * 100 : null;
    const threshold = 5; // % изменения считаем значимым
    if (trendPct != null && Math.abs(trendPct) >= threshold) {
      trend = trendPct > 0 ? "up" : "down";
    } else {
      trend = "stable";
    }
  }

  return { biomarker: b, points, latest, status, trend, trendPct, deviationPct };
}

// ── Текстовые интерпретации ──────────────────────────────────────────────

const STATUS_TEXT: Record<BiomarkerAnalysis["status"], string> = {
  normal: "в пределах референтных значений",
  low: "ниже референтного диапазона",
  high: "выше референтного диапазона",
  critical: "критически выходит за пределы нормы",
  no_data: "нет данных",
};

const TREND_TEXT: Record<BiomarkerAnalysis["trend"], string> = {
  up: "растёт",
  down: "снижается",
  stable: "стабилен",
  insufficient: "недостаточно данных для оценки тренда",
};

export function describeBiomarker(a: BiomarkerAnalysis, docs: DocumentLike[]): string {
  const b = a.biomarker;
  if (!a.latest) return `По показателю «${b.name}» данных пока нет.`;
  const parts: string[] = [];
  parts.push(
    `**${b.name}**: последнее значение ${a.latest.value} ${b.unit} (${fmtDate(a.latest.date)}) — ${STATUS_TEXT[a.status]}` +
      (b.refLow != null && b.refHigh != null
        ? ` (норма ${b.refLow}–${b.refHigh} ${b.unit})`
        : "") +
      "."
  );
  if (a.trend !== "insufficient" && a.trendPct != null) {
    parts.push(
      `Динамика с ${fmtDate(a.points[0].date)}: показатель ${TREND_TEXT[a.trend]} (${a.trendPct > 0 ? "+" : ""}${a.trendPct.toFixed(1)}%).`
    );
  }
  if (a.status === "high" || a.status === "low") {
    parts.push(
      `Отклонение от границы нормы составляет ~${Math.abs(a.deviationPct ?? 0).toFixed(0)}% от ширины референтного диапазона.`
    );
  }
  if (a.status === "critical") {
    parts.push("⚠️ Значительное отклонение — рекомендуется очная консультация врача в ближайшее время.");
  }
  // Цитирование источников
  const srcIds = [...new Set(a.points.map((p) => p.documentId).filter(Boolean))] as number[];
  const srcDocs = docs.filter((d) => srcIds.includes(Number(d.id)));
  if (srcDocs.length) {
    parts.push(
      "Источники: " +
        srcDocs.map((d) => `«${d.title}» от ${fmtDate(String(d.docDate))}`).join("; ") +
        "."
    );
  }
  return parts.join("\n");
}

// ── Выявление взаимосвязей и рисков ──────────────────────────────────────

export function detectCorrelations(analyses: BiomarkerAnalysis[]): string[] {
  const byCode = new Map(analyses.map((a) => [a.biomarker.code, a]));
  const findings: string[] = [];
  const bad = (code: string) => {
    const a = byCode.get(code);
    return a && (a.status === "high" || a.status === "critical");
  };
  const rising = (code: string) => byCode.get(code)?.trend === "up";

  if ((bad("CHOL") || bad("LDL")) && bad("GLU")) {
    findings.push(
      "Одновременное повышение холестерина/ЛПНП и глюкозы — типичный маркер метаболического риска (риск сердечно-сосудистых событий и инсулинорезистентности). Обоснование: показатели CHOL/LDL и GLU выше нормы в последних анализах."
    );
  }
  if (bad("URIC") && (bad("CHOL") || bad("TG"))) {
    findings.push(
      "Повышенная мочевая кислота на фоне нарушений липидного профиля часто связана с образом жизни (питание, алкоголь, низкая активность). Обоснование: URIC и CHOL/TG выше референта."
    );
  }
  if (bad("ALT") && bad("AST")) {
    findings.push(
      "Синхронное повышение АЛТ и АСТ указывает на нагрузку на печёночную ткань. Рекомендуется обсудить с гепатологом/терапевтом. Обоснование: ALT и AST выше нормы."
    );
  }
  if (bad("TSH") && byCode.get("VITD")?.status === "low") {
    findings.push(
      "Сочетание отклонений ТТГ и дефицита витамина D может усиливать утомляемость и снижение тонуса. Обоснование: TSH выше нормы, VITD ниже нормы."
    );
  }
  if (rising("CHOL") && rising("GLU") && findings.length === 0) {
    findings.push(
      "Холестерин и глюкоза растут одновременно, хотя ещё могут быть в норме — ранний сигнал метаболического сдвига. Стоит скорректировать питание и пересдать анализы через 2–3 месяца."
    );
  }
  return findings;
}

export function detectRisks(analyses: BiomarkerAnalysis[]): string[] {
  const risks: string[] = [];
  for (const a of analyses) {
    if (a.status === "critical") {
      risks.push(
        `Критическое отклонение: ${a.biomarker.name} — ${a.latest!.value} ${a.biomarker.unit} при норме ${a.biomarker.refLow}–${a.biomarker.refHigh}. Требуется консультация врача.`
      );
    } else if (a.status === "high" && a.trend === "up") {
      risks.push(
        `${a.biomarker.name}: значение выше нормы и продолжает расти (${a.trendPct != null ? "+" + a.trendPct.toFixed(1) + "%" : ""} за период наблюдения).`
      );
    } else if (a.status === "low" && a.trend === "down") {
      risks.push(
        `${a.biomarker.name}: значение ниже нормы и продолжает снижаться (${a.trendPct != null ? a.trendPct.toFixed(1) + "%" : ""} за период наблюдения).`
      );
    }
  }
  return risks;
}

// ── Рекомендации по питанию и спорту ─────────────────────────────────────

export type Recommendation = {
  title: string;
  detail: string;
  reason: string; // на основании каких показателей
  priority: "high" | "medium" | "low";
};

export type LifestyleRecommendations = {
  nutrition: Recommendation[];
  sport: Recommendation[];
  contraindications: string[];
  summary: string;
};

export function buildRecommendations(
  analyses: BiomarkerAnalysis[],
  vitalsCtx?: { weight?: number; pressureSys?: number; pressureDia?: number; pulse?: number }
): LifestyleRecommendations {
  const byCode = new Map(analyses.map((a) => [a.biomarker.code, a]));
  const get = (code: string) => byCode.get(code);
  const high = (code: string) => {
    const a = get(code);
    return a && (a.status === "high" || a.status === "critical");
  };
  const low = (code: string) => {
    const a = get(code);
    return a && (a.status === "low" || a.status === "critical");
  };

  const nutrition: Recommendation[] = [];
  const sport: Recommendation[] = [];
  const contraindications: string[] = [];

  // ── Питание ──
  if (high("CHOL") || high("LDL")) {
    nutrition.push({
      title: "Снизить насыщенные жиры и трансжиры",
      detail:
        "Ограничьте красное мясо, сливочное масло, жирные молочные продукты, выпечку и фастфуд. Замените на рыбу (2–3 раза в неделю), оливковое масло, орехи (горсть в день), авокадо.",
      reason: `Холестерин/ЛПНП выше нормы (${get("CHOL")?.latest?.value ?? "—"} / ${get("LDL")?.latest?.value ?? "—"})`,
      priority: "high",
    });
    nutrition.push({
      title: "Добавить растворимую клетчатку",
      detail:
        "Овсянка, бобовые, яблоки, семена льна — 25–30 г клетчатки в день помогают снизить ЛПНП на 5–10%.",
      reason: "Повышенный липидный профиль",
      priority: "medium",
    });
  }
  if (high("HDL") === false && low("HDL")) {
    nutrition.push({
      title: "Поднять «хороший» холестерин (ЛПВП)",
      detail: "Оливковое масло, жирная рыба, орехи, умеренное потребление яиц. Отказ от трансжиров обязателен.",
      reason: `ЛПВП ниже нормы (${get("HDL")?.latest?.value})`,
      priority: "medium",
    });
  }
  if (high("GLU") || high("HBA1C")) {
    nutrition.push({
      title: "Ограничить быстрые углеводы",
      detail:
        "Уберите сахар, сладкие напитки, белый хлеб, соки. Основа рациона — овощи, цельнозерновые крупы, белок. Дробное питание 4–5 раз в день небольшими порциями.",
      reason: `Глюкоза/HbA1c выше нормы (${get("GLU")?.latest?.value ?? "—"} / ${get("HBA1C")?.latest?.value ?? "—"})`,
      priority: "high",
    });
    nutrition.push({
      title: "Контроль гликемической нагрузки",
      detail: "Продукты с низким ГИ: гречка, киноа, чечевица, ягоды. Углеводы — в первой половине дня.",
      reason: "Нарушение углеводного обмена",
      priority: "medium",
    });
  }
  if (high("URIC")) {
    nutrition.push({
      title: "Гипопуриновая диета",
      detail:
        "Ограничьте мясо, субпродукты, бобовые, грибы, шпинат, какао. Исключите пиво и крепкий алкоголь. Пейте 2–2,5 л воды в день, полезны молочные продукты с низкой жирностью и вишня.",
      reason: `Мочевая кислота выше нормы (${get("URIC")?.latest?.value})`,
      priority: "high",
    });
  }
  if (high("ALT") || high("AST")) {
    nutrition.push({
      title: "Щадящий режим для печени",
      detail:
        "Исключите алкоголь полностью, жареное и копчёное. Стол №5: отварное/паровое, нежирные сорта мяса и рыбы, больше овощей. Меньше соли и специй.",
      reason: `Печёночные ферменты повышены (АЛТ ${get("ALT")?.latest?.value ?? "—"}, АСТ ${get("AST")?.latest?.value ?? "—"})`,
      priority: "high",
    });
  }
  if (low("VITD")) {
    nutrition.push({
      title: "Восполнение витамина D",
      detail:
        "Жирная рыба (лосось, скумбрия), яичный желток, обогащённые продукты. Обсудите с врачом дозировку препаратов витамина D3 — обычно 1000–2000 МЕ/сут при дефиците.",
      reason: `Витамин D ниже нормы (${get("VITD")?.latest?.value})`,
      priority: "medium",
    });
  }
  if (low("HGB")) {
    nutrition.push({
      title: "Питание при сниженном гемоглобине",
      detail:
        "Говядина, печень, гречка, гранат, чечевица. Железо усваивается с витамином C — добавляйте цитрусовые/перец к приёму пищи. Чай и кофе пейте отдельно от еды.",
      reason: `Гемоглобин ниже нормы (${get("HGB")?.latest?.value})`,
      priority: "high",
    });
  }
  if (high("TG")) {
    nutrition.push({
      title: "Снизить триглицериды",
      detail: "Резко ограничьте алкоголь и простые сахара. Омега-3 (рыба или добавки по согласованию с врачом).",
      reason: `Триглицериды выше нормы (${get("TG")?.latest?.value})`,
      priority: "medium",
    });
  }
  if (high("TSH")) {
    nutrition.push({
      title: "Поддержка щитовидной железы",
      detail:
        "Достаточное потребление йода (йодированная соль, морская рыба, морепродукты) и селена (бразильский орех — 1–2 шт в день). Не злоупотребляйте сырыми крестоцветными.",
      reason: `ТТГ выше нормы (${get("TSH")?.latest?.value})`,
      priority: "medium",
    });
  }
  if (vitalsCtx?.weight && vitalsCtx.weight > 90) {
    nutrition.push({
      title: "Умеренный дефицит калорий",
      detail:
        "Дефицит 300–500 ккал/сут: тарелка — ½ овощи, ¼ белок, ¼ сложные углеводы. Взвешивание раз в неделю, цель — минус 0,5 кг/нед.",
      reason: `Текущий вес ${vitalsCtx.weight} кг`,
      priority: "medium",
    });
  }

  // ── Спорт ──
  const metabolicRisk = high("CHOL") || high("GLU") || high("HBA1C") || high("TG");
  if (metabolicRisk) {
    sport.push({
      title: "Аэробная нагрузка 150+ минут в неделю",
      detail:
        "Быстрая ходьба, плавание, велосипед — 30 минут 5 раз в неделю. Доказано снижение глюкозы, триглицеридов и ЛПНП при регулярной аэробной активности.",
      reason: "Метаболические отклонения (липиды/глюкоза)",
      priority: "high",
    });
    sport.push({
      title: "Силовые тренировки 2 раза в неделю",
      detail:
        "Умеренные веса, собственный вес или тренажёры — увеличение мышечной массы улучшает чувствительность к инсулину.",
      reason: "Метаболический профиль",
      priority: "medium",
    });
  }
  if (low("VITD") || high("TSH")) {
    sport.push({
      title: "Активность на свежем воздухе",
      detail:
        "Прогулки днём 30–40 минут — естественный источник витамина D и поддержка гормонального фона.",
      reason: "Витамин D / ТТГ",
      priority: "low",
    });
  }
  if (low("HGB")) {
    sport.push({
      title: "Умеренная нагрузка без перегрузок",
      detail:
        "Ходьба, йога, лёгкое плавание. Избегайте интенсивных интервальных тренировок до восстановления гемоглобина.",
      reason: `Гемоглобин ${get("HGB")?.latest?.value} — снижен`,
      priority: "medium",
    });
  }
  if (high("URIC")) {
    sport.push({
      title: "Избегать обезвоживания на тренировках",
      detail:
        "Пейте воду до, во время и после нагрузки. Интенсивное потоение без восполнения жидкости провоцирует подъём мочевой кислоты.",
      reason: "Мочевая кислота повышена",
      priority: "medium",
    });
  }
  if (vitalsCtx?.pressureSys && vitalsCtx.pressureSys >= 140) {
    contraindications.push(
      `Давление ${vitalsCtx.pressureSys}/${vitalsCtx.pressureDia ?? "—"} мм рт. ст.: избегайте максимальных силовых нагрузок, задержек дыхания (статика, планка с натуживанием). Предпочтительны ходьба, плавание, дыхательные практики.`
    );
  }
  if (vitalsCtx?.pulse && vitalsCtx.pulse >= 90) {
    contraindications.push(
      `Пульс в покое ${vitalsCtx.pulse} уд/мин: начинайте нагрузку постепенно, контролируйте ЧСС (зона 50–70% от максимальной).`
    );
  }
  for (const a of analyses) {
    if (a.status === "critical") {
      contraindications.push(
        `${a.biomarker.name}: критическое отклонение — до консультации врача только лёгкая активность (ходьба).`
      );
    }
  }

  if (!nutrition.length) {
    nutrition.push({
      title: "Поддерживающее сбалансированное питание",
      detail:
        "Отклонений не выявлено. Рацион по принципу «здоровой тарелки»: ½ овощи и зелень, ¼ белок, ¼ цельнозерновые. 1,5–2 л воды в день.",
      reason: "Все показатели в норме",
      priority: "low",
    });
  }
  if (!sport.length) {
    sport.push({
      title: "Общая физическая активность",
      detail:
        "Минимум 7000–10000 шагов в день, 150 минут умеренной активности в неделю по рекомендациям ВОЗ.",
      reason: "Профилактика",
      priority: "low",
    });
  }

  const devCount = analyses.filter((a) => a.status !== "normal" && a.latest).length;
  const summary = devCount
    ? `Сформировано на основе ${devCount} отклоняющихся показателей: ${nutrition.length} рекомендаций по питанию, ${sport.length} по спорту${contraindications.length ? `, ${contraindications.length} ограничений` : ""}.`
    : "Отклонений не выявлено — рекомендации носят профилактический характер.";

  return { nutrition, sport, contraindications, summary };
}

// ── Маршрутизация вопросов по клиническому интенту ───────────────────────

const norm = (s: string) => s.toLowerCase().replace(/ё/g, "е");

function findBiomarker(q: string, analyses: BiomarkerAnalysis[]): BiomarkerAnalysis | null {
  const nq = norm(q);
  let best: BiomarkerAnalysis | null = null;
  let bestLen = 0;
  for (const a of analyses) {
    const name = norm(a.biomarker.name);
    const code = norm(a.biomarker.code);
    if ((name.length > 2 && nq.includes(name)) || nq.includes(code)) {
      if (name.length > bestLen) {
        best = a;
        bestLen = name.length;
      }
    }
    // частичное совпадение по словам названия
    for (const w of name.split(/[\s()\/,-]+/).filter((w) => w.length > 4)) {
      if (nq.includes(w) && w.length > bestLen) {
        best = a;
        bestLen = w.length;
      }
    }
  }
  return best;
}

export function answerQuestion(
  question: string,
  analyses: BiomarkerAnalysis[],
  docs: DocumentLike[]
): string {
  const q = norm(question);
  const withData = analyses.filter((a) => a.latest);

  if (!withData.length) {
    return "В системе пока нет загруженных показателей. Загрузите анализы в разделе «Документы» или добавьте измерения вручную на странице «Показатели» — после этого я смогу анализировать динамику и отвечать на вопросы.";
  }

  // Интент: конкретный биомаркер
  const target = findBiomarker(question, analyses);
  if (target) {
    return describeBiomarker(target, docs);
  }

  // Интент: ухудшение / риски
  if (/ухудш|риск|опасн|тревож|критич|плох/.test(q)) {
    const risks = detectRisks(withData);
    if (!risks.length)
      return "По текущим данным критических отклонений и устойчиво ухудшающихся показателей не выявлено. Все отслеживаемые биомаркеры либо в норме, либо стабильны. Продолжайте плановый контроль.";
    return (
      "Обнаружены следующие моменты, требующие внимания:\n\n" +
      risks.map((r) => `• ${r}`).join("\n") +
      "\n\nРезультат не является диагнозом — обсудите эти данные с врачом."
    );
  }

  // Интент: взаимосвязи
  if (/связ|взаим|влия|причин/.test(q)) {
    const corr = detectCorrelations(withData);
    if (!corr.length)
      return "Явных паттернов взаимосвязи между показателями на текущих данных не выявлено. По мере накопления истории анализов я смогу находить более тонкие зависимости.";
    return "Выявленные взаимосвязи:\n\n" + corr.map((c) => `• ${c}`).join("\n\n");
  }

  // Интент: динамика за период
  if (/динамик|измен|тренд|за последн|за год|за период/.test(q)) {
    const lines = withData
      .filter((a) => a.trend !== "insufficient")
      .sort((a, b) => Math.abs(b.trendPct ?? 0) - Math.abs(a.trendPct ?? 0))
      .map(
        (a) =>
          `• ${a.biomarker.name}: ${TREND_TEXT[a.trend]} (${a.trendPct! > 0 ? "+" : ""}${a.trendPct!.toFixed(1)}%), последнее значение ${a.latest!.value} ${a.biomarker.unit} — ${STATUS_TEXT[a.status]}`
      );
    if (!lines.length) return "Недостаточно серий измерений для оценки динамики — нужно минимум два результата по каждому показателю.";
    const periodStart = withData.flatMap((a) => a.points).map((p) => p.date).sort()[0];
    return (
      `Динамика показателей за период с ${fmtDate(periodStart)}:\n\n` +
      lines.join("\n") +
      "\n\nПодробные графики — в разделе «Показатели»."
    );
  }

  // Интент: что означают показатели / общий обзор
  if (/означа|интерпрет|расшифр|обзор|общ|состояни|как дела|сводк/.test(q)) {
    const abnormal = withData.filter((a) => a.status !== "normal");
    const ok = withData.length - abnormal.length;
    let out = `Всего отслеживается ${withData.length} показателей: ${ok} в норме, ${abnormal.length} с отклонениями.\n\n`;
    if (abnormal.length) {
      out += "Показатели вне референтных диапазонов:\n\n" + abnormal.map((a) => describeBiomarker(a, docs)).join("\n\n");
      const corr = detectCorrelations(withData);
      if (corr.length) out += "\n\nВозможные взаимосвязи:\n\n" + corr.map((c) => `• ${c}`).join("\n\n");
    } else {
      out += "Все показатели находятся в пределах референтных значений. Отклонений не выявлено.";
    }
    return out + "\n\nРезультат не является диагнозом — при отклонениях требуется консультация врача.";
  }

  // Фолбэк
  return (
    "Я могу ответить на вопросы о ваших медицинских данных. Примеры:\n\n" +
    "• «Что означают мои показатели?» — общий обзор с интерпретацией\n" +
    "• «Какая динамика за последний год?» — тренды всех биомаркеров\n" +
    "• «Есть ли ухудшение?» — поиск рисков и критических изменений\n" +
    "• «Какой холестерин?» — детали по конкретному показателю\n" +
    "• «Есть ли связь между показателями?» — выявление взаимосвязей\n\n" +
    `Сейчас в системе ${withData.length} активных биомаркеров и ${docs.length} документов.`
  );
}
