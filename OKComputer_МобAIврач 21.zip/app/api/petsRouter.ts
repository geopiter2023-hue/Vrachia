import { z } from "zod";
import { createRouter, userProcedure } from "./middleware";
import { getDb } from "./queries/connection";
import { pets, petEvents, auditLog } from "@db/schema";
import { and, eq, desc } from "drizzle-orm";

async function log(userId: number, action: string, detail: string) {
  await getDb().insert(auditLog).values({ userId, action, detail });
}

export const petsRouter = createRouter({
  list: userProcedure.query(async ({ ctx }) => {
    const db = getDb();
    const ps = await db.select().from(pets).where(eq(pets.userId, ctx.user.id)).orderBy(desc(pets.createdAt));
    const evs = await db.select().from(petEvents).where(eq(petEvents.userId, ctx.user.id)).orderBy(desc(petEvents.eventDate));
    return ps.map((p) => ({
      ...p,
      events: evs.filter((e) => e.petId === Number(p.id)),
    }));
  }),

  create: userProcedure
    .input(
      z.object({
        name: z.string().min(1),
        species: z.enum(["dog", "cat", "bird", "rodent", "other"]),
        breed: z.string().optional(),
        sex: z.enum(["male", "female"]).default("male"),
        birthDate: z.string().optional(),
        weightKg: z.number().optional(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const res = await getDb().insert(pets).values({
        userId: ctx.user.id,
        name: input.name,
        species: input.species,
        breed: input.breed,
        sex: input.sex,
        birthDate: input.birthDate || null,
        weightKg: input.weightKg,
        notes: input.notes,
      });
      await log(ctx.user.id, "pet", `Добавлен питомец «${input.name}» (${input.species})`);
      return { id: Number(res[0].insertId) };
    }),

  update: userProcedure
    .input(
      z.object({
        id: z.number(),
        name: z.string().min(1),
        species: z.enum(["dog", "cat", "bird", "rodent", "other"]),
        breed: z.string().optional(),
        sex: z.enum(["male", "female"]),
        birthDate: z.string().optional(),
        weightKg: z.number().optional(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      await getDb()
        .update(pets)
        .set({
          name: input.name,
          species: input.species,
          breed: input.breed,
          sex: input.sex,
          birthDate: input.birthDate || null,
          weightKg: input.weightKg,
          notes: input.notes,
        })
        .where(and(eq(pets.id, input.id), eq(pets.userId, ctx.user.id)));
      await log(ctx.user.id, "pet", `Обновлён профиль питомца «${input.name}»`);
      return { ok: true };
    }),

  remove: userProcedure.input(z.object({ id: z.number() })).mutation(async ({ input, ctx }) => {
    const db = getDb();
    await db.delete(petEvents).where(and(eq(petEvents.petId, input.id), eq(petEvents.userId, ctx.user.id)));
    await db.delete(pets).where(and(eq(pets.id, input.id), eq(pets.userId, ctx.user.id)));
    await log(ctx.user.id, "pet", `Удалён питомец #${input.id}`);
    return { ok: true };
  }),

  addEvent: userProcedure
    .input(
      z.object({
        petId: z.number(),
        eventType: z.enum(["visit", "vaccine", "analysis", "procedure", "note"]),
        title: z.string().min(1),
        eventDate: z.string(),
        detail: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      await getDb().insert(petEvents).values({ ...input, userId: ctx.user.id });
      await log(ctx.user.id, "pet_event", `Событие для питомца #${input.petId}: ${input.title} (${input.eventDate})`);
      return { ok: true };
    }),

  removeEvent: userProcedure.input(z.object({ id: z.number() })).mutation(async ({ input, ctx }) => {
    await getDb().delete(petEvents).where(and(eq(petEvents.id, input.id), eq(petEvents.userId, ctx.user.id)));
    return { ok: true };
  }),
});
