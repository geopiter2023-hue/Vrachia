// ─── Маркетплейс медицинских принадлежностей (B2B-закупки клиник) ────────
// Поставщики размещают расходники; клиники закупаются через кабинет.
// Комиссия площадки — с оборота (учитывается при выставлении счёта клинике).
import { z } from "zod";
import { createRouter, userProcedure } from "./middleware";
import { getDb } from "./queries/connection";
import { marketProducts, marketOrders, marketOrderItems } from "@db/schema";
import { desc, eq, sql } from "drizzle-orm";
import { ensurePlatformTables } from "./platformTables";

// Стартовый каталог (сидится один раз, дальше управляется поставщиками/админом)
const SEED: Array<[string, string, string, number, number, boolean]> = [
  // категория, название, ед., цена ₽, остаток, требует лицензию продавца
  ["Перевязочные материалы", "Бинт стерильный 7см×14м", "упак. 10 шт", 450, 500, false],
  ["Перевязочные материалы", "Пластырь рулонный 5см×5м", "шт", 180, 800, false],
  ["Перевязочные материалы", "Вата медицинская стерильная 100г", "упак. 20 шт", 900, 300, false],
  ["Расходники для инъекций", "Шприц трёхкомпонентный 5 мл", "упак. 100 шт", 850, 400, true],
  ["Расходники для инъекций", "Шприц инсулиновый 1 мл U-100", "упак. 100 шт", 1100, 350, true],
  ["Расходники для инъекций", "Катетер периферический 18G", "упак. 50 шт", 2900, 120, true],
  ["Защита и гигиена", "Перчатки нитриловые смотровые M", "упак. 100 шт", 950, 600, false],
  ["Защита и гигиена", "Маски медицинские трёхслойные", "упак. 50 шт", 420, 900, false],
  ["Защита и гигиена", "Антисептик кожный 1 л", "шт", 380, 500, false],
  ["Лаборатория", "Пробирки вакуумные с ЭДТА (фиолетовые)", "упак. 100 шт", 1650, 250, true],
  ["Лаборатория", "Скарификаторы одноразовые", "упак. 200 шт", 1400, 180, true],
  ["Лаборатория", "Тест-полоски глюкозы (универсальные)", "упак. 50 шт", 890, 300, false],
  ["Диагностика", "Тонометр автоматический плечевой", "шт", 3200, 60, false],
  ["Диагностика", "Пульсоксиметр пальцевый", "шт", 1450, 90, false],
  ["Диагностика", "Термометр электронный", "шт", 290, 400, false],
  ["Стерилизация", "Крафт-пакеты для стерилизации 100×200", "упак. 100 шт", 520, 350, false],
  ["Стерилизация", "Индикаторы стерилизации 4 класса", "упак. 250 шт", 1900, 100, false],
  ["Мебель и оснащение", "Кушетка смотровая медицинская", "шт", 12500, 15, false],
  ["Мебель и оснащение", "Стул манипуляционный с подлокотником", "шт", 8900, 20, false],
  ["Документооборот", "Бланки медицинские А5 (рецепты)", "упак. 500 шт", 650, 200, false],
];

let seeded = false;
async function ensureSeed() {
  if (seeded) return;
  await ensurePlatformTables();
  const db = getDb();
  const existing = await db.select({ id: marketProducts.id }).from(marketProducts).limit(1);
  if (!existing.length) {
    for (const [category, name, unit, price, stock, requiresLicense] of SEED) {
      await db.insert(marketProducts).values({ category, name, unit, price, stock, requiresLicense, supplier: "МедСнаб Про" });
    }
  }
  seeded = true;
}

export const marketRouter = createRouter({
  // Каталог (доступен авторизованным: и пациентам для обзора, и клиникам)
  catalog: userProcedure
    .input(z.object({ category: z.string().max(128).optional(), q: z.string().max(128).optional() }).optional())
    .query(async ({ input }) => {
      await ensureSeed();
      const db = getDb();
      const rows = await db.select().from(marketProducts).orderBy(marketProducts.category, marketProducts.name);
      const q = input?.q?.trim().toLowerCase();
      const items = rows
        .filter((r) => (!input?.category || r.category === input.category) && (!q || r.name.toLowerCase().includes(q)))
        .map((r) => ({ ...r, id: Number(r.id) }));
      const categories = [...new Set(rows.map((r) => r.category))].sort();
      return { items, categories };
    }),

  // Оформление заказа клиникой (accountId передаётся из клиник-кабинета через ordersFor)
  createOrder: userProcedure
    .input(z.object({
      clinicAccountId: z.number(),
      items: z.array(z.object({ productId: z.number(), qty: z.number().min(1).max(100000) })).min(1).max(100),
      comment: z.string().max(1000).optional(),
    }))
    .mutation(async ({ input }) => {
      await ensureSeed();
      const db = getDb();
      const products = await db.select().from(marketProducts);
      const byId = new Map(products.map((p) => [Number(p.id), p]));
      let total = 0;
      const lines: Array<{ productId: number; qty: number; price: number }> = [];
      for (const it of input.items) {
        const p = byId.get(it.productId);
        if (!p) return { ok: false as const, error: `Товар #${it.productId} не найден` };
        if (Number(p.stock) < it.qty) return { ok: false as const, error: `«${p.name}»: на складе ${p.stock} ${p.unit}` };
        total += Number(p.price) * it.qty;
        lines.push({ productId: it.productId, qty: it.qty, price: Number(p.price) });
      }
      const r = await db.insert(marketOrders).values({
        accountId: input.clinicAccountId,
        total,
        comment: input.comment ?? null,
      });
      const orderId = Number((r as any)[0]?.insertId ?? (r as any).insertId);
      for (const l of lines) {
        await db.insert(marketOrderItems).values({ orderId, ...l });
        await db.execute(sql.raw(`UPDATE market_products SET stock = stock - ${l.qty} WHERE id = ${l.productId}`));
      }
      return { ok: true as const, orderId, total };
    }),

  // Заказы клиники (по accountId кабинета)
  ordersFor: userProcedure
    .input(z.object({ clinicAccountId: z.number() }))
    .query(async ({ input }) => {
      await ensurePlatformTables();
      const db = getDb();
      const orders = await db.select().from(marketOrders)
        .where(eq(marketOrders.accountId, input.clinicAccountId))
        .orderBy(desc(marketOrders.id))
        .limit(100);
      const items = await db.select().from(marketOrderItems);
      const products = await db.select().from(marketProducts);
      const nameById = new Map(products.map((p) => [Number(p.id), p.name]));
      return {
        items: orders.map((o) => ({
          id: Number(o.id),
          total: o.total,
          status: o.status,
          createdAt: o.createdAt,
          lines: items
            .filter((i) => Number(i.orderId) === Number(o.id))
            .map((i) => ({ name: nameById.get(Number(i.productId)) ?? `#${i.productId}`, qty: i.qty, price: i.price })),
        })),
      };
    }),
});
