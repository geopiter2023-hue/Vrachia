// Фирменный PDF-бланк «Дневник артериального давления» с QR-кодом входа в систему
import pdfMake from "pdfmake/build/pdfmake";
import QRCode from "qrcode";
import { ensureFonts } from "./medcard-pdf";

const TEAL = "#0f766e";
const TEAL_DARK = "#115e59";
const MUTED = "#64748b";

export type BpPdfEntry = {
  sys: number;
  dia: number;
  pulse: number | null;
  arm: "left" | "right";
  wellbeing: "none" | "great" | "good" | "ok" | "bad";
  note: string | null;
  measuredAt: string | Date;
};

export type BpPdfStats = {
  count: number;
  avgSys: number | null;
  avgDia: number | null;
  avgPulse: number | null;
  maxSys: number | null;
  highCount: number;
  highPct: number;
};

const WB: Record<string, string> = {
  none: "—",
  great: "Отличное",
  good: "Хорошее",
  ok: "Сносное",
  bad: "Плохое",
};

function bpLabel(sys: number, dia: number): string {
  if (sys >= 160 || dia >= 100) return "Гипертония 2 ст.";
  if (sys >= 140 || dia >= 90) return "Гипертония 1 ст.";
  if (sys >= 130 || dia >= 85) return "Высокое нормальное";
  if (sys < 90 || dia < 60) return "Пониженное";
  return "Норма";
}

function bpColor(sys: number, dia: number): string {
  if (sys >= 160 || dia >= 100) return "#e11d48";
  if (sys >= 140 || dia >= 90) return "#ea580c";
  if (sys >= 130 || dia >= 85) return "#d97706";
  if (sys < 90 || dia < 60) return "#0284c7";
  return "#059669";
}

function fmtDateTime(d: string | Date): { date: string; time: string } {
  const dt = new Date(d);
  const date = dt.toLocaleDateString("ru-RU", { day: "2-digit", month: "2-digit", year: "numeric" });
  const time = dt.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" });
  return { date, time };
}

export async function exportBpPdf(entries: BpPdfEntry[], stats: BpPdfStats | null): Promise<void> {
  await ensureFonts();

  const siteUrl = window.location.origin;
  const qrDataUrl = await QRCode.toDataURL(siteUrl, {
    width: 220,
    margin: 1,
    color: { dark: TEAL_DARK, light: "#ffffff" },
  });

  const sorted = [...entries].sort(
    (a, b) => new Date(a.measuredAt).getTime() - new Date(b.measuredAt).getTime()
  );
  const first = sorted[0] ? fmtDateTime(sorted[0].measuredAt).date : "—";
  const last = sorted.length ? fmtDateTime(sorted[sorted.length - 1].measuredAt).date : "—";

  const tableBody: any[] = [
    [
      { text: "Дата", style: "th" },
      { text: "Время", style: "th" },
      { text: "SYS", style: "th" },
      { text: "DIA", style: "th" },
      { text: "Пульс", style: "th" },
      { text: "Рука", style: "th" },
      { text: "Самочувствие", style: "th" },
      { text: "Оценка", style: "th" },
    ],
    ...sorted.map((e) => {
      const { date, time } = fmtDateTime(e.measuredAt);
      return [
        { text: date, fontSize: 9 },
        { text: time, fontSize: 9, color: MUTED },
        { text: String(e.sys), fontSize: 10, bold: true, color: bpColor(e.sys, e.dia) },
        { text: String(e.dia), fontSize: 10, bold: true, color: bpColor(e.sys, e.dia) },
        { text: e.pulse != null ? String(e.pulse) : "—", fontSize: 9 },
        { text: e.arm === "left" ? "Левая" : "Правая", fontSize: 9, color: MUTED },
        { text: WB[e.wellbeing] ?? "—", fontSize: 9, color: MUTED },
        { text: bpLabel(e.sys, e.dia), fontSize: 8.5, color: bpColor(e.sys, e.dia), bold: true },
      ];
    }),
  ];

  const doc: any = {
    pageSize: "A4",
    pageMargins: [0, 0, 0, 60],
    defaultStyle: { font: "Roboto", fontSize: 10, color: "#1e293b" },
    footer: (page: number, pages: number) => ({
      margin: [40, 0, 40, 24],
      columns: [
        {
          text: "Отчёт сформирован системой «AI Врач» · не является медицинским диагнозом",
          fontSize: 8,
          color: MUTED,
        },
        { text: `${page} / ${pages}`, fontSize: 8, color: MUTED, alignment: "right" },
      ],
    }),
    content: [
      // ── Фирменная шапка ──
      {
        table: {
          widths: ["*"],
          body: [
            [
              {
                fillColor: TEAL,
                border: [false, false, false, false],
                margin: [28, 18, 28, 18],
                columns: [
                  {
                    stack: [
                      {
                        text: [
                          { text: "AI ", fontSize: 22, bold: true, color: "#ffffff" },
                          { text: "Врач", fontSize: 22, bold: true, color: "#99f6e4" },
                        ],
                      },
                      { text: "Цифровой двойник здоровья", fontSize: 10, color: "#ccfbf1", margin: [0, 4, 0, 0] },
                    ],
                  },
                  {
                    stack: [
                      { text: "ДНЕВНИК АРТЕРИАЛЬНОГО ДАВЛЕНИЯ", fontSize: 12, bold: true, color: "#ffffff", alignment: "right" },
                      { text: `Период: ${first} — ${last} · записей: ${sorted.length}`, fontSize: 9, color: "#ccfbf1", alignment: "right", margin: [0, 4, 0, 0] },
                      { text: `Сформировано: ${fmtDateTime(new Date()).date}`, fontSize: 9, color: "#ccfbf1", alignment: "right", margin: [0, 2, 0, 0] },
                    ],
                  },
                ],
              },
            ],
          ],
        },
        layout: "noBorders",
      },

      // ── Сводка ──
      stats && stats.count > 0
        ? {
            margin: [40, 20, 40, 0],
            columns: [
              statBox("Среднее АД", `${stats.avgSys}/${stats.avgDia}`, "мм рт. ст."),
              statBox("Средний пульс", stats.avgPulse != null ? String(stats.avgPulse) : "—", "уд/мин"),
              statBox("Максимум SYS", stats.maxSys != null ? String(stats.maxSys) : "—", "мм рт. ст."),
              statBox("≥ 140/90", `${stats.highPct}%`, `${stats.highCount} из ${stats.count}`),
            ],
          }
        : { text: "" },

      // ── Таблица измерений ──
      {
        margin: [40, 18, 40, 0],
        table: {
          headerRows: 1,
          widths: ["auto", "auto", "auto", "auto", "auto", "auto", "*", "auto"],
          body: tableBody,
        },
        layout: {
          fillColor: (row: number) => (row === 0 ? "#f0fdfa" : row % 2 === 0 ? "#f8fafc" : null),
          hLineColor: () => "#e2e8f0",
          vLineColor: () => "#e2e8f0",
          hLineWidth: () => 0.5,
          vLineWidth: () => 0.5,
          paddingTop: () => 4,
          paddingBottom: () => 4,
        },
      },

      // ── Классификация ──
      {
        margin: [40, 16, 40, 0],
        fontSize: 8.5,
        color: MUTED,
        text: [
          { text: "Классификация АД (ESC/ESH): ", bold: true, color: "#334155" },
          "Норма — до 129/84 · Высокое нормальное — 130–139/85–89 · Гипертония 1 ст. — 140–159/90–99 · Гипертония 2 ст. — от 160/100. ",
          "Оптимально измерять утром и вечером, сидя, после 5 минут покоя.",
        ],
      },

      // ── QR-код ──
      {
        margin: [40, 24, 40, 0],
        columns: [
          {
            width: 96,
            stack: [
              { image: qrDataUrl, width: 86, height: 86 },
            ],
          },
          {
            margin: [14, 8, 0, 0],
            stack: [
              { text: "Ваши данные всегда под рукой", fontSize: 12, bold: true, color: TEAL_DARK },
              {
                text: "Отсканируйте QR-код камерой телефона, чтобы открыть личный кабинет «AI Врач» — дневник давления, анализы, рекомендации и медкарта в одном месте.",
                fontSize: 9.5,
                color: MUTED,
                margin: [0, 5, 0, 0],
                lineHeight: 1.35,
              },
              {
                text: siteUrl.replace(/^https?:\/\//, ""),
                fontSize: 10,
                bold: true,
                color: TEAL,
                margin: [0, 6, 0, 0],
              },
            ],
          },
        ],
      },
    ],
    styles: {
      th: { bold: true, fontSize: 9, color: TEAL_DARK },
    },
  };

  function statBox(label: string, value: string, sub: string) {
    return {
      margin: [0, 0, 8, 0],
      table: {
        widths: ["*"],
        body: [
          [
            {
              border: [true, true, true, true],
              borderColor: ["#ccfbf1", "#ccfbf1", "#ccfbf1", "#ccfbf1"],
              fillColor: "#f0fdfa",
              margin: [10, 8, 10, 8],
              stack: [
                { text: value, fontSize: 15, bold: true, color: TEAL_DARK },
                { text: label, fontSize: 8, color: MUTED, margin: [0, 2, 0, 0] },
                { text: sub, fontSize: 7.5, color: "#94a3b8", margin: [0, 1, 0, 0] },
              ],
            },
          ],
        ],
      },
      layout: "noBorders",
    };
  }

  (pdfMake as any).createPdf(doc).download(`дневник-давления-${new Date().toISOString().slice(0, 10)}.pdf`);
}
