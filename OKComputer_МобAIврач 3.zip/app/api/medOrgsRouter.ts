import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { medOrgs } from "@db/schema";
import { and, asc, eq, like, or, sql } from "drizzle-orm";

const PAGE = 50;

export const medOrgsRouter = createRouter({
  // Сводка по категориям (кол-во учреждений)
  stats: publicQuery.query(async () => {
    const db = getDb();
    const rows = await db
      .select({ category: medOrgs.category, count: sql<number>`count(*)` })
      .from(medOrgs)
      .groupBy(medOrgs.category)
      .orderBy(sql`count(*) desc`);
    const total = rows.reduce((s, r) => s + Number(r.count), 0);
    return { total, byCategory: rows.map((r) => ({ category: r.category, count: Number(r.count) })) };
  }),

  // Постраничная выдача с фильтрами — без нагрузки на клиент
  list: publicQuery
    .input(
      z.object({
        category: z.string().optional(),
        q: z.string().optional(),
        limit: z.number().min(1).max(200).default(PAGE),
        offset: z.number().min(0).default(0),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conds = [];
      if (input.category) conds.push(eq(medOrgs.category, input.category));
      const q = input.q?.trim();
      if (q) {
        const pat = `%${q}%`;
        conds.push(
          or(
            like(medOrgs.name, pat),
            like(medOrgs.address, pat),
            like(medOrgs.operator, pat),
            like(medOrgs.specialties, pat)
          )
        );
      }
      const where = conds.length ? and(...conds) : undefined;
      const rows = await db
        .select()
        .from(medOrgs)
        .where(where)
        .orderBy(asc(medOrgs.name))
        .limit(input.limit)
        .offset(input.offset);
      const [cnt] = await db
        .select({ count: sql<number>`count(*)` })
        .from(medOrgs)
        .where(where);
      return { items: rows, total: Number(cnt?.count ?? 0) };
    }),
});
